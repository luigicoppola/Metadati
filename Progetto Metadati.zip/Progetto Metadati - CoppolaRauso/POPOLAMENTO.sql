-- DATABASE

INSERT ALL
INTO Database(id_db,nome) VALUES ('1','Segrepass')
INTO Database(id_db,nome) VALUES ('2','Ufficio')
INTO Database(id_db,nome) VALUES ('3','Ferrovia')
SELECT * FROM DUAL;

-- TABELLA

INSERT ALL
INTO Tabella(id_tabella,nome,id_db) VALUES ('1','Studenti','1')
INTO Tabella(id_tabella,nome,id_db) VALUES ('2','Professori','1')
INTO Tabella(id_tabella,nome,id_db) VALUES ('3','Esami','1')
INTO Tabella(id_tabella,nome,id_db) VALUES ('4','Corsi','1')

INTO Tabella(id_tabella,nome,id_db) VALUES ('5','Impiegati','2')
INTO Tabella(id_tabella,nome,id_db) VALUES ('6','Sedi','2')
INTO Tabella(id_tabella,nome,id_db) VALUES ('7','Stipendi','2')
INTO Tabella(id_tabella,nome,id_db) VALUES ('8','Lavori','2')

INTO Tabella(id_tabella,nome,id_db) VALUES ('9','Treni','3')
INTO Tabella(id_tabella,nome,id_db) VALUES ('10','Stazioni','3')
INTO Tabella(id_tabella,nome,id_db) VALUES ('11','Tratta','3')
INTO Tabella(id_tabella,nome,id_db) VALUES ('12','Citt�','3')



SELECT * FROM DUAL;

-- DOMINIO
INSERT ALL
INTO DOMINIO (id_dominio,nome,descrizione,formato) VALUES ('1','int','numeri interi,'int')
INTO DOMINIO (id_dominio,nome,descrizione,formato) VALUES ('2','String','stringa,'String')
INTO DOMINIO (id_dominio,nome,descrizione,formato) VALUES ('3','Boolean','booleani,'Boolean')
INTO DOMINIO (id_dominio,nome,descrizione,formato) VALUES ('4','votazione','voto maggiore di 18,'voti>18')
INTO DOMINIO (id_dominio,nome,descrizione,formato) VALUES ('5','giorni','ricoveri almeno 2 giorni,'giorni>18')
SELECT * FROM DUAL;


--ATTRIBUTO

INSERT ALL
INTO ATTRIBUTO(id_attributo,Nome,Defoult,id_tabella, id_dominio,PK, nome_pk,posizione_pk) VALUES('1','IdStudente','NOT NULL','1','1','*','pk1','1')
INTO ATTRIBUTO(id_attributo,Nome,Defoult,id_tabella, id_dominio,PK, nome_pk,posizione_pk) VALUES('2','NomeStudente','NOT NULL','1','1',null,null,null)
INTO ATTRIBUTO(id_attributo,Nome,Defoult,id_tabella, id_dominio,PK, nome_pk,posizione_pk) VALUES('3','CognomeStudente','NOT NULL','1','1',null,null,null)
INTO ATTRIBUTO(id_attributo,Nome,Defoult,id_tabella, id_dominio,PK, nome_pk,posizione_pk) VALUES('4','SessoStudente','NOT NULL','1','2',null,null,null)


INTO ATTRIBUTO(id_attributo,Nome,Defoult,id_tabella, id_dominio,PK, nome_pk,posizione_pk) VALUES('5','IdProf','NOT NULL','2','1','*','pk2','1')
INTO ATTRIBUTO(id_attributo,Nome,Defoult,id_tabella, id_dominio,PK, nome_pk,posizione_pk) VALUES('6','NomeProf','NOT NULL','2','2',null,null,null)
INTO ATTRIBUTO(id_attributo,Nome,Defoult,id_tabella, id_dominio,PK, nome_pk,posizione_pk) VALUES('7','CognomeProf','NOT NULL','2','2',null,null,null)


INTO ATTRIBUTO(id_attributo,Nome,Defoult,id_tabella, id_dominio,PK, nome_pk,posizione_pk) VALUES('8','IdCorso','NOT NULL','4','1','*','pk3','1')
INTO ATTRIBUTO(id_attributo,Nome,Defoult,id_tabella, id_dominio,PK, nome_pk,posizione_pk) VALUES('9','NomeCorso','NOT NULL','4','2',null,null,null)
INTO ATTRIBUTO(id_attributo,Nome,Defoult,id_tabella, id_dominio,PK, nome_pk,posizione_pk) VALUES('10','CodProf','NOT NULL','4','1',null,null,null)
INTO ATTRIBUTO(id_attributo,Nome,Defoult,id_tabella, id_dominio,PK, nome_pk,posizione_pk) VALUES('11','Aula','NOT NULL','4','2',null,null,null)


INTO ATTRIBUTO(id_attributo,Nome,Defoult,id_tabella, id_dominio,PK, nome_pk,posizione_pk) VALUES('12','IdImpiegato','NOT NULL','5','1','*','pk4','1')
INTO ATTRIBUTO(id_attributo,Nome,Defoult,id_tabella, id_dominio,PK, nome_pk,posizione_pk) VALUES('13','NomeImpiegato','NOT NULL','5','2',null,null,null)
INTO ATTRIBUTO(id_attributo,Nome,Defoult,id_tabella, id_dominio,PK, nome_pk,posizione_pk) VALUES('14','CognomeImpiegato','NOT NULL','5','2',null,null,null)

INTO ATTRIBUTO(id_attributo,Nome,Defoult,id_tabella, id_dominio,PK, nome_pk,posizione_pk) VALUES('15','IdSede','NOT NULL','6','1','*','pk5','1')
INTO ATTRIBUTO(id_attributo,Nome,Defoult,id_tabella, id_dominio,PK, nome_pk,posizione_pk) VALUES('16','NomeSede','NOT NULL','6','2',null,null,null)
INTO ATTRIBUTO(id_attributo,Nome,Defoult,id_tabella, id_dominio,PK, nome_pk,posizione_pk) VALUES('17','ImpiegatoIn','NOT NULL','6','1',null,null,null)

INTO ATTRIBUTO(id_attributo,Nome,Defoult,id_tabella, id_dominio,PK, nome_pk,posizione_pk) VALUES('18','IdTreno','NOT NULL','9','1','*','pk6','1')
INTO ATTRIBUTO(id_attributo,Nome,Defoult,id_tabella, id_dominio,PK, nome_pk,posizione_pk) VALUES('19','CompagniaTreno','NOT NULL','9','2',null,null,null)
INTO ATTRIBUTO(id_attributo,Nome,Defoult,id_tabella, id_dominio,PK, nome_pk,posizione_pk) VALUES('20','TipologiaTreno','NOT NULL','9','2',null,null,null)

INTO ATTRIBUTO(id_attributo,Nome,Defoult,id_tabella, id_dominio,PK, nome_pk,posizione_pk) VALUES('21','IdStazione','NOT NULL','9','1','*','pk7','1')
INTO ATTRIBUTO(id_attributo,Nome,Defoult,id_tabella, id_dominio,PK, nome_pk,posizione_pk) VALUES('22','Citt�','NOT NULL','9','2',null,null,null)
INTO ATTRIBUTO(id_attributo,Nome,Defoult,id_tabella, id_dominio,PK, nome_pk,posizione_pk) VALUES('23','PassaTreno','NOT NULL','9','1',null,null,null)
SELECT * FROM DUAL;



-- FOREIGN KEYS
INSERT ALL

INTO FOREIGNKEY(Nome_Fk,id_tabella,id_attributo,RTabella, RAttributo,posizione) VALUES('fk1','4','9','2','4')
INTO FOREIGNKEY(Nome_Fk,id_tabella,id_attributo,RTabella, RAttributo,posizione) VALUES('fk2','6','16','5','11')
INTO FOREIGNKEY(Nome_Fk,id_tabella,id_attributo,RTabella, RAttributo,posizione) VALUES('fk3','10','23','9','18')
SELECT * FROM DUAL;


--CHECK

INSERT ALL
INTO VCHECK (nome,descrizione, id_attributo,codice_sql) VALUES('SessoStudente','Scelta del sesso','4','Sesso IN ("MASCHIO","Femmina")')
INTO VCHECK (nome,descrizione, id_attributo,codice_sql) VALUES('TipoTreno', 'Tipologia del treno','20', 'TipoTreno IN ("Intercity","Regionale","Alta Velocit�")')
SELECT * FROM DUAL;

--VISTA

INSERT ALL
INTO VISTA (id_vista,nome,descrizione, codice_sql,id_db) VALUES ('1','MediaVoti','Media voti studente', 'CREATE VIEW MediaVoti AS SELECT column1, column2 FROM table_name WHERE condition','1')
INTO VISTA (id_vista,nome,descrizione, codice_sql,id_db) VALUES ('2','TreniNapoli','Treni con stazione Napoli','CREATE VIEW TreniNapoli AS SELECT column1, column2 FROM table_name WHERE condition','3')
INTO VISTA (id_vista,nome,descrizione, codice_sql,id_db) VALUES ('3','SediAziendaNapoli','Azienda a Napoli', 'CREATE VIEW SediAziendaNapoli AS SELECT column1, column2 FROM table_name WHERE condition','2')
SELECT * FROM DUAL;

--TRIGGER

INSERT ALL
INTO TRIGGERS (id_trigger,nome,descrizione, codice_sql,id_tabella,id_vista) VALUES ('1','AggiornaMedia','Aggiorna media dello studente','CREATE TRIGGER AggiornaMedia ON { table | view }',null,'1')
INTO TRIGGERS (id_trigger,nome,descrizione, codice_sql,id_tabella,id_vista) VALUES ('2','AggiungiSede','Inserisce sedi','CREATE TRIGGER AggiornaMedia ON { table | view }','6',null)
SELECT * FROM DUAL;


--ASSERZIONE

INSERT ALL
INTO ASSERZIONE(id_asserzione,nome,descrizione,codice_sql,id_db) VALUES('1','MaxDipendentiSede','Numero massimo di dipendenti in una sede', 'create assertion limitaImpieghi check (not exists(...))','2')
INTO ASSERZIONE(id_asserzione,nome,descrizione,codice_sql,id_db) VALUES('2','MaxTreniNapoli','Numero massimo di treni per Napoli', 'create assertion MaxTreniNapoli check (not exists(...))','3')
INTO ASSERZIONE(id_asserzione,nome,descrizione,codice_sql,id_db) VALUES('3','MaxProfCorso','Ogni corso ha massimo un professore', 'create assertion MaxProfCorso check (not exists(...))','1')
SELECT * FROM DUAL;

--PROCEDURA
INSERT ALL 
INTO PROCEDURA (id_procedura,nome,descrizione, codice_sql,id_db) VALUES ('1','ListaStudentiCorso','Crea la lista degli studenti che seguono il corso','CREATE PROCEDURE ListaStudentiCorso (parametro1,parametro2) AS ... ;','1')
INTO PROCEDURA (id_procedura,nome,descrizione, codice_sql,id_db) VALUES ('2','ListaTreniNapoli','Crea la lista dei treni per Napoli','CREATE PROCEDURE ListaTreniNapoli (parametro1,parametro2) AS ... ;','3')
INTO PROCEDURA (id_procedura,nome,descrizione, codice_sql,id_db) VALUES ('3','ContaImpiegatiSede','Restituisce numero di impiegati in una sede','CREATE PROCEDURE ContaImpiegatiSede (parametro1,parametro2) AS ... ;','2')
SELECT * FROM DUAL;

--SEQUENZA
INSERT ALL 
INTO SEQUENZA (nome,startwith,incremento,minval,maxval,id_attributo) VALUES ('OneStudente','20','2','10','150','1')
INTO SEQUENZA (nome,startwith,incremento,minval,maxval,id_attributo) VALUES ('TwoImpiegato','10','1','5','100','5')
INTO SEQUENZA (nome,startwith,incremento,minval,maxval,id_attributo) VALUES ('TreeTrain','50','25','50','1000','18')
SELECT * FROM DUAL;

--UTENTE

INSERT ALL
INTO UTENTE(username,nome,cognome,email,password) VALUES ('luisinho','Luigi','Coppola','coppolaluigi@virgilio.it','copp94')
INTO UTENTE(username,nome,cognome,email,password) VALUES ('rausocir','Ciro','Rauso','ciroras@virgilio.it','cir94')
INTO UTENTE(username,nome,cognome,email,password) VALUES ('debounina','Debora','Farina','debfar@live.it','debyuni')
INTO UTENTE(username,nome,cognome,email,password) VALUES ('Redmirko','Mirko','Rossi','mirkoilred@virgilio.it','red94')
INTO UTENTE(username,nome,cognome,email,password) VALUES ('Pocho','Ezequiel','Lavezzi','pocho11@virgilio.it','pocholoco')
INTO UTENTE(username,nome,cognome,email,password) VALUES ('Matador','Edinson','Cavani','edinsnap@outlook.com','napoli1926')
SELECT * FROM DUAL;

--PERMESSI
 
INSERT ALL
INTO ACCESSO(username,id_db,accesso) VALUES('luisinho','1','Writer')
INTO ACCESSO(username,id_db,accesso) VALUES('luisinho','2','Reader')
INTO ACCESSO(username,id_db,accesso) VALUES('Pocho','1','Writer')
INTO ACCESSO(username,id_db,accesso) VALUES('Matador','3','Editor')
INTO ACCESSO(username,id_db,accesso) VALUES('Redmirko','2','Reader')
SELECT * FROM DUAL;



 














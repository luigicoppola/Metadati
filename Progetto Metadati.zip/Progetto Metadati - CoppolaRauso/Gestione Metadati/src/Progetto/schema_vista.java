/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Progetto;

/**
 *
 * @author Coppola Luigi
 */
public class schema_vista {
    private  int id_vista;
    private  String nome;
    private  String descrizione;
    private  String codice_sql;
    private  int id_db;
    
    public schema_vista(int id_vista, String nome, String descrizione, String codice_sql, int id_db){
    this.id_vista= id_vista;
    this.nome=nome;
    this.descrizione=descrizione;
    this.codice_sql=codice_sql;
    this.id_db=id_db;
    }

    public int getId_vista() {
        return id_vista;
    }

    public String getNome() {
        return nome;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public String getCodice_sql() {
        return codice_sql;
    }

    public int getId_db() {
        return id_db;
    }

    public void setId_vista(int id_vista) {
        this.id_vista = id_vista;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public void setCodice_sql(String codice_sql) {
        this.codice_sql = codice_sql;
    }

    public void setId_db(int id_db) {
        this.id_db = id_db;
    }

    @Override
    public String toString() {
        return "schema_vista{" + "id_vista=" + id_vista + ", nome=" + nome + ", descrizione=" + descrizione + ", codice_sql=" + codice_sql + ", id_db=" + id_db + '}';
    }
    
    
   
    
    
}

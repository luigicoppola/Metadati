/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Progetto;

/**
 *
 * @author Coppola Luigi
 */
public class schema_attributo {
    
   private int id_attributo ; 
   private String Nome;
   private String Defoult;
   private int id_tabella;
   private int id_dominio;
    private String PK;
     private String nome_pk;
      private int posizione_pk;

    public schema_attributo(int id_attributo, String Nome, String Defoult, int id_tabella, int id_dominio, String PK, String nome_pk, int posizione_pk) {
        this.id_attributo = id_attributo;
        this.Nome = Nome;
        this.Defoult = Defoult;
        this.id_tabella = id_tabella;
        this.id_dominio = id_dominio;
        this.PK = PK;
        this.nome_pk = nome_pk;
        this.posizione_pk = posizione_pk;
    }

    public int getId_attributo() {
        return id_attributo;
    }

    public void setId_attributo(int id_attributo) {
        this.id_attributo = id_attributo;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    public String getDefoult() {
        return Defoult;
    }

    public void setDefoult(String Defoult) {
        this.Defoult = Defoult;
    }

    public int getId_tabella() {
        return id_tabella;
    }

    public void setId_tabella(int id_tabella) {
        this.id_tabella = id_tabella;
    }

    public int getId_dominio() {
        return id_dominio;
    }

    public void setId_dominio(int id_dominio) {
        this.id_dominio = id_dominio;
    }

    public String getPK() {
        return PK;
    }

    public void setPrimary_key(String primary_key) {
        this.PK = PK;
    }

    public String getNome_pk() {
        return nome_pk;
    }

    public void setNome_pk(String nome_pk) {
        this.nome_pk = nome_pk;
    }

    public int getPosizione_pk() {
        return posizione_pk;
    }

    public void setPosizione_pk(int posizione_pk) {
        this.posizione_pk = posizione_pk;
    }

    @Override
    public String toString() {
        return "schema_attributo{" + "id_attributo=" + id_attributo + ", Nome=" + Nome + ", Defoult=" + Defoult + ", id_tabella=" + id_tabella + ", id_dominio=" + id_dominio + ", PK=" + PK + ", nome_pk=" + nome_pk + ", posizione_pk=" + posizione_pk + '}';
    }

    
    
}

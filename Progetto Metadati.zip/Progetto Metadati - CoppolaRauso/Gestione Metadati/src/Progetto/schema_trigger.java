/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Progetto;

/**
 *
 * @author Coppola Luigi
 */
public class schema_trigger {
    private int id_trigger;
    private String nome;
    private String Descrizione;
    private String codice_sql;
    private int id_tabella;
    private int id_vista;

    public schema_trigger(int id_trigger, String nome, String Descrizione, String codice_sql, int id_tabella, int id_vista) {
        this.id_trigger = id_trigger;
        this.nome = nome;
        this.Descrizione = Descrizione;
        this.codice_sql = codice_sql;
        this.id_tabella = id_tabella;
        this.id_vista = id_vista;
    }

    public int getId_trigger() {
        return id_trigger;
    }

    public void setId_trigger(int id_trigger) {
        this.id_trigger = id_trigger;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String Nome) {
        this.nome = nome;
    }

    public String getDescrizione() {
        return Descrizione;
    }

    public void setDescrizione(String Descrizione) {
        this.Descrizione = Descrizione;
    }

    public String getCodice_sql() {
        return codice_sql;
    }

    public void setCodice_sql(String codice_sql) {
        this.codice_sql = codice_sql;
    }

    public int getId_tabella() {
        return id_tabella;
    }

    public void setId_tabella(int id_tabella) {
        this.id_tabella = id_tabella;
    }

    public int getId_vista() {
        return id_vista;
    }

    public void setId_vista(int id_vista) {
        this.id_vista = id_vista;
    }

    @Override
    public String toString() {
        return "schema_trigger{" + "id_trigger=" + id_trigger + ", Nome=" + nome + ", Descrizione=" + Descrizione + ", codice_sql=" + codice_sql + ", id_tabella=" + id_tabella + ", id_vista=" + id_vista + '}';
    }
    
    
    
    
    
  
    
    
    
}

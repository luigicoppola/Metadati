/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Progetto;

/**
 *
 * @author Coppola Luigi
 */
public class schema_procedura {
    
    private int id_procedura;
    private String nome;
    private String descrizione;
    private String codice_sql;
    private int id_db;

    public schema_procedura(int id_procedura, String nome, String descrizione, String codice_sql, int id_db) {
        this.id_procedura = id_procedura;
        this.nome = nome;
        this.descrizione = descrizione;
        this.codice_sql = codice_sql;
        this.id_db = id_db;
    }

    public int getId_procedura() {
        return id_procedura;
    }

    public String getNome() {
        return nome;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public String getCodice_sql() {
        return codice_sql;
    }

    public int getId_db() {
        return id_db;
    }

    public void setId_procedura(int id_procedura) {
        this.id_procedura = id_procedura;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public void setCodice_sql(String codice_sql) {
        this.codice_sql = codice_sql;
    }

    public void setId_db(int id_db) {
        this.id_db = id_db;
    }

    @Override
    public String toString() {
        return "schema_procedura{" + "id_procedura=" + id_procedura + ", nome=" + nome + ", descrizione=" + descrizione + ", codice_sql=" + codice_sql + ", id_db=" + id_db + '}';
    }
    
    
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Progetto;

/**
 *
 * @author Coppola Luigi
 */
public class schema_check {
    
    private String nome;
    private String descrizione;
    private int id_attributo;
    private String codice_sql;

    public schema_check(String nome, String descrizione, int id_attributo, String codice_sql) {
        this.nome = nome;
        this.descrizione = descrizione;
        this.id_attributo = id_attributo;
        this.codice_sql = codice_sql;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public int getId_attributo() {
        return id_attributo;
    }

    public void setId_attributo(int id_attributo) {
        this.id_attributo = id_attributo;
    }

    public String getCodice_sql() {
        return codice_sql;
    }

    public void setCodice_sql(String codice_sql) {
        this.codice_sql = codice_sql;
    }

    @Override
    public String toString() {
        return "schema_check{" + "nome=" + nome + ", descrizione=" + descrizione + ", id_attributo=" + id_attributo + ", codice_sql=" + codice_sql + '}';
    }

    
    
    
}

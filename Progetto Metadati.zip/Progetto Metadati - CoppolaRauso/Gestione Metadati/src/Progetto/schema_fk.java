/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Progetto;

/**
 *
 * @author Coppola Luigi
 */
public class schema_fk {
  private String Nome_fk;
  private int id_tabella;
  private int id_attributo;
  private int RTabella;
  private int RAttributo;
  private int posizione; 

    public schema_fk(String Nome_fk, int id_tabella, int id_attributo, int RTabella, int RAttributo, int posizione) {
        this.Nome_fk = Nome_fk;
        this.id_tabella = id_tabella;
        this.id_attributo = id_attributo;
        this.RTabella = RTabella;
        this.RAttributo = RAttributo;
        this.posizione = posizione;
    }

    public String getNome_fk() {
        return Nome_fk;
    }

    public void setNome_fk(String Nome_fk) {
        this.Nome_fk = Nome_fk;
    }

    public int getId_tabella() {
        return id_tabella;
    }

    public void setId_tabella(int id_tabella) {
        this.id_tabella = id_tabella;
    }

    public int getId_attributo() {
        return id_attributo;
    }

    public void setId_attributo(int id_attributo) {
        this.id_attributo = id_attributo;
    }

    public int getRTabella() {
        return RTabella;
    }

    public void setRTabella(int RTabella) {
        this.RTabella = RTabella;
    }

    public int getRAttributo() {
        return RAttributo;
    }

    public void setRAttributo(int RAttributo) {
        this.RAttributo = RAttributo;
    }

    public int getPosizione() {
        return posizione;
    }

    public void setPosizione(int posizione) {
        this.posizione = posizione;
    }

    @Override
    public String toString() {
        return "schema_fk{" + "Nome_fk=" + Nome_fk + ", id_tabella=" + id_tabella + ", id_attributo=" + id_attributo + ", RTabella=" + RTabella + ", RAttributo=" + RAttributo + ", posizione=" + posizione + '}';
    }
                     

  
  
    
}

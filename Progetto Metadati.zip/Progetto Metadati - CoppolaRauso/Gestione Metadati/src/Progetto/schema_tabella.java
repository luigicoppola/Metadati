/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Progetto;

/**
 *
 * @author Coppola Luigi
 */
public class schema_tabella {
    private int id_tabella;
    private String nome;
    private int id_db;
    
   public schema_tabella(int id_tabella,String nome,int id_db){
  this.id_tabella=id_tabella;
  this.nome=nome;
  this.id_db=id_db;
   } 

   

    public int getId_tabella() {
        return id_tabella;
    }

    public void setId_tabella(int id_tabella) {
        this.id_tabella = id_tabella;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getId_db() {
        return id_db;
    }

    public void setId_db(int id_db) {
        this.id_db = id_db;
    }

  @Override
    public String toString() {
        return "schema_tabella{" + "id_tabella=" + id_tabella + ", nome=" + nome + ", id_db=" + id_db + '}';
    }   
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Progetto;

/**
 *
 * @author Coppola Luigi
 */
public class schema_dominio {
    private int id_dominio;
    private String nome;
    private String descrizione;
    private String formato;

    public schema_dominio(int id_dominio, String nome, String descrizione, String formato) {
        this.id_dominio = id_dominio;
        this.nome = nome;
        this.descrizione = descrizione;
        this.formato = formato;
    }

    public int getId_dominio() {
        return id_dominio;
    }

    public void setId_dominio(int id_dominio) {
        this.id_dominio = id_dominio;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public String getFormato() {
        return formato;
    }

    public void setFormato(String formato) {
        this.formato = formato;
    }

    @Override
    public String toString() {
        return "schema_dominio{" + "id_dominio=" + id_dominio + ", nome=" + nome + ", descrizione=" + descrizione + ", formato=" + formato + '}';
    }
    
    
    

}
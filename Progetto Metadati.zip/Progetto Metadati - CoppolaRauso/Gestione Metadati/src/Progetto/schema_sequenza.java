/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Progetto;

/**
 *
 * @author Coppola Luigi
 */
public class schema_sequenza {
    private String nome;
    private int startwith;
    private int incremento;
    private int minval;
    private int maxval;
    private int id_attributo;

    public schema_sequenza(String nome, int startwith, int incremento, int minval, int maxval, int id_attributo) {
        this.nome = nome;
        this.startwith = startwith;
        this.incremento = incremento;
        this.minval = minval;
        this.maxval = maxval;
        this.id_attributo = id_attributo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getStartwith() {
        return startwith;
    }

    public void setStartwith(int startwith) {
        this.startwith = startwith;
    }

    public int getIncremento() {
        return incremento;
    }

    public void setIncremento(int incremento) {
        this.incremento = incremento;
    }

    public int getMinval() {
        return minval;
    }

    public void setMinval(int minval) {
        this.minval = minval;
    }

    public int getMaxval() {
        return maxval;
    }

    public void setMaxval(int maxval) {
        this.maxval = maxval;
    }

    public int getId_attributo() {
        return id_attributo;
    }

    public void setId_attributo(int id_attributo) {
        this.id_attributo = id_attributo;
    }

    @Override
    public String toString() {
        return "schema_sequenza{" + "nome=" + nome + ", startwith=" + startwith + ", incremento=" + incremento + ", minval=" + minval + ", maxval=" + maxval + ", id_attributo=" + id_attributo + '}';
    }

    
   
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Progetto;


import static Progetto.Database.getDefaultConnection;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Coppola Luigi
 */
public class CountFunction {

    /**
     *
     * @param tableName
     * @return
     * @throws SQLException
     */
    public static int countDb(String tableName) throws SQLException
    {
     int tot=0;
     Connection  con = getDefaultConnection();
     Statement st;
     try{
         st=con.createStatement();
         ResultSet rs=st.executeQuery( "SELECT COUNT(*) FROM "+tableName);
         while(rs.next()){
         tot=rs.getInt(1);
         
         
         
         }
     }
         catch(SQLException ex){
                 Logger.getLogger(CountFunction.class.getName()).log(Level.SEVERE, null, ex);
                 }
     return tot;
    }
 }

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Progetto;

/**
 *
 * @author Coppola Luigi
 */
public class schema_accesso {
    String username;
    String accesso;
    int id_db;

    public schema_accesso(String username, String accesso, int id_db) {
        this.username = username;
        this.accesso = accesso;
        this.id_db = id_db;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getAccesso() {
        return accesso;
    }

    public void setAccesso(String accesso) {
        this.accesso = accesso;
    }

    public int getId_db() {
        return id_db;
    }

    public void setId_db(int id_db) {
        this.id_db = id_db;
    }

    @Override
    public String toString() {
        return "schema_accesso{" + "username=" + username + ", accesso=" + accesso + ", id_db=" + id_db + '}';
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Progetto;


import static Progetto.Database.getDefaultConnection;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import org.jdesktop.beansbinding.*;
import Progetto.CountFunction;
import static com.sun.org.apache.xalan.internal.xsltc.compiler.util.Type.String;
import static com.sun.xml.internal.fastinfoset.alphabet.BuiltInRestrictedAlphabets.table;
import java.awt.Color;
import java.awt.event.ItemEvent;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import static jdk.internal.org.objectweb.asm.commons.GeneratorAdapter.AND;

/**
 *
 * @author Coppola Luigi
 */
public final class Scelta extends javax.swing.JFrame {
  
 
    


    /** Creates new form Scelta
     * @throws java.sql.SQLException */
     public Scelta() throws SQLException {
          
      initComponents();
       
      loginOrExit();
      
      
       Scelta.ndb.setText(""+Integer.toString(CountFunction.countDb("DATABASE")));
       Scelta.ntb.setText(""+Integer.toString(CountFunction.countDb("TABELLA")));
       Scelta.nvst.setText(""+Integer.toString(CountFunction.countDb("VISTA")));
       Scelta.nusr.setText(""+Integer.toString(CountFunction.countDb("UTENTE")));
       Scelta.ntrg.setText(""+Integer.toString(CountFunction.countDb("TRIGGERS")));
       Scelta.nass.setText(""+Integer.toString(CountFunction.countDb("ASSERZIONE")));
       Scelta.nprd.setText(""+Integer.toString(CountFunction.countDb("DATABASE")));
       Scelta.natt.setText(""+Integer.toString(CountFunction.countDb("ATTRIBUTO")));
       Scelta.nprd.setText(""+Integer.toString(CountFunction.countDb("PROCEDURA")));
       Scelta.nsqz.setText(""+Integer.toString(CountFunction.countDb("SEQUENZA")));
       Scelta.ndmn.setText(""+Integer.toString(CountFunction.countDb("DOMINIO")));
       jTabbedPane2.setSelectedIndex(0) ; 
     
       Show_Db_In_JTable();
        //Show_Table_In_JTable();
        
       Show_db_In_JCombo();
      // Show_View_In_JTable();
       Show_Db_In_JCombo2();
       //Show_Assertion_In_JTable();
       Show_Db_In_JCombo3();
       Show_Table_In_JComboTriggers();
       Show_View_In_JComboTriggers();
       //Show_Trigger_In_JTable();
       Show_Attribute_In_JTable();
       Show_Formato_In_JCombo();
       Search_Db_in_JTable1( JTable1,"");
      Show_Domain_In_JComboAttributoDomain();
       Show_Table_In_JComboAttributo();
       Show_Domain_In_JComboAttributoDomain();
       Search_Table_in_JTable1( jTable2,"");
       Show_SProcedure_In_JTable();
       Show_Db_In_JComboProcedura();
       Search_Trigger_in_JTable5( jTable5,"");
       Show_User_In_JTable();
       Search_Assertion_in_JTable1( jTable6,"");
      Search_View_in_JTable1(jTable3,"");
      Show_Table_In_JComboAttribute();
    //Show_Attribute_In_JComboAttribute();
      //RiempiRAttributo();
    // RiempiTextAttributo();
      //Search_Attribute_in_JTable10(jTable10,"");
      Show_Table_In_JComboTabellaAttribute();
      //Show_Attribute_In_JComboAttributes();
       Show_Fk_In_JTable();
       //Search_FK_in_JTableFk(tabellaFk, "");
     // Show_Attribute_In_JTable();
      Show_Table_In_JComboCheck() ;
      Show_Dominio_In_JTable();
//      Show_Attribute_In_JComboCheck() ;
        Show_Check_In_JTable();
        Show_Table_In_JComboSequenza();
    //Show_Attribute_In_JComboSequenza();
       // RiempiAttributoSequenza();
       Show_Sequenza_In_JTable();
      Show_Access_In_JTable();
     
   }
     
     
     
     //LOGIN

   private void loginOrExit() {
      Login l = new Login(this, true);
      l.setVisible(true);
      if (l.getPremuto() == Login.PREMUTO_ANNULLA) {
        // dispose();
        System.exit(0);
      } else {
         setVisible(true);
      }
   } 
      
   
     

     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
  
  


 
  
   
   
   
   
   
   //CREO LISTA DI DATABASE SECONDO LO SCHEMA_DB
   
    public ArrayList<schema_db> getDbList() throws SQLException {
        
       ArrayList<schema_db> DbList = new ArrayList<>();
       Connection con = getDefaultConnection();
       
       String query = "SELECT * FROM  Database";
       Statement st;
       ResultSet rs;
       
       try {
           st = con.createStatement();
           rs = st.executeQuery(query);

           schema_db db;

           while(rs.next())
           {
           db = new schema_db(rs.getInt("id_db"),rs.getString("nome"));
               DbList.add(db);
           }

       } 
      catch (SQLException e) {
       }
       return DbList;
   }  
       
        
 
 //MOSTRO LA LISTA DEI DB NELLA TABELLA DI OUTPUT
 
   public void Show_Db_In_JTable() throws SQLException
   {
       ArrayList<schema_db> list = getDbList();
        DefaultTableModel model = (DefaultTableModel) JTable1.getModel();
       Object[] row = new Object[2];
       for(int i = 0; i < list.size(); i++)
       {
           row[0] = list.get(i).getId_db();
           row[1] = list.get(i).getNome();
           
           model.addRow(row);
       }}
   
   
   
   //EFFETTUO RICERCA DEI DB CHE HANNO UN VALORE CONTENTE IL VALUETOSEARCH INSERITO DALL'UTENTE
   
      public void Search_Db_in_JTable1(JTable table,String valueToSearch) throws SQLException{
 
 Connection con = getDefaultConnection();
       
       String query = "SELECT * FROM  database WHERE CONCAT(id_db,nome) LIKE '%"+valueToSearch+"%'";
     
       
       Statement st;
       ResultSet rs;
       
       try {
           st = con.createStatement();
           rs = st.executeQuery(query);
           DefaultTableModel model= (DefaultTableModel)table.getModel();
           Object[] row;
           while(rs.next()){
           row=new Object[2];
           row[0]= rs.getInt(1);
           row[1]= rs.getString(2);
           model.addRow(row);
           
           
           }
  } 
      catch (SQLException e) {
          //
       }
      
 }
   
   
   
  
   
   
   
   
   
       
// CREO LISTA DELLE TABELLE SECONDO LO SCHEMA_TABELLA
 public ArrayList<schema_tabella> getTableList() throws SQLException {
        
       ArrayList<schema_tabella> TabellaList = new ArrayList<>();
       Connection con = getDefaultConnection();
       
       String query = "SELECT * FROM  tabella ORDER BY id_db ASC ";
       Statement st;
       ResultSet rs;
       
       try {
           st = con.createStatement();
           rs = st.executeQuery(query);

           schema_tabella tabella;

           while(rs.next())
           {
           tabella = new schema_tabella(rs.getInt("id_tabella"),rs.getString("nome"),rs.getInt("id_db"));
               TabellaList.add(tabella);
           }

       } 
      catch (SQLException e) {
       }
       return TabellaList;
   }
       


     //MOSTRA LE TABELLE NELLA TABELLA DI OUTPUT
 
  public void Show_Table_In_JTable() throws SQLException
   {
       ArrayList<schema_tabella> list = getTableList();
        DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
       Object[] row = new Object[3];
       for(int i = 0; i < list.size(); i++)
       {
           row[0] = list.get(i).getId_tabella();
           row[1] = list.get(i).getNome();
           row[2] = list.get(i).getId_db();
           
           
           model.addRow(row);
       }}  
       
       
     //MOSTRO LA LISTA DEI DATABASE NELLA JCOMBO 
       public void Show_db_In_JCombo() throws SQLException
   {
       
       String query="SELECT * FROM DATABASE ORDER BY id_db ASC";
       Statement st;
       ResultSet rs;
       
      try {
          Connection con= getDefaultConnection();
           st = con.createStatement();
           rs = st.executeQuery(query);
           jComboBox_db.addItem("Seleziona");
           while(rs.next()) {
            jComboBox_db.addItem(rs.getInt("id_db")+":"+rs.getString("nome")); 
           }   
       } 
      catch (SQLException e) {
              
              }
       }

       
       
       
       
       
       
       
  
     //MOSTRA I DB NELLA COMBO DB  

    /**
     *
     * @throws SQLException
     */
       public void Show_Db_In_JCombo2() throws SQLException
   {
       
       String query="SELECT id_db,nome FROM DATABASE ORDER BY id_db ASC";
       Statement st;
       ResultSet rs;
       
      try {
          Connection con= getDefaultConnection();
           st = con.createStatement();
           rs = st.executeQuery(query);
           jComboBoxDb2.addItem("Seleziona");
           while(rs.next()) {
            jComboBoxDb2.addItem(rs.getString("id_db")+":" +rs.getString("nome")); 
           
           }    
           

       } 
      catch (SQLException e) {
              
              }
       }

       
       
       //EFFETTUO RICERCA TABELLA SECONDO IL VALORE INSERITO DA UTENTE
 
  public void Search_Table_in_JTable1(JTable table,String valueToSearch) throws SQLException{
   Connection con = getDefaultConnection();
       
       String query = "SELECT * FROM  tabella WHERE id_tabella LIKE '%"+valueToSearch+"%'OR nome LIKE '%"+valueToSearch+"%' OR id_db LIKE '%"+valueToSearch+"%'" ;
     
       
       Statement st;
       ResultSet rs;
       
       try {
           st = con.createStatement();
           rs = st.executeQuery(query);
           DefaultTableModel model= (DefaultTableModel)table.getModel();
           Object[] row;
           while(rs.next()){
           row=new Object[3];
           row[0]= rs.getInt(1);
           row[1]= rs.getString(2);
           row[2]= rs.getInt(3);
           model.addRow(row);
           
           
           }
  } 
      catch (SQLException e) {
          //
       }
      
 }
   
   
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       //LISTA VISTA
   
    public ArrayList<schema_vista> getVistaList() throws SQLException {
        
       ArrayList<schema_vista> ViewList = new ArrayList<>();
       Connection con = getDefaultConnection();
       
       String query = "SELECT * FROM  VISTA ";
       Statement st;
       ResultSet rs;
       
       try {
           st = con.createStatement();
           rs = st.executeQuery(query);

           schema_vista view;

           while(rs.next())
           {
           view = new schema_vista(rs.getInt("id_vista"),rs.getString("nome"),rs.getString("descrizione"), rs.getString("codice_sql"), rs.getInt("id_db"));
               ViewList.add(view);
           }

       } 
      catch (SQLException e) {
       }
       return ViewList;
   }
       
 
       
  
     public void Show_View_In_JTable() throws SQLException
   {
       ArrayList<schema_vista> listav = getVistaList();
        DefaultTableModel model = (DefaultTableModel) jTable3.getModel();
       Object[] row = new Object[5];
       for(int i = 0; i < listav.size(); i++)
       {
           row[0] = listav.get(i).getId_vista();
           row[1] = listav.get(i).getNome();
           row[2] = listav.get(i).getDescrizione();
           row[3] = listav.get(i).getCodice_sql();
           row[4] = listav.get(i).getId_db();
           
           
           model.addRow(row);
       }}  
        
      
     
     //LISTA ASSERZIONI 
     
   
    public ArrayList<schema_asserzione> getAssertionList() throws SQLException {
        
       ArrayList<schema_asserzione> AssertionList = new ArrayList<>();
       Connection con = getDefaultConnection();
       
       String query = "SELECT * FROM  ASSERZIONE ";
       Statement st;
       ResultSet rs;
       
       try {
           st = con.createStatement();
           rs = st.executeQuery(query);

           schema_asserzione assertion;

           while(rs.next())
           {
           assertion = new schema_asserzione(rs.getInt("id_asserzione"),rs.getString("nome"), rs.getString("descrizione"), rs.getString("codice_sql"), rs.getInt("id_db"));
               AssertionList.add(assertion);
           }

       } 
      catch (SQLException e) {
       }
       return AssertionList;
   }
       
        
     
    //MOSTRA NELLA TABELLA I DB
 
  public void Show_Assertion_In_JTable() throws SQLException
   {
       ArrayList<schema_asserzione> list = getAssertionList();
        DefaultTableModel model = (DefaultTableModel) jTable6.getModel();
       Object[] row = new Object[5];
       for(int i = 0; i < list.size(); i++)
       {
           row[0] = list.get(i).getId_asserzione();
           row[1] = list.get(i).getNome();
           row[2] = list.get(i).getDescrizione();
           row[3] = list.get(i).getCodice_sql();
           row[4] = list.get(i).getId_db();
           
           model.addRow(row);
       }}    
     
     
     
     
     
     //MOSTRA I DB NELLA COMBO db asserzione
       public void Show_Db_In_JCombo3() throws SQLException
   {
       
       String query="SELECT id_db,nome FROM DATABASE ORDER BY id_db ASC";
       Statement st;
       ResultSet rs;
       
      try {
          Connection con= getDefaultConnection();
           st = con.createStatement();
           rs = st.executeQuery(query);
           textDbAssertion.addItem("Seleziona");
           while(rs.next()) {
           textDbAssertion.addItem(rs.getString("id_db") + ":" +rs.getString("nome")); 
             }    
           
       } 
      catch (SQLException e) {
              
              }}
       
      
      //RICERCA VELOCE ASSERZIONE
      public void Search_Assertion_in_JTable1(JTable table,String valueToSearch) throws SQLException{
   Connection con = getDefaultConnection();
       
       String query = "SELECT * FROM ASSERZIONE WHERE id_asserzione LIKE '%"+valueToSearch+"%'OR nome LIKE '%"+valueToSearch+"%' OR descrizione LIKE '%"+valueToSearch+"%' OR codice_sql LIKE '%"+valueToSearch+"%' OR id_db LIKE '%"+valueToSearch+"%'" ;
     
       
       Statement st;
       ResultSet rs;
       
       try {
           st = con.createStatement();
           rs = st.executeQuery(query);
           DefaultTableModel model= (DefaultTableModel)table.getModel();
           Object[] row;
           while(rs.next()){
           row=new Object[5];
           row[0]= rs.getInt(1);
           row[1]= rs.getString(2);
           row[2]= rs.getString(3);
            row[3]= rs.getString(4);
           row[4]= rs.getInt(5);
           
           model.addRow(row);
           
           
           }
  } 
      catch (SQLException e) {
          //
       }
      
 }
       
       
       
       
       
       
       
       
       
      
      
      
      
      
      
      //LISTA SPROCEDURE IN TABELLA
  
    
     
    public ArrayList<schema_procedura> getSProcedureList() throws SQLException {
    
       ArrayList<schema_procedura> SProcedureList = new ArrayList<>();
       Connection con = getDefaultConnection();
       
       String query = "SELECT * FROM  PROCEDURA ";
       Statement st;
       ResultSet rs;
       
       try {
           st = con.createStatement();
           rs = st.executeQuery(query);

           schema_procedura SProcedura;

           while(rs.next())
           {
           SProcedura = new schema_procedura(rs.getInt("id_procedura"),rs.getString("nome"), rs.getString("descrizione"), rs.getString("codice_sql"), rs.getInt("id_db"));
               SProcedureList.add(SProcedura);
           }

       } 
      catch (SQLException e) {
       }
       return SProcedureList;
   }
       
        
     
    //MOSTRA NELLA TABELLA I DB
 
  public void Show_SProcedure_In_JTable() throws SQLException
   {
       ArrayList<schema_procedura> list = getSProcedureList();
        DefaultTableModel model = (DefaultTableModel) jTable7.getModel();
       Object[] row = new Object[5];
       for(int i = 0; i < list.size(); i++)
       {
           row[0] = list.get(i).getId_procedura();
           row[1] = list.get(i).getNome();
           row[2] = list.get(i).getDescrizione();
           row[3] = list.get(i).getCodice_sql();
           row[4] = list.get(i).getId_db();
           
           model.addRow(row);
       }}    
     
     
     
     
     
     //MOSTRA I DB NELLA COMBO DB  
       public void Show_Db_In_JComboSProcedure() throws SQLException
   {
       
       String query="SELECT id_db,nome FROM DATABASE ORDER BY id_db ASC";
       Statement st;
       ResultSet rs;
       
      try {
          Connection con= getDefaultConnection();
           st = con.createStatement();
           rs = st.executeQuery(query);
            jComboBoxDbProcedura.addItem("Seleziona");
           while(rs.next()) {
           jComboBoxDbProcedura.addItem(rs.getString("id_db")+":"+rs.getString("nome")); 
            
           
           }    
           
       } 
      catch (SQLException e) {
              
              }
       }
      
      
      //RIEMPI COMBO TABELLA DI TRIGGERS
      public void Show_Table_In_JComboTriggers()
      
      {
       
       String query="SELECT id_tabella,nome FROM tabella ORDER BY id_tabella ASC";
       Statement st;
       ResultSet rs;
       
      try {
          Connection con= getDefaultConnection();
           st = con.createStatement();
           rs = st.executeQuery(query);
            jComboBoxTriggerTabella.addItem("Seleziona");
           while(rs.next()) {
           jComboBoxTriggerTabella.addItem(rs.getString("id_tabella")+ ":"+rs.getString("nome")); 
           
           }    
           

       } 
      catch (SQLException e) {
              
              }
       }
      
      
      
      
    //RIEMPI COMBO VISTA DI TRIGGERS  
      public void Show_View_In_JComboTriggers()
      
      {
       
       String query="SELECT id_vista,nome FROM VISTA ORDER BY id_vista ASC ";
       Statement st;
       ResultSet rs;
       
      try {
          Connection con= getDefaultConnection();
           st = con.createStatement();
           rs = st.executeQuery(query);
          jComboBoxTriggerVista.addItem("Seleziona");
           while(rs.next()) {
           jComboBoxTriggerVista.addItem(rs.getString("id_vista")+ ":" +rs.getString("nome")); 
           
           }    
           

       } 
      catch (SQLException e) {
              
              }
       }
      
      
      //effettuo ricerca veloce su vista
      public void Search_View_in_JTable1(JTable table,String valueToSearch) throws SQLException{
   Connection con = getDefaultConnection();
       
       String query = "SELECT * FROM VISTA WHERE id_vista LIKE '%"+valueToSearch+"%'OR nome LIKE '%"+valueToSearch+"%' OR descrizione LIKE '%"+valueToSearch+"%' OR codice_sql LIKE '%"+valueToSearch+"%' OR id_db LIKE '%"+valueToSearch+"%'" ;
     
       
       Statement st;
       ResultSet rs;
       
       try {
           st = con.createStatement();
           rs = st.executeQuery(query);
           DefaultTableModel model= (DefaultTableModel)table.getModel();
           Object[] row;
           while(rs.next()){
           row=new Object[5];
           row[0]= rs.getInt(1);
           row[1]= rs.getString(2);
           row[2]= rs.getString(3);
            row[3]= rs.getString(4);
           row[4]= rs.getInt(5);
           
           model.addRow(row);
           
           
           }
  } 
      catch (SQLException e) {
          //
       }
      
 } 
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      //LISTA TRIGGERS
  
    
     
    public ArrayList<schema_trigger> getTriggerList() throws SQLException {
    
       ArrayList<schema_trigger> TriggerList = new ArrayList<>();
       Connection con = getDefaultConnection();
       
       String query = "SELECT * FROM  TRIGGERS ";
       Statement st;
       ResultSet rs;
       
       try {
           st = con.createStatement();
           rs = st.executeQuery(query);

           schema_trigger Trigger;

           while(rs.next())
           {
           Trigger = new schema_trigger(rs.getInt("id_trigger"),rs.getString("nome"), rs.getString("descrizione"), rs.getString("codice_sql"), rs.getInt("id_tabella"), rs.getInt("id_vista"));
               TriggerList.add(Trigger);
           }

       } 
      catch (SQLException e) {
       }
       return TriggerList;
   }
       
        
     
    //MOSTRA NELLA TABELLA I DB
 
  public void Show_Trigger_In_JTable() throws SQLException
   {
       ArrayList<schema_trigger> list = getTriggerList();
        DefaultTableModel model = (DefaultTableModel) jTable5.getModel();
       Object[] row = new Object[6];
       for(int i = 0; i < list.size(); i++)
       {
           row[0] = list.get(i).getId_trigger();
           row[1] = list.get(i).getNome();
           row[2] = list.get(i).getDescrizione();
           row[3] = list.get(i).getCodice_sql();
           row[4] = list.get(i).getId_tabella();
           row[5] = list.get(i).getId_vista();
           
           model.addRow(row);
       }}    
     
    
  
  //ricerca trigger veloce
  public void Search_Trigger_in_JTable5( JTable table, String valueToSearch) throws SQLException{
  
  Connection con = getDefaultConnection();
       
       String query = "SELECT * FROM  TRIGGERS WHERE id_tabella LIKE '%"+valueToSearch+"%'OR nome LIKE '%"+valueToSearch+"%' OR descrizione LIKE '%"+valueToSearch+"%' OR codice_sql LIKE '%"+valueToSearch+"%'OR id_vista LIKE '%"+valueToSearch+"%'OR id_tabella LIKE '%"+valueToSearch+"%'" ;
     
       
       Statement st;
       ResultSet rs;
       
       try {
           st = con.createStatement();
           rs = st.executeQuery(query);
           DefaultTableModel model= (DefaultTableModel)table.getModel();
           Object[] row;
           while(rs.next()){
           row=new Object[6];
           row[0]= rs.getInt(1);
           row[1]= rs.getString(2);
           row[2]= rs.getString(3);
           row[3]= rs.getString(4);
           row[4]= rs.getInt(5);
           row[5]= rs.getInt(6);
           model.addRow(row);
           
           
           }
  } 
      catch (SQLException e) {
          //
       }
  
  
  
  
  }
  
  
  
  
  
  //LISTA ATTRIBUTI
   
    public ArrayList<schema_attributo> getAttributoList() throws SQLException {
        
       ArrayList<schema_attributo> AttributoList = new ArrayList<>();
       Connection con = getDefaultConnection();
       
       String query = "SELECT * FROM  ATTRIBUTO ";
       Statement st;
       ResultSet rs;
       
       try {
           st = con.createStatement();
           rs = st.executeQuery(query);

           schema_attributo attributo;

           while(rs.next())
           {
               
          
               
         attributo= new schema_attributo(rs.getInt("id_attributo"), rs.getString("Nome"), rs.getString("Defoult"),rs.getInt("id_tabella"),rs.getInt("id_dominio"),rs.getString("PK"),rs.getString("nome_pk"),rs.getInt("posizione_pk"));
               AttributoList.add(attributo);
           }

       } 
      catch (SQLException e) {
       }
       return AttributoList;
   }  
       
        
 
 //MOSTRA NELLA TABELLA attributi
 
   public void Show_Attribute_In_JTable() throws SQLException
   {
       
       
       ArrayList<schema_attributo> list = getAttributoList();
        DefaultTableModel model = (DefaultTableModel) jTable10.getModel();
       Object[] row = new Object[8];
       for(int i = 0; i < list.size(); i++)
       {
           
           
           row[0] = list.get(i).getId_attributo();
           row[1] = list.get(i).getNome();
           row[2] = list.get(i).getDefoult();
           row[3] = list.get(i).getId_tabella();
           row[4] = list.get(i).getId_dominio();
           row[5] = list.get(i).getPK();
           row[6] = list.get(i).getNome_pk();
           row[7] = list.get(i).getPosizione_pk();
           
         
           model.addRow(row);
       }}
   
    
   //ricerca attributo veloce
  public void  Search_Attribute_in_JTable10( JTable table, String valueToSearch) throws SQLException{
  
  Connection con = getDefaultConnection();
       
       String query = "SELECT * FROM  ATTRIBUTO WHERE id_attributo LIKE '%"+valueToSearch+"%'OR Nome LIKE '%"+valueToSearch+"%' OR Defoult LIKE '%"+valueToSearch+"%' OR id_tabella LIKE '%"+valueToSearch+"%'OR id_dominio LIKE '%"+valueToSearch+"%'OR PK LIKE '%"+valueToSearch+"%'OR nome_pk LIKE '%"+valueToSearch+"%'OR posizione_pk LIKE '%"+valueToSearch+"%'" ;
     
       
       Statement st;
       ResultSet rs;
       
       try {
           st = con.createStatement();
           rs = st.executeQuery(query);
           DefaultTableModel model= (DefaultTableModel)table.getModel();
           Object[] row;
           while(rs.next()){
           row=new Object[8];
           row[0]= rs.getInt(1);
           row[1]= rs.getString(2);
           row[2]= rs.getString(3);
           row[3]= rs.getInt(4);
           row[4]= rs.getInt(5);
           row[5]= rs.getString(6);
           row[6]= rs.getString(7);
           row[7]= rs.getInt(8);
           model.addRow(row);
           
           
           }
  } 
      catch (SQLException e) {
          //
       }
  
  
  
  
  }
  
   
    //ricerca pk in search
  public void   Search_Pk_in_JTableSearch( JTable table, String valueToSearch) throws SQLException{
  
  Connection con = getDefaultConnection();
       
       String query = "SELECT * FROM  ATTRIBUTO WHERE PK= '"+valueToSearch+"'" ;
     
       
       Statement st;
       ResultSet rs;
       
       try {
           st = con.createStatement();
           rs = st.executeQuery(query);
           DefaultTableModel model= (DefaultTableModel)table.getModel();
           Object[] row;
           while(rs.next()){
           row=new Object[8];
           row[0]= rs.getInt(1);
           row[1]= rs.getString(2);
           row[2]= rs.getString(3);
           row[3]= rs.getInt(4);
           row[4]= rs.getInt(5);
           row[5]= rs.getString(6);
           row[6]= rs.getString(7);
           row[7]= rs.getInt(8);
           model.addRow(row);
           
           
           }
  } 
      catch (SQLException e) {
          //
       }
  
  
  
  
  }
   
   
   
  
   
   //RIEMPI COMBO TABELLA IN ATTRIBUTO
    public void Show_Table_In_JComboAttribute()
      
      {
       
       String query="SELECT id_tabella,nome FROM tabella ORDER BY id_tabella ASC ";
       Statement st;
       ResultSet rs;
       
      try {
          Connection con= getDefaultConnection();
           st = con.createStatement();
           rs = st.executeQuery(query);
          
           while(rs.next()) {
           comboRTabella.addItem(rs.getString("id_tabella")+ ":"+rs.getString("nome")); 
           
           }    
           

       } 
      catch (SQLException e) {
              
              }
       }
   
    
    
    //RIEMPI COMBO RTABELLA IN FK
    public void Show_Attribute_In_JComboAttribute()
      
      {
       //funzione split();
           
          String str= comboRTabella.getSelectedItem().toString();
          String[] strSplit= str.split(":");
          String p1= strSplit[0];
     
         
         int intero= Integer.parseInt(p1);
         
         
         
       String query="SELECT id_attributo,Nome FROM ATTRIBUTO WHERE PK='*' AND id_tabella= "+intero+" ORDER BY id_attributo ASC";
       System.out.println(intero);
       Statement st;
       ResultSet rs;
       
      try {
          Connection con= getDefaultConnection();
           st = con.createStatement();
           rs = st.executeQuery(query);
           while(rs.next()) {
           comboRAttributo.addItem(rs.getString("id_attributo")+ ":"+rs.getString("Nome")); 
           
           }    
           

       } 
      catch (SQLException e) {
              
              }
       }
    
    
    
   
    
    
   
   public void RiempiRAttributo(){
       
     String s = "Seleziona";
      String t= comboRTabella.getSelectedItem().toString();
      
   

        if(!t.equals(s)){
            System.out.println("STRINGA diversa da SELEZIONA");
            comboRAttributo.enable();
            Show_Attribute_In_JComboAttribute();
        }
        else  if(t.equals(s)){
                     System.out.println("STRINGA =  SELEZIONA");
                             comboRAttributo.disable();
        
    }
}
   
   
   
  
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
  
   
   
   
   
   
   
   //LISTA fk in table
   
    public ArrayList<schema_fk> getFkList() throws SQLException {
        
       ArrayList<schema_fk> FkList = new ArrayList<>();
       Connection con = getDefaultConnection();
       
       String query = "SELECT * FROM FOREIGNKEY ";
       Statement st;
       ResultSet rs;
       
       try {
           st = con.createStatement();
           rs = st.executeQuery(query);

           schema_fk fk;

           while(rs.next())
           {
               
          
               
         fk= new schema_fk(rs.getString("Nome_fk"), rs.getInt("id_tabella"), rs.getInt("id_attributo"),rs.getInt("RTabella"),rs.getInt("RAttributo"),rs.getInt("posizione"));
               FkList.add(fk);
           }

       } 
      catch (SQLException e) {
       }
       return FkList;
   }  
       
        
 
 //MOSTRA LE FOREIGN KEY NELLA TABELLA IN OUTPUT TABELLAFK
 
   public void Show_Fk_In_JTable() throws SQLException
   {
       ArrayList<schema_fk> list = getFkList();
        DefaultTableModel model = (DefaultTableModel) tabellaFk.getModel();
       Object[] row = new Object[6];
       for(int i = 0; i < list.size(); i++)
       {
           
           
           row[0] = list.get(i).getNome_fk();
           row[1] = list.get(i).getId_tabella();
           row[2] = list.get(i).getId_attributo();
           row[3] = list.get(i).getRTabella();
           row[4] = list.get(i).getRAttributo();
           row[5] = list.get(i).getPosizione();
           
           model.addRow(row);
       }
   }
   
   
   
   
   
   //RIEMPO COMBO TABELLA DI FK
   public void Show_Table_In_JComboTabellaAttribute()
      
      {
       
       String query="SELECT id_tabella,nome FROM tabella ORDER BY id_tabella ASC ";
       Statement st;
       ResultSet rs;
       
      try {
          Connection con= getDefaultConnection();
           st = con.createStatement();
           rs = st.executeQuery(query);
           textTabellaFk.addItem("Seleziona"); 
           while(rs.next()) {
           textTabellaFk.addItem(rs.getString("id_tabella")+ ":"+rs.getString("nome")); 
           
           }    
           

       } 
      catch (SQLException e) {
              
              }
       }
   
   
   
   //MOSTRA COMBO TABELLA DI FK
    public void Show_Attribute_In_JComboAttributes()
      
      {
       //funzione split();
           
          String str= textTabellaFk.getSelectedItem().toString();
          String[] strSplit= str.split(":");
          String p1= strSplit[0];
     
         
         int intero= Integer.parseInt(p1);
         
         
         
       String query="SELECT id_attributo,Nome FROM ATTRIBUTO WHERE PK='*' AND id_tabella= "+intero+" ORDER BY id_attributo";
       System.out.println(intero);
       Statement st;
       ResultSet rs;
       
      try {
          Connection con= getDefaultConnection();
           st = con.createStatement();
           rs = st.executeQuery(query);
           textAttributoFk.addItem("Seleziona");
           while(rs.next()) {
           textAttributoFk.addItem(rs.getString("id_attributo")+ ":"+rs.getString("Nome")); 
           
           }    
           

       } 
      catch (SQLException e) {
              
              }
       }
   
   
   
   
   
   
    public void RiempiTextAttributo(){
       
     String s = "Seleziona";
      String t= textTabellaFk.getSelectedItem().toString();
      
   

        if(!t.equals(s)){
            System.out.println("STRINGA diversa da SELEZIONA");
            textAttributoFk.enable();
            Show_Attribute_In_JComboAttributes();
        }
        else  if(t.equals(s)){
                     System.out.println("STRINGA =  SELEZIONA");
                             textAttributoFk.disable();
        
    }
}
   
   
   //Ricerca veloce Fk
  
    public void Search_FK_in_JTableFk (JTable table,String valueToSearch ) throws SQLException{
   
   Connection con = getDefaultConnection();
       
      String query = "SELECT * FROM FOREIGNKEY WHERE Nome_fk LIKE '%"+valueToSearch+"%' OR id_tabella LIKE '%"+valueToSearch+"%' OR id_attributo LIKE '%"+valueToSearch+"%' OR RTabella LIKE '%"+valueToSearch+"%' OR RAttributo LIKE '%"+valueToSearch+"%' OR posizione LIKE '%"+valueToSearch+"%'";
     
       
       Statement st;
       ResultSet rs;
       
       try {
           st = con.createStatement();
           rs = st.executeQuery(query);
           DefaultTableModel model= (DefaultTableModel)table.getModel();
           Object[] row;
           while(rs.next()){
           row=new Object[6];
           row[0]= rs.getString(1);
           row[1]= rs.getInt(2);
           row[2]= rs.getInt(3);
           row[3]= rs.getInt(4);
           row[4]= rs.getInt(5);
           row[5]= rs.getInt(6);
          
           model.addRow(row);
           
           
           }
  } 
      catch (SQLException e) {
          //
       }
  
  
  
   
   
   }
   
    
   
   
   
   
   
   //RIEMPI COMBO TABELLA DI CHECK
   public void Show_Table_In_JComboCheck()
      
      {
       
       String query="SELECT id_tabella,nome FROM tabella ";
       Statement st;
       ResultSet rs;
       
      try {
          Connection con= getDefaultConnection();
           st = con.createStatement();
           rs = st.executeQuery(query);
           tabellaCheck.addItem("Seleziona");
           while(rs.next()) {
           tabellaCheck.addItem(rs.getString("id_tabella")+ ":"+rs.getString("nome")); 
           
           }    
           

       } 
      catch (SQLException e) {
              
              }
       }
   
    
   //RIEMPI COMBO ATTRIBUTO DI CHECK
    public void Show_Attribute_In_JComboCheck()
      
      {
       //funzione split();
           
          String str= tabellaCheck.getSelectedItem().toString();
          String[] strSplit= str.split(":");
          String p1= strSplit[0];
     
         
         int intero= Integer.parseInt(p1);
         
         
         
       String query="SELECT id_attributo,Nome FROM ATTRIBUTO WHERE id_tabella= "+intero;
       System.out.println(intero);
       Statement st;
       ResultSet rs;
       
      try {
          Connection con= getDefaultConnection();
           st = con.createStatement();
           rs = st.executeQuery(query);
           attributoCheck.addItem("Seleziona");
           while(rs.next()) {
           attributoCheck.addItem(rs.getString("id_attributo")+ ":"+rs.getString("Nome")); 
           
           }    
           

       } 
      catch (SQLException e) {
              
              }
       }
    
    
    
   
    
    
   
   public void RiempiAttributoCheck(){
       
     String s = "Seleziona";
      String t= tabellaCheck.getSelectedItem().toString();
      
   

        if(!t.equals(s)){
            System.out.println("STRINGA diversa da SELEZIONA");
            attributoCheck.enable();
            Show_Attribute_In_JComboCheck();
        }
        else  if(t.equals(s)){
                     System.out.println("STRINGA =  SELEZIONA");
                             attributoCheck.disable();
        
    }
}
   
   
   
   
   





 //LISTA DOMINI in tabella
   
    public ArrayList<schema_dominio> getDominioList() throws SQLException {
        
       ArrayList<schema_dominio> DominioList = new ArrayList<>();
       Connection con = getDefaultConnection();
       
       String query = "SELECT * FROM  DOMINIO ";
       Statement st;
       ResultSet rs;
       
       try {
           st = con.createStatement();
           rs = st.executeQuery(query);

           schema_dominio dominio;

           while(rs.next())
           {
           dominio = new schema_dominio(rs.getInt("id_dominio"),rs.getString("nome"),rs.getString("descrizione"), rs.getString("formato"));
               DominioList.add(dominio);
           }

       } 
      catch (SQLException e) {
       }
       return DominioList;
   }
       
 
       
  //MOSTRA DOMINI NELLA TABELLA DI OUTPUT JTABLE11
     public void Show_Dominio_In_JTable() throws SQLException
   {
       ArrayList<schema_dominio> list = getDominioList();
        DefaultTableModel model = (DefaultTableModel) jTable11.getModel();
       Object[] row = new Object[4];
       for(int i = 0; i < list.size(); i++)
       {
           row[0] = list.get(i).getId_dominio();
           row[1] = list.get(i).getNome();
           row[2] = list.get(i).getDescrizione();
           row[3] = list.get(i).getFormato();
         
           model.addRow(row);
       }}  
        




//MOSTRA I FORMATI NELLA JCOMBO FORMATO
       public void Show_Formato_In_JCombo() throws SQLException
   {
       
       
           textStandard.addItem("Int"); 
           textStandard.addItem("String");
           textStandard.addItem("Data");
     
   }
      
      

       
       
       


   //effettua ricerca veloce dominio
   public void Search_Domain_in_JTable11(JTable table,String valueToSearch ) throws SQLException{
   
   Connection con = getDefaultConnection();
       
       String query = "SELECT * FROM  DOMINIO WHERE id_dominio LIKE '%"+valueToSearch+"%'OR nome LIKE '%"+valueToSearch+"%' OR descrizione LIKE '%"+valueToSearch+"%' OR formato LIKE '%"+valueToSearch+"%'" ;
     
       
       Statement st;
       ResultSet rs;
       
       try {
           st = con.createStatement();
           rs = st.executeQuery(query);
           DefaultTableModel model= (DefaultTableModel)table.getModel();
           Object[] row;
           while(rs.next()){
           row=new Object[4];
           row[0]= rs.getInt(1);
           row[1]= rs.getString(2);
           row[2]= rs.getString(3);
           row[3]= rs.getString(4);
          
           model.addRow(row);
           
           
           }
  } 
      catch (SQLException e) {
          //
       }
  
  
  
   
   
   }
   
   
   
   
   
   
   
   
   //MOSTRA NELLA COMBO ATTRIBUTI I NOMI DELLE TABELLE
   public void Show_Table_In_JComboAttributo()
      
      {
       
       String query="SELECT * FROM tabella ORDER BY id_tabella ASC";
       Statement st;
       ResultSet rs;
       
      try {
          Connection con= getDefaultConnection();
           st = con.createStatement();
           rs = st.executeQuery(query);
            jComboBoxAttributoTabella.addItem("Seleziona"); 
           while(rs.next()) {
           jComboBoxAttributoTabella.addItem(rs.getInt("id_tabella")+ ":"+rs.getString("nome")); 
           
           
           }    
           

       } 
      catch (SQLException e) {
              
              }
       }
   
   
   
   //RIEMPI COMBO DOMINIO DI ATTRIBUTO
   
   public void Show_Domain_In_JComboAttributoDomain()
      
      {
       
       String query="SELECT * FROM Dominio ORDER BY id_dominio ASC";
       Statement st;
       ResultSet rs;
       
      try {
          Connection con= getDefaultConnection();
           st = con.createStatement();
           rs = st.executeQuery(query);
           jComboBoxAttributoDominio.addItem("Seleziona"); 
           while(rs.next()) {
           jComboBoxAttributoDominio.addItem(rs.getInt("id_dominio")+ ":"+rs.getString("nome")); 
           
           
           }    
           

       } 
      catch (SQLException e) {
              
              }
       }
   
      
   
   
   
   //RIEMPI COMBO DB DI PROCEDURA
   
   public void Show_Db_In_JComboProcedura() throws SQLException
   {
       
       String query="SELECT id_db,nome FROM DATABASE ORDER BY id_db";
       Statement st;
       ResultSet rs;
       
      try {
          Connection con= getDefaultConnection();
           st = con.createStatement();
           rs = st.executeQuery(query);
           jComboBoxDbProcedura.addItem("Seleziona"); 
           while(rs.next()) {
            jComboBoxDbProcedura.addItem(rs.getString("id_db")+":" +rs.getString("nome")); 
           
           
           }    
           

       } 
      catch (SQLException e) {
              
              }
       }
      
      
   
  //ricerca veloce procedura 
   public void Search_SProcedure_in_JTable7(JTable table,String valueToSearch ) throws SQLException{
   
   Connection con = getDefaultConnection();
       
       String query = "SELECT * FROM PROCEDURA WHERE id_procedura LIKE '%"+valueToSearch+"%'OR nome LIKE '%"+valueToSearch+"%' OR descrizione LIKE '%"+valueToSearch+"%' OR codice_sql LIKE '%"+valueToSearch+"%' OR id_db LIKE '%"+valueToSearch+"%'" ;
     
       
       Statement st;
       ResultSet rs;
       
       try {
           st = con.createStatement();
           rs = st.executeQuery(query);
           DefaultTableModel model= (DefaultTableModel)table.getModel();
           Object[] row;
           while(rs.next()){
           row=new Object[5];
           row[0]= rs.getInt(1);
           row[1]= rs.getString(2);
           row[2]= rs.getString(3);
           row[3]= rs.getString(4);
           row[4]= rs.getInt(5);
          
           model.addRow(row);
           
           
           }
  } 
      catch (SQLException e) {
          //
       }
  
  
  
   
   
   }
   
   
  
   
   
   // LISTA UTENTI SECONDO LO SCHEMA_UTENTE
   
   public ArrayList<schema_utente> getUserList() throws SQLException {
        
       ArrayList<schema_utente> UserList = new ArrayList<>();
       Connection con = getDefaultConnection();
       
       String query = "SELECT * FROM UTENTE  ";
       Statement st;
       ResultSet rs;
       
       try {
           st = con.createStatement();
           rs = st.executeQuery(query);

           schema_utente utente;

           while(rs.next())
           {
           utente = new schema_utente(rs.getString("username"),rs.getString("nome"),rs.getString("cognome"),rs.getString("email"),rs.getString("password"));
               UserList.add(utente);
           }

       } 
      catch (SQLException e) {
       }
       return UserList;
   }  
   
   
 // MOSTRO UTENTI NELLA TABELLA IN OUTPUT JTABLEUTENTEE  
     public void Show_User_In_JTable() throws SQLException
   {
       ArrayList<schema_utente> list = getUserList();
        DefaultTableModel model = (DefaultTableModel) jTableUtente.getModel();
       Object[] row = new Object[5];
       for(int i = 0; i < list.size(); i++)
       {
           row[0] = list.get(i).getUsername();
           row[1] = list.get(i).getNome();
           row[2] = list.get(i).getCognome();
           row[3] = list.get(i).getEmail();
           row[4] = list.get(i).getPassword();
         
           model.addRow(row);
       }}  
   
   
     
     
 //RICERCA VELOCE UTENTI
      public void Search_User_in_JTable1(JTable table,String valueToSearch) throws SQLException{
   Connection con = getDefaultConnection();
       
       String query = "SELECT * FROM UTENTE WHERE username LIKE '%"+valueToSearch+"%'OR nome LIKE '%"+valueToSearch+"%' OR cognome LIKE '%"+valueToSearch+"%' OR email LIKE '%"+valueToSearch+"%' OR password LIKE '%"+valueToSearch+"%'" ;
     
       
       Statement st;
       ResultSet rs;
       
       try {
           st = con.createStatement();
           rs = st.executeQuery(query);
           DefaultTableModel model= (DefaultTableModel)table.getModel();
           Object[] row;
           while(rs.next()){
           row=new Object[5];
           row[0]= rs.getString(1);
           row[1]= rs.getString(2);
           row[2]= rs.getString(3);
            row[3]= rs.getString(4);
           row[4]= rs.getString(5);
           
           model.addRow(row);
           
           
           }
  } 
      catch (SQLException e) {
          //
       }
      
 }
   
 
      
        //LISTA check in table
   
    public ArrayList<schema_check> getCheckList() throws SQLException {
        
       ArrayList<schema_check> checkList = new ArrayList<>();
       Connection con = getDefaultConnection();
       
       String query = "SELECT * FROM VCHECK ";
       Statement st;
       ResultSet rs;
       
       try {
           st = con.createStatement();
           rs = st.executeQuery(query);

           schema_check vcheck;

           while(rs.next())
           {
               
           
         vcheck= new schema_check(rs.getString("nome"), rs.getString("descrizione"), rs.getInt("id_attributo"),rs.getString("codice_sql"));
               checkList.add(vcheck);
           }

       } 
      catch (SQLException e) {
       }
       return checkList;
   }  
       
        
 
 //MOSTRA check in JTABLE
 
   public void Show_Check_In_JTable() throws SQLException
   {
       ArrayList<schema_check> list = getCheckList();
        DefaultTableModel model = (DefaultTableModel)jTableCheck.getModel();
       Object[] row = new Object[4];
       for(int i = 0; i < list.size(); i++)
       {
           
           
           row[0] = list.get(i).getNome();
           row[1] = list.get(i).getDescrizione();
           row[2] = list.get(i).getId_attributo();
           row[3] = list.get(i).getCodice_sql();
         
           
           model.addRow(row);
       }
   }
   
   
   
   
   //effettua ricerca check
   
   
     public void RicercaCheck(JTable table,String valueToSearch) throws SQLException{
 
 Connection con = getDefaultConnection();
       
       String query = "SELECT * FROM  VCHECK WHERE nome LIKE '%"+valueToSearch+"%' OR id_attributo LIKE '%"+valueToSearch+"%'";
     
       
       Statement st;
       ResultSet rs;
       
       try {
           st = con.createStatement();
           rs = st.executeQuery(query);
           DefaultTableModel model= (DefaultTableModel)table.getModel();
           Object[] row;
           while(rs.next()){
           row=new Object[4];
           row[0]= rs.getString(1);
           row[1]= rs.getString(2);
           row[2]= rs.getInt(3);
           row[3]= rs.getString(4);
           model.addRow(row);
           
           
           }
  } 
      catch (SQLException e) {
          //
       }
      
 } 
      
      
  
     //RIEMPI COMBO TABELLA DI SEQUENZA
   
   public void Show_Table_In_JComboSequenza()
      
      {
       
       String query="SELECT id_tabella,nome FROM tabella ORDER BY id_tabella ASC ";
       Statement st;
       ResultSet rs;
       
      try {
          Connection con= getDefaultConnection();
           st = con.createStatement();
           rs = st.executeQuery(query);
           tabellaSequenza.addItem("Seleziona");
           while(rs.next()) {
           tabellaSequenza.addItem(rs.getString("id_tabella")+ ":"+rs.getString("nome")); 
           
           }    
           

       } 
      catch (SQLException e) {
              
              }
       }
   
    
   
   //RIEMPI COMBO ATTRIBUTO IN SEQUENZA
    public void Show_Attribute_In_JComboSequenza()
      
      {
       //funzione split();
           
          String str= tabellaSequenza.getSelectedItem().toString();
          String[] strSplit= str.split(":");
          String p1= strSplit[0];
     
         
         int intero= Integer.parseInt(p1);
         
         
         
       String query="SELECT id_attributo,Nome FROM ATTRIBUTO WHERE id_tabella= "+intero+" ORDER BY id_attributo ASC";
       System.out.println(intero);
       Statement st;
       ResultSet rs;
       
      try {
          Connection con= getDefaultConnection();
           st = con.createStatement();
           rs = st.executeQuery(query);
           attributoSequenza.addItem("Seleziona");
           while(rs.next()) {
           attributoSequenza.addItem(rs.getString("id_attributo")+ ":"+rs.getString("Nome")); 
           
           }    
           

       } 
      catch (SQLException e) {
              
              }
       }
    
    
    
   
    
    
   public void RiempiAttributoSequenza(){
       
     String s = "Seleziona";
      String t= tabellaSequenza.getSelectedItem().toString();
      
   

        if(!t.equals(s)){
            System.out.println("STRINGA diversa da SELEZIONA");
            attributoSequenza.enable();
            Show_Attribute_In_JComboSequenza();
        }
        else  if(t.equals(s)){
                     System.out.println("STRINGA =  SELEZIONA");
                            attributoSequenza.disable();
        
    }
}
   
   
   
   
   
      // LISTA SEQUENZA
   
   public ArrayList<schema_sequenza> getSequenzaList() throws SQLException {
        
       ArrayList<schema_sequenza> sequenzaList = new ArrayList<>();
       Connection con = getDefaultConnection();
       
       String query;
         query = "SELECT * FROM SEQUENZA";
       Statement st;
       ResultSet rs;
       
       try {
           st = con.createStatement();
           rs = st.executeQuery(query);

           schema_sequenza sequenza;

           while(rs.next())
           {
           sequenza = new schema_sequenza(rs.getString("nome"),rs.getInt("startwith"),rs.getInt("incremento"),rs.getInt("minval"),rs.getInt("maxval"),rs.getInt("id_attributo"));
              sequenzaList.add(sequenza);
           }

       } 
      catch (SQLException e) {
       }
       return sequenzaList;
   }  
   
   
   //MOSTRA SEQUENZE NELLE TABELLE IN OUTPUT JTABLESEQUENZA
     public void Show_Sequenza_In_JTable() throws SQLException
   {
       ArrayList<schema_sequenza> list = getSequenzaList();
        DefaultTableModel model = (DefaultTableModel)jTableSequenza.getModel();
       Object[] row = new Object[6];
       for(int i = 0; i < list.size(); i++)
       {
           row[0] = list.get(i).getNome();
           row[1] = list.get(i).getStartwith();
           row[2] = list.get(i).getIncremento();
           row[3] = list.get(i).getMinval();
           row[4] = list.get(i).getMaxval();
           row[5] = list.get(i).getId_attributo();
         
           model.addRow(row);
       }}  
   
   
     
     
      //MOSTRA GLI USER  NELLA COMBO USER DI PERMESSI
       public void Show_Users_In_JComboPermessi() throws SQLException
   {
       
       String query="SELECT username FROM UTENTE ORDER BY USERNAME ASC";
       Statement st;
       ResultSet rs;
       
      try {
          Connection con= getDefaultConnection();
           st = con.createStatement();
           rs = st.executeQuery(query);
           comboUsernamePermessi.addItem("Seleziona"); 
           while(rs.next()) {
           comboUsernamePermessi.addItem(rs.getString("username")); 
           
            
               
           
           }    
           

       } 
      catch (SQLException e) {
              
              }}
     
 //RIEMPI COMBO DB IN PERMESSI

        public void Show_Db_In_JComboPermessi() throws SQLException
   {
       
      String query="SELECT * FROM DATABASE ORDER BY id_db ASC";
       Statement st;
       ResultSet rs;
       
      try {
          Connection con= getDefaultConnection();
           st = con.createStatement();
           rs = st.executeQuery(query);
          comboDbPermessi.addItem("Seleziona"); 
           while(rs.next()) {
          comboDbPermessi.addItem(rs.getString("id_db")+":"+rs.getString("nome")); 
           
            
               
           
           }    
           

       } 
      catch (SQLException e) {
              
              }}
        
        
        
        
        
       
         // LISTA PERMESSI 
   
   public ArrayList<schema_accesso> getAccessList() throws SQLException {
        
       ArrayList<schema_accesso> accessList = new ArrayList<>();
       Connection con = getDefaultConnection();
       
       String query;
         query = "SELECT * FROM ACCESSO";
       Statement st;
       ResultSet rs;
       
       try {
           st = con.createStatement();
           rs = st.executeQuery(query);

           schema_accesso accesso;

           while(rs.next())
           {
           accesso = new schema_accesso(rs.getString("username"),rs.getString("accesso"),rs.getInt("id_db"));
              accessList.add(accesso);
           }

       } 
      catch (SQLException e) {
       }
       return accessList;
   }  
   
   
   //MOSTRA PERMESSI NELLE TABELLE IN OUTPUT JTABLEPERMESSI
     public void Show_Access_In_JTable() throws SQLException
   {
       ArrayList<schema_accesso> list = getAccessList();
        DefaultTableModel model = (DefaultTableModel)jTable4.getModel();
       Object[] row = new Object[3];
       for(int i = 0; i < list.size(); i++)
       {
           row[0] = list.get(i).getUsername();
           row[1] = list.get(i).getAccesso();
           row[2] = list.get(i).getId_db();
           
         
           model.addRow(row);
       }}  
     
     
     
     
     
     
     
     
     
        public void Search_Sequence_in_JTable1(JTable table,String valueToSearch) throws SQLException{
 
 Connection con = getDefaultConnection();
       
       String query = "SELECT * FROM SEQUENZA WHERE nome LIKE '%"+valueToSearch+"%' OR startwith LIKE '%"+valueToSearch+"%' OR incremento LIKE '%"+valueToSearch+"%' OR minval LIKE '%"+valueToSearch+"%' OR maxval LIKE '%"+valueToSearch+"%' OR id_attributo LIKE '%"+valueToSearch+"%'";
     
       
       Statement st;
       ResultSet rs;
       
       try {
           st = con.createStatement();
           rs = st.executeQuery(query);
           DefaultTableModel model= (DefaultTableModel)table.getModel();
           Object[] row;
           while(rs.next()){
           row=new Object[6];
           row[0]= rs.getString(1);
           row[1]= rs.getInt(2);
           row[2]= rs.getInt(3);
           row[3]= rs.getInt(4);
           row[4]= rs.getInt(5);
           row[5]= rs.getInt(6);
           model.addRow(row);
           
           
           }
  } 
      catch (SQLException e) {
          //
       }
      
 } 
     
     
     
     
     
   
   
        
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        RadioFormato = new javax.swing.ButtonGroup();
        buttonGroupVincoli = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        logo = new javax.swing.JLabel();
        jButton10 = new javax.swing.JButton();
        jPanel18 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        ntb = new javax.swing.JLabel();
        jPanel16 = new javax.swing.JPanel();
        nvst = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        ndb = new javax.swing.JLabel();
        jPanel20 = new javax.swing.JPanel();
        natt = new javax.swing.JLabel();
        BottomVista = new javax.swing.JButton();
        BottomDatabase = new javax.swing.JButton();
        BottomTabella = new javax.swing.JButton();
        BottomAttributo = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jPanel34 = new javax.swing.JPanel();
        ndmn = new javax.swing.JLabel();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel4 = new javax.swing.JPanel();
        label2 = new java.awt.Label();
        label3 = new java.awt.Label();
        jPanel3 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        textIdDb = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        textNomeDb = new javax.swing.JTextField();
        editDbBottom = new javax.swing.JButton();
        addDbBottom = new javax.swing.JButton();
        deleteDbBottom = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        JTable1 = new javax.swing.JTable();
        value = new javax.swing.JLabel();
        valueDb = new javax.swing.JTextField();
        jPanel6 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jPanel23 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        textNomeTabella = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jComboBox_db = new javax.swing.JComboBox<>();
        deleteTbBottom = new javax.swing.JButton();
        editDbBottom4 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        addtableBottom = new javax.swing.JButton();
        textIdTb = new javax.swing.JLabel();
        textIdTabella = new javax.swing.JTextField();
        value1 = new javax.swing.JLabel();
        valueTabella = new javax.swing.JTextField();
        jPanel10 = new javax.swing.JPanel();
        jScrollPane7 = new javax.swing.JScrollPane();
        jTable5 = new javax.swing.JTable();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        textNomeTrigger = new javax.swing.JTextField();
        jScrollPane15 = new javax.swing.JScrollPane();
        textDescrizioneTrigger = new javax.swing.JTextArea();
        jLabel30 = new javax.swing.JLabel();
        jScrollPane16 = new javax.swing.JScrollPane();
        textCodiceSqlTrigger = new javax.swing.JTextArea();
        jLabel31 = new javax.swing.JLabel();
        jComboBoxTriggerTabella = new javax.swing.JComboBox<>();
        addTriggerBottom = new javax.swing.JButton();
        editTriggerBottom = new javax.swing.JButton();
        deleteTriggerBottom = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        textIdTrigger = new javax.swing.JTextField();
        RadioTabella = new javax.swing.JRadioButton();
        RadioVista = new javax.swing.JRadioButton();
        jComboBoxTriggerVista = new javax.swing.JComboBox<>();
        valueTrigger = new javax.swing.JTextField();
        value2 = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jScrollPane8 = new javax.swing.JScrollPane();
        jTable6 = new javax.swing.JTable();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jScrollPane17 = new javax.swing.JScrollPane();
        textCodiceSqlAssertion = new javax.swing.JTextArea();
        jScrollPane18 = new javax.swing.JScrollPane();
        textDescrizioneAssertion = new javax.swing.JTextArea();
        textNomeAssertion = new javax.swing.JTextField();
        jLabel35 = new javax.swing.JLabel();
        editAssertionBottom = new javax.swing.JButton();
        deleteDbBottom5 = new javax.swing.JButton();
        textDbAssertion = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        addAssertionBottom = new javax.swing.JButton();
        jLabel41 = new javax.swing.JLabel();
        textIdAssertion = new javax.swing.JTextField();
        valueAssertion = new javax.swing.JTextField();
        RicercaAssertion = new javax.swing.JLabel();
        jPanel13 = new javax.swing.JPanel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        textUsername = new javax.swing.JTextField();
        textCognome = new javax.swing.JTextField();
        addUtente = new javax.swing.JButton();
        editUtente = new javax.swing.JButton();
        deleteUtente = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel52 = new javax.swing.JLabel();
        jLabel53 = new javax.swing.JLabel();
        textNome = new javax.swing.JTextField();
        textEmail = new javax.swing.JTextField();
        textPasswordUtente = new javax.swing.JPasswordField();
        ShowPassword = new javax.swing.JCheckBox();
        valueUser = new javax.swing.JTextField();
        jLabel27 = new javax.swing.JLabel();
        jScrollPane13 = new javax.swing.JScrollPane();
        jTableUtente = new javax.swing.JTable();
        jButton7 = new javax.swing.JButton();
        jPanel9 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        textNomeVista = new javax.swing.JTextField();
        textId_vista = new javax.swing.JTextField();
        jScrollPane4 = new javax.swing.JScrollPane();
        textDescrizioneVista = new javax.swing.JTextArea();
        jScrollPane5 = new javax.swing.JScrollPane();
        textCodiceSqlVista = new javax.swing.JTextArea();
        jLabel23 = new javax.swing.JLabel();
        jComboBoxDb2 = new javax.swing.JComboBox<>();
        addVistaBottom = new javax.swing.JButton();
        editVistaBottom = new javax.swing.JButton();
        deleteVistaBottom = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        valueVista = new javax.swing.JTextField();
        jLabel51 = new javax.swing.JLabel();
        jPanel24 = new javax.swing.JPanel();
        jScrollPane12 = new javax.swing.JScrollPane();
        jTable10 = new javax.swing.JTable();
        jLabel13 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        textIdAttributo = new javax.swing.JTextField();
        textNomeAttributo = new javax.swing.JTextField();
        jComboBoxDefaultAttributo = new javax.swing.JComboBox<>();
        jComboBoxAttributoTabella = new javax.swing.JComboBox<>();
        addAttributo = new javax.swing.JButton();
        editAttributo = new javax.swing.JButton();
        deleteAttributo = new javax.swing.JButton();
        jLabel50 = new javax.swing.JLabel();
        jComboBoxAttributoDominio = new javax.swing.JComboBox<>();
        jLabel17 = new javax.swing.JLabel();
        valueAttributo = new javax.swing.JTextField();
        jLabel55 = new javax.swing.JLabel();
        boxPk = new javax.swing.JRadioButton();
        boxFk = new javax.swing.JRadioButton();
        boxCheck = new javax.swing.JRadioButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        panelPk = new javax.swing.JPanel();
        jLabel61 = new javax.swing.JLabel();
        textNomePk = new javax.swing.JTextField();
        jLabel62 = new javax.swing.JLabel();
        comboPosizionePk = new javax.swing.JComboBox<>();
        panelFk = new javax.swing.JPanel();
        comboPosizioneFk = new javax.swing.JComboBox<>();
        jLabel66 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        nomeFkAttributo = new javax.swing.JTextField();
        jButton8 = new javax.swing.JButton();
        panelCheck = new javax.swing.JPanel();
        textDescrizioneCheck = new javax.swing.JTextField();
        jLabel68 = new javax.swing.JLabel();
        textNomeCheck = new javax.swing.JTextField();
        jLabel72 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jPanel28 = new javax.swing.JPanel();
        jPanel32 = new javax.swing.JPanel();
        pushKey = new javax.swing.JRadioButton();
        jPanel25 = new javax.swing.JPanel();
        jLabel45 = new javax.swing.JLabel();
        textIdDominio = new javax.swing.JTextField();
        textNomeDominio = new javax.swing.JTextField();
        jLabel46 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        textDescrizioneDominio = new javax.swing.JTextField();
        addDominio = new javax.swing.JButton();
        editDominio = new javax.swing.JButton();
        deleteDominio = new javax.swing.JButton();
        textStandard = new javax.swing.JComboBox<>();
        standard = new javax.swing.JRadioButton();
        personalizzato = new javax.swing.JRadioButton();
        jScrollPane10 = new javax.swing.JScrollPane();
        textPersonalizzato = new javax.swing.JTextArea();
        jLabel44 = new javax.swing.JLabel();
        jScrollPane21 = new javax.swing.JScrollPane();
        jTable11 = new javax.swing.JTable();
        valueDominio = new javax.swing.JTextField();
        jLabel54 = new javax.swing.JLabel();
        jPanel26 = new javax.swing.JPanel();
        jLabel75 = new javax.swing.JLabel();
        jLabel76 = new javax.swing.JLabel();
        nomeSequenza = new javax.swing.JTextField();
        jLabel77 = new javax.swing.JLabel();
        jLabel78 = new javax.swing.JLabel();
        jLabel79 = new javax.swing.JLabel();
        jLabel80 = new javax.swing.JLabel();
        jLabel81 = new javax.swing.JLabel();
        jLabel82 = new javax.swing.JLabel();
        iniziadaSequenza = new javax.swing.JTextField();
        incrementadiSequenza = new javax.swing.JTextField();
        valoremaxSequenza = new javax.swing.JTextField();
        valoreminSequenza = new javax.swing.JTextField();
        tabellaSequenza = new javax.swing.JComboBox<>();
        attributoSequenza = new javax.swing.JComboBox<>();
        addSequenza = new javax.swing.JButton();
        editSequenza = new javax.swing.JButton();
        deleteSequenza = new javax.swing.JButton();
        jScrollPane23 = new javax.swing.JScrollPane();
        jTableSequenza = new javax.swing.JTable();
        valueSequenza = new javax.swing.JTextField();
        jLabel83 = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();
        jScrollPane9 = new javax.swing.JScrollPane();
        jTable7 = new javax.swing.JTable();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        textIdProcedura = new javax.swing.JTextField();
        jScrollPane19 = new javax.swing.JScrollPane();
        textDescrizioneProcedura = new javax.swing.JTextArea();
        textNomeProcedura = new javax.swing.JTextField();
        jScrollPane20 = new javax.swing.JScrollPane();
        textCodiceSqlProcedura = new javax.swing.JTextArea();
        jComboBoxDbProcedura = new javax.swing.JComboBox<>();
        editProcedureBottom = new javax.swing.JButton();
        deleteProcedureBottom = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        addProcedureBottom = new javax.swing.JButton();
        valueProcedura = new javax.swing.JTextField();
        RicercaProcedure = new javax.swing.JLabel();
        jPanel21 = new javax.swing.JPanel();
        jLabel67 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTableCheck = new javax.swing.JTable();
        jLabel69 = new javax.swing.JLabel();
        jLabel70 = new javax.swing.JLabel();
        jLabel71 = new javax.swing.JLabel();
        jLabel73 = new javax.swing.JLabel();
        jLabel74 = new javax.swing.JLabel();
        nomeCheck = new javax.swing.JTextField();
        descrizioneCheck = new javax.swing.JTextField();
        jScrollPane22 = new javax.swing.JScrollPane();
        codiceSqlCheck = new javax.swing.JTextArea();
        attributoCheck = new javax.swing.JComboBox<>();
        addProcedureBottom1 = new javax.swing.JButton();
        deleteCheck = new javax.swing.JButton();
        tabellaCheck = new javax.swing.JComboBox<>();
        valueCheck = new javax.swing.JTextField();
        jLabel85 = new javax.swing.JLabel();
        jPanel27 = new javax.swing.JPanel();
        jLabel56 = new javax.swing.JLabel();
        jLabel57 = new javax.swing.JLabel();
        jLabel58 = new javax.swing.JLabel();
        jLabel59 = new javax.swing.JLabel();
        nomeFk = new javax.swing.JTextField();
        addFk = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jLabel60 = new javax.swing.JLabel();
        jLabel63 = new javax.swing.JLabel();
        jLabel64 = new javax.swing.JLabel();
        comboRAttributo = new javax.swing.JComboBox<>();
        comboPosAttributo = new javax.swing.JComboBox<>();
        textAttributoFk = new javax.swing.JComboBox<>();
        jScrollPane24 = new javax.swing.JScrollPane();
        tabellaFk = new javax.swing.JTable();
        textTabellaFk = new javax.swing.JComboBox<>();
        comboRTabella = new javax.swing.JComboBox<>();
        jLabel65 = new javax.swing.JLabel();
        valueFk = new javax.swing.JTextField();
        jPanel22 = new javax.swing.JPanel();
        jScrollPane11 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jComboBox1 = new javax.swing.JComboBox<>();
        jButton2 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jLabel84 = new javax.swing.JLabel();
        jPanel31 = new javax.swing.JPanel();
        jScrollPane14 = new javax.swing.JScrollPane();
        jTable4 = new javax.swing.JTable();
        jLabel21 = new javax.swing.JLabel();
        NomeUtente = new javax.swing.JLabel();
        database = new javax.swing.JLabel();
        Permesso = new javax.swing.JLabel();
        comboDbPermessi = new javax.swing.JComboBox<>();
        addSequenza1 = new javax.swing.JButton();
        editPermessi = new javax.swing.JButton();
        deletePermessi = new javax.swing.JButton();
        comboPermesso = new javax.swing.JComboBox<>();
        comboUsernamePermessi = new javax.swing.JComboBox<>();
        jPanel29 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        ntrg = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        nass = new javax.swing.JLabel();
        jPanel14 = new javax.swing.JPanel();
        nprd = new javax.swing.JLabel();
        BottomTrigger2 = new javax.swing.JButton();
        BottomProcedura2 = new javax.swing.JButton();
        BottomFunzione2 = new javax.swing.JButton();
        BottomSequenza = new javax.swing.JButton();
        jPanel35 = new javax.swing.JPanel();
        nsqz = new javax.swing.JLabel();
        BottomUtente = new javax.swing.JButton();
        jPanel17 = new javax.swing.JPanel();
        nusr = new javax.swing.JLabel();
        jPanel30 = new javax.swing.JPanel();
        jPanel19 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(178, 38, 38));
        jPanel1.setPreferredSize(new java.awt.Dimension(1230, 100));

        jButton1.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/home.png"))); // NOI18N
        jButton1.setText("HOME");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        logo.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 30)); // NOI18N
        logo.setForeground(new java.awt.Color(255, 255, 255));
        logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/logodatabase.png"))); // NOI18N
        logo.setText("GESTIONE METADATI");

        jButton10.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        jButton10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/search.png"))); // NOI18N
        jButton10.setText("RICERCA");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(169, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(164, 164, 164)
                .addComponent(logo)
                .addGap(190, 190, 190)
                .addComponent(jButton10)
                .addGap(151, 151, 151))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(logo, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addComponent(jButton10))
                    .addComponent(jButton1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(1, 1, 1))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1260, 100));

        jPanel18.setBackground(new java.awt.Color(178, 38, 38));
        jPanel18.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel16.setBackground(new java.awt.Color(255, 255, 255));
        jLabel16.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("© Coppola Luigi - N86001723 / Rauso Ciro - N86002443");
        jPanel18.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(367, 11, 680, -1));

        getContentPane().add(jPanel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 650, 1280, 60));

        jPanel7.setBackground(new java.awt.Color(178, 38, 38));

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ntb)
                .addContainerGap())
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ntb)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(nvst)
                .addContainerGap())
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(nvst)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ndb)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ndb)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel20Layout = new javax.swing.GroupLayout(jPanel20);
        jPanel20.setLayout(jPanel20Layout);
        jPanel20Layout.setHorizontalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel20Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(natt)
                .addContainerGap())
        );
        jPanel20Layout.setVerticalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel20Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(natt)
                .addContainerGap())
        );

        BottomVista.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 11)); // NOI18N
        BottomVista.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/vista.png"))); // NOI18N
        BottomVista.setText("VISTA");
        BottomVista.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BottomVista.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        BottomVista.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BottomVistaActionPerformed(evt);
            }
        });

        BottomDatabase.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 11)); // NOI18N
        BottomDatabase.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/Db.png"))); // NOI18N
        BottomDatabase.setText("DATABASE");
        BottomDatabase.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BottomDatabase.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        BottomDatabase.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BottomDatabaseActionPerformed(evt);
            }
        });

        BottomTabella.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 11)); // NOI18N
        BottomTabella.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/table.png"))); // NOI18N
        BottomTabella.setText("TABELLA");
        BottomTabella.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BottomTabella.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        BottomTabella.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BottomTabellaActionPerformed(evt);
            }
        });

        BottomAttributo.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 11)); // NOI18N
        BottomAttributo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/attributo.png"))); // NOI18N
        BottomAttributo.setText("ATTRIBUTO");
        BottomAttributo.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BottomAttributo.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        BottomAttributo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BottomAttributoActionPerformed1(evt);
            }
        });

        jButton5.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 11)); // NOI18N
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/dominio.png"))); // NOI18N
        jButton5.setText("DOMINIO");
        jButton5.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton5.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel34Layout = new javax.swing.GroupLayout(jPanel34);
        jPanel34.setLayout(jPanel34Layout);
        jPanel34Layout.setHorizontalGroup(
            jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel34Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ndmn)
                .addContainerGap())
        );
        jPanel34Layout.setVerticalGroup(
            jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel34Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ndmn)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel34, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(BottomDatabase, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(21, 21, 21)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(BottomTabella, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(21, 21, 21)
                        .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(BottomAttributo, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(21, 21, 21)
                        .addComponent(jPanel20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(BottomVista, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(21, 21, 21)
                        .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 0, 0))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(BottomDatabase, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(40, 40, 40)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(BottomTabella, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(40, 40, 40)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(BottomAttributo, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addComponent(jPanel20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(40, 40, 40)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(BottomVista, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addComponent(jButton5)
                        .addGap(19, 19, 19))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel34, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(46, 46, 46))))
        );

        getContentPane().add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 170, 560));

        jTabbedPane2.setTabLayoutPolicy(javax.swing.JTabbedPane.SCROLL_TAB_LAYOUT);
        jTabbedPane2.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jTabbedPane2.setFocusable(false);
        jTabbedPane2.setInheritsPopupMenu(true);

        label2.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 36)); // NOI18N
        label2.setText("Gentile Utente, le diamo il benvenuto.");

        label3.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 36)); // NOI18N
        label3.setForeground(new java.awt.Color(204, 0, 0));
        label3.setText("Login eseguito con successo.");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap(222, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addComponent(label3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(251, 251, 251))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addComponent(label2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(197, 197, 197))))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(106, 106, 106)
                .addComponent(label2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(label3, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(314, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("ben", jPanel4);

        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel9.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel9.setText("Id database:");
        jPanel3.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(654, 167, 212, 37));

        textIdDb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textIdDbActionPerformed(evt);
            }
        });
        jPanel3.add(textIdDb, new org.netbeans.lib.awtextra.AbsoluteConstraints(606, 222, 220, 27));

        jLabel10.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel10.setText("Nome database:");
        jPanel3.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(646, 267, 220, 37));

        textNomeDb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textNomeDbActionPerformed(evt);
            }
        });
        jPanel3.add(textNomeDb, new org.netbeans.lib.awtextra.AbsoluteConstraints(606, 322, 220, 27));

        editDbBottom.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        editDbBottom.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/edit.png"))); // NOI18N
        editDbBottom.setText("MODIFICA");
        editDbBottom.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        editDbBottom.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        editDbBottom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editDbBottomActionPerformed(evt);
            }
        });
        jPanel3.add(editDbBottom, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 384, 91, 63));

        addDbBottom.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        addDbBottom.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/add.png"))); // NOI18N
        addDbBottom.setText("AGGIUNGI");
        addDbBottom.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        addDbBottom.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        addDbBottom.setInheritsPopupMenu(true);
        addDbBottom.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        addDbBottom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addDbBottomActionPerformed(evt);
            }
        });
        jPanel3.add(addDbBottom, new org.netbeans.lib.awtextra.AbsoluteConstraints(536, 384, -1, -1));

        deleteDbBottom.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        deleteDbBottom.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/delete.png"))); // NOI18N
        deleteDbBottom.setText("ELIMINA");
        deleteDbBottom.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        deleteDbBottom.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        deleteDbBottom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteDbBottomActionPerformed(evt);
            }
        });
        jPanel3.add(deleteDbBottom, new org.netbeans.lib.awtextra.AbsoluteConstraints(809, 384, 91, 63));

        jLabel2.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 24)); // NOI18N
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/Db.png"))); // NOI18N
        jLabel2.setText("GESTIONE DEI DATABASE");
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(335, 27, -1, -1));

        JTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "NOME"
            }
        ));
        JTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                JTable1MouseClicked(evt);
            }
        });
        JTable1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                JTable1KeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(JTable1);

        jPanel3.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 131, -1, 382));

        value.setText("RICERCA VELOCE:");
        jPanel3.add(value, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 108, 113, -1));

        valueDb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                valueDbActionPerformed(evt);
            }
        });
        valueDb.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                valueDbKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                valueDbKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                valueDbKeyTyped(evt);
            }
        });
        jPanel3.add(valueDb, new org.netbeans.lib.awtextra.AbsoluteConstraints(167, 105, 335, -1));

        jTabbedPane2.addTab("db", jPanel3);

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID TABELLA", "NOME TABELLA", "DATABASE"
            }
        ));
        jTable2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable2MouseClicked(evt);
            }
        });
        jTable2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTable2KeyReleased(evt);
            }
        });
        jScrollPane2.setViewportView(jTable2);

        javax.swing.GroupLayout jPanel23Layout = new javax.swing.GroupLayout(jPanel23);
        jPanel23.setLayout(jPanel23Layout);
        jPanel23Layout.setHorizontalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel23Layout.setVerticalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jLabel11.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel11.setText("Nome tabella:");

        textNomeTabella.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textNomeTabellaActionPerformed(evt);
            }
        });

        jLabel14.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel14.setText("Database:");

        jComboBox_db.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox_dbActionPerformed(evt);
            }
        });

        deleteTbBottom.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        deleteTbBottom.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/delete.png"))); // NOI18N
        deleteTbBottom.setText("ELIMINA");
        deleteTbBottom.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        deleteTbBottom.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        deleteTbBottom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteTbBottomActionPerformed(evt);
            }
        });

        editDbBottom4.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        editDbBottom4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/edit.png"))); // NOI18N
        editDbBottom4.setText("MODIFICA");
        editDbBottom4.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        editDbBottom4.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        editDbBottom4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editDbBottom4ActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 24)); // NOI18N
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/table.png"))); // NOI18N
        jLabel3.setText("GESTIONE DELLE TABELLE");

        addtableBottom.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        addtableBottom.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/add.png"))); // NOI18N
        addtableBottom.setText("AGGIUNGI");
        addtableBottom.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        addtableBottom.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        addtableBottom.setInheritsPopupMenu(true);
        addtableBottom.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        addtableBottom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addtableBottomActionPerformed(evt);
            }
        });

        textIdTb.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        textIdTb.setText("Id Tabella:");

        textIdTabella.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textIdTabellaActionPerformed(evt);
            }
        });

        value1.setText("RICERCA VELOCE:");

        valueTabella.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                valueTabellaActionPerformed(evt);
            }
        });
        valueTabella.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                valueTabellaKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(335, 335, 335)
                        .addComponent(jLabel3))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addComponent(value1, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(7, 7, 7)
                                .addComponent(valueTabella))
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 426, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(75, 75, 75)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGap(125, 125, 125)
                                .addComponent(textIdTb))
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGap(58, 58, 58)
                                .addComponent(textIdTabella, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGap(124, 124, 124)
                                .addComponent(jLabel11))
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGap(58, 58, 58)
                                .addComponent(textNomeTabella, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGap(139, 139, 139)
                                .addComponent(jLabel14))
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGap(58, 58, 58)
                                .addComponent(jComboBox_db, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addComponent(addtableBottom)
                                .addGap(32, 32, 32)
                                .addComponent(editDbBottom4, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(34, 34, 34)
                                .addComponent(deleteTbBottom, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(49, 49, 49))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addComponent(jPanel23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(value1, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(valueTabella, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 324, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(textIdTb, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(11, 11, 11)
                        .addComponent(textIdTabella, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(25, 25, 25)
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(11, 11, 11)
                        .addComponent(textNomeTabella, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(24, 24, 24)
                        .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(jComboBox_db, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(35, 35, 35)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(addtableBottom, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(editDbBottom4, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(deleteTbBottom, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)))))
        );

        jTabbedPane2.addTab("tb", jPanel6);

        jPanel10.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable5.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "NOME", "DESCRIZIONE", "CODICE SQL", "TABELLA", "VISTA"
            }
        ));
        jTable5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable5MouseClicked(evt);
            }
        });
        jTable5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTable5KeyReleased(evt);
            }
        });
        jScrollPane7.setViewportView(jTable5);
        if (jTable5.getColumnModel().getColumnCount() > 0) {
            jTable5.getColumnModel().getColumn(0).setResizable(false);
        }

        jPanel10.add(jScrollPane7, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 135, 426, 376));

        jLabel28.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel28.setText("Descrizione:");
        jPanel10.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(534, 218, -1, 30));

        jLabel29.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel29.setText("Nome: ");
        jPanel10.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(534, 170, -1, 30));

        textNomeTrigger.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textNomeTriggerActionPerformed(evt);
            }
        });
        jPanel10.add(textNomeTrigger, new org.netbeans.lib.awtextra.AbsoluteConstraints(669, 177, 204, -1));

        textDescrizioneTrigger.setColumns(20);
        textDescrizioneTrigger.setRows(5);
        jScrollPane15.setViewportView(textDescrizioneTrigger);

        jPanel10.add(jScrollPane15, new org.netbeans.lib.awtextra.AbsoluteConstraints(669, 218, 204, 50));

        jLabel30.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel30.setText("Codice SQL:");
        jPanel10.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(534, 289, -1, 22));

        textCodiceSqlTrigger.setColumns(20);
        textCodiceSqlTrigger.setRows(5);
        jScrollPane16.setViewportView(textCodiceSqlTrigger);

        jPanel10.add(jScrollPane16, new org.netbeans.lib.awtextra.AbsoluteConstraints(669, 289, 204, 50));

        jLabel31.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel31.setText("Associato a:");
        jPanel10.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(534, 356, -1, 22));

        jComboBoxTriggerTabella.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxTriggerTabellaActionPerformed(evt);
            }
        });
        jPanel10.add(jComboBoxTriggerTabella, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 359, 143, -1));

        addTriggerBottom.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        addTriggerBottom.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/add.png"))); // NOI18N
        addTriggerBottom.setText("AGGIUNGI");
        addTriggerBottom.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        addTriggerBottom.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        addTriggerBottom.setInheritsPopupMenu(true);
        addTriggerBottom.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        addTriggerBottom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addTriggerBottomActionPerformed(evt);
            }
        });
        jPanel10.add(addTriggerBottom, new org.netbeans.lib.awtextra.AbsoluteConstraints(529, 452, -1, 59));

        editTriggerBottom.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        editTriggerBottom.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/edit.png"))); // NOI18N
        editTriggerBottom.setText("MODIFICA");
        editTriggerBottom.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        editTriggerBottom.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        editTriggerBottom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editTriggerBottomActionPerformed(evt);
            }
        });
        jPanel10.add(editTriggerBottom, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 452, -1, -1));

        deleteTriggerBottom.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        deleteTriggerBottom.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/delete.png"))); // NOI18N
        deleteTriggerBottom.setText("ELIMINA");
        deleteTriggerBottom.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        deleteTriggerBottom.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        deleteTriggerBottom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteTriggerBottomActionPerformed(evt);
            }
        });
        jPanel10.add(deleteTriggerBottom, new org.netbeans.lib.awtextra.AbsoluteConstraints(796, 452, -1, -1));

        jLabel4.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 24)); // NOI18N
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/trigger.png"))); // NOI18N
        jLabel4.setText("GESTIONE DEI TRIGGERS");
        jPanel10.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(335, 18, 306, 50));

        jLabel49.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel49.setText("Id:");
        jPanel10.add(jLabel49, new org.netbeans.lib.awtextra.AbsoluteConstraints(534, 129, -1, 30));

        textIdTrigger.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textIdTriggerActionPerformed(evt);
            }
        });
        jPanel10.add(textIdTrigger, new org.netbeans.lib.awtextra.AbsoluteConstraints(669, 136, 204, -1));

        RadioFormato.add(RadioTabella);
        RadioTabella.setText("Tabella");
        RadioTabella.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                RadioTabellaItemStateChanged(evt);
            }
        });
        RadioTabella.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RadioTabellaActionPerformed(evt);
            }
        });
        jPanel10.add(RadioTabella, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 360, -1, -1));

        RadioFormato.add(RadioVista);
        RadioVista.setText("Vista");
        RadioVista.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                RadioVistaItemStateChanged(evt);
            }
        });
        RadioVista.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RadioVistaActionPerformed(evt);
            }
        });
        jPanel10.add(RadioVista, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 390, -1, -1));

        jComboBoxTriggerVista.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxTriggerVistaActionPerformed(evt);
            }
        });
        jPanel10.add(jComboBoxTriggerVista, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 391, 143, -1));

        valueTrigger.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                valueTriggerActionPerformed(evt);
            }
        });
        valueTrigger.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                valueTriggerKeyReleased(evt);
            }
        });
        jPanel10.add(valueTrigger, new org.netbeans.lib.awtextra.AbsoluteConstraints(181, 104, 295, -1));

        value2.setText("RICERCA VELOCE:");
        jPanel10.add(value2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 107, 113, -1));

        jTabbedPane2.addTab("trgg", jPanel10);

        jTable6.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID ", "NOME", "DESCRIZIONE", "CODICE SQL", "DATABASE"
            }
        ));
        jTable6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable6MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jTable6MouseEntered(evt);
            }
        });
        jTable6.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTable6KeyReleased(evt);
            }
        });
        jScrollPane8.setViewportView(jTable6);

        jLabel32.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel32.setText("Nome: ");

        jLabel33.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel33.setText("Descrizione:");

        jLabel34.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel34.setText("Codice SQL: ");

        textCodiceSqlAssertion.setColumns(20);
        textCodiceSqlAssertion.setRows(5);
        jScrollPane17.setViewportView(textCodiceSqlAssertion);

        textDescrizioneAssertion.setColumns(20);
        textDescrizioneAssertion.setRows(5);
        jScrollPane18.setViewportView(textDescrizioneAssertion);

        textNomeAssertion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textNomeAssertionActionPerformed(evt);
            }
        });

        jLabel35.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel35.setText("Database:");

        editAssertionBottom.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        editAssertionBottom.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/edit.png"))); // NOI18N
        editAssertionBottom.setText("MODIFICA");
        editAssertionBottom.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        editAssertionBottom.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        editAssertionBottom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editAssertionBottomActionPerformed(evt);
            }
        });

        deleteDbBottom5.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        deleteDbBottom5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/delete.png"))); // NOI18N
        deleteDbBottom5.setText("ELIMINA");
        deleteDbBottom5.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        deleteDbBottom5.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        deleteDbBottom5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteDbBottom5ActionPerformed(evt);
            }
        });

        textDbAssertion.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleziona" }));

        jLabel5.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 24)); // NOI18N
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/funzione.png"))); // NOI18N
        jLabel5.setText("GESTIONE DELLE ASSERZIONI");

        addAssertionBottom.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        addAssertionBottom.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/add.png"))); // NOI18N
        addAssertionBottom.setText("AGGIUNGI");
        addAssertionBottom.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        addAssertionBottom.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        addAssertionBottom.setInheritsPopupMenu(true);
        addAssertionBottom.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        addAssertionBottom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addAssertionBottomActionPerformed(evt);
            }
        });

        jLabel41.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel41.setText("Id:");

        textIdAssertion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textIdAssertionActionPerformed(evt);
            }
        });

        valueAssertion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                valueAssertionActionPerformed(evt);
            }
        });
        valueAssertion.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                valueAssertionKeyReleased(evt);
            }
        });

        RicercaAssertion.setText("RICERCA VELOCE:");

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addGap(297, 297, 297))
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 426, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel11Layout.createSequentialGroup()
                        .addComponent(RicercaAssertion)
                        .addGap(18, 18, 18)
                        .addComponent(valueAssertion)))
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGap(76, 76, 76)
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel11Layout.createSequentialGroup()
                                .addComponent(jLabel41)
                                .addGap(69, 69, 69)
                                .addComponent(textIdAssertion))
                            .addGroup(jPanel11Layout.createSequentialGroup()
                                .addComponent(jLabel32)
                                .addGap(39, 39, 39)
                                .addComponent(textNomeAssertion))
                            .addGroup(jPanel11Layout.createSequentialGroup()
                                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel34)
                                    .addComponent(jLabel33))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane18)
                                    .addComponent(jScrollPane17)))))
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel11Layout.createSequentialGroup()
                                .addGap(69, 69, 69)
                                .addComponent(addAssertionBottom))
                            .addGroup(jPanel11Layout.createSequentialGroup()
                                .addGap(78, 78, 78)
                                .addComponent(jLabel35)))
                        .addGap(32, 32, 32)
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel11Layout.createSequentialGroup()
                                .addComponent(editAssertionBottom, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(37, 37, 37)
                                .addComponent(deleteDbBottom5, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(textDbAssertion, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(64, 64, 64))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 55, Short.MAX_VALUE)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textIdAssertion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel41, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(20, 20, 20)
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textNomeAssertion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel32, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(20, 20, 20)
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel33, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane18, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(20, 20, 20)
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane17, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textDbAssertion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel35, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(deleteDbBottom5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(editAssertionBottom, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(addAssertionBottom, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(valueAssertion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(RicercaAssertion))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(91, 91, 91))
        );

        jTabbedPane2.addTab("ass", jPanel11);

        jLabel24.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel24.setText("Email:");

        jLabel25.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel25.setText("Nome Utente:");

        jLabel26.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel26.setText("Cognome:");

        textUsername.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textUsernameActionPerformed(evt);
            }
        });

        textCognome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textCognomeActionPerformed(evt);
            }
        });

        addUtente.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        addUtente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/add.png"))); // NOI18N
        addUtente.setText("AGGIUNGI");
        addUtente.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        addUtente.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        addUtente.setInheritsPopupMenu(true);
        addUtente.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        addUtente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addUtenteActionPerformed(evt);
            }
        });

        editUtente.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        editUtente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/edit.png"))); // NOI18N
        editUtente.setText("MODIFICA");
        editUtente.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        editUtente.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        editUtente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editUtenteActionPerformed(evt);
            }
        });

        deleteUtente.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        deleteUtente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/delete.png"))); // NOI18N
        deleteUtente.setText("ELIMINA");
        deleteUtente.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        deleteUtente.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        deleteUtente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteUtenteActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 24)); // NOI18N
        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/utenti.png"))); // NOI18N
        jLabel7.setText("GESTIONE DEGLI UTENTI");

        jLabel52.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel52.setText("Nome:");

        jLabel53.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel53.setText("Password:");

        textNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textNomeActionPerformed(evt);
            }
        });

        textEmail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textEmailActionPerformed(evt);
            }
        });

        ShowPassword.setText("Mostra Password");
        ShowPassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ShowPasswordActionPerformed(evt);
            }
        });

        valueUser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                valueUserActionPerformed(evt);
            }
        });
        valueUser.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                valueUserKeyReleased(evt);
            }
        });

        jLabel27.setText("RICERCA VELOCE:");

        jTableUtente.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "USERNAME", "NOME", "COGNOME", "EMAIL", "PASSWORD"
            }
        ));
        jTableUtente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableUtenteMouseClicked(evt);
            }
        });
        jTableUtente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTableUtenteKeyReleased(evt);
            }
        });
        jScrollPane13.setViewportView(jTableUtente);

        jButton7.setText("IMPOSTA PERMESSI");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addGap(330, 330, 330)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel13Layout.createSequentialGroup()
                                .addGap(2, 2, 2)
                                .addComponent(jLabel27)
                                .addGap(18, 18, 18)
                                .addComponent(valueUser))
                            .addComponent(jScrollPane13, javax.swing.GroupLayout.PREFERRED_SIZE, 426, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(54, 54, 54)
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel13Layout.createSequentialGroup()
                                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel25)
                                    .addComponent(jLabel52)
                                    .addComponent(jLabel26)
                                    .addComponent(jLabel53)
                                    .addComponent(addUtente))
                                .addGap(38, 38, 38)
                                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(textUsername, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(textNome, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(textCognome, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(textEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(ShowPassword)
                                    .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addGroup(jPanel13Layout.createSequentialGroup()
                                            .addComponent(editUtente, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(deleteUtente, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addComponent(textPasswordUtente, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(jPanel13Layout.createSequentialGroup()
                                .addComponent(jLabel24)
                                .addGap(21, 21, 21)
                                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(0, 65, Short.MAX_VALUE))
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(valueUser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel27))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane13, javax.swing.GroupLayout.PREFERRED_SIZE, 345, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel13Layout.createSequentialGroup()
                                .addGap(105, 105, 105)
                                .addComponent(jLabel52, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel13Layout.createSequentialGroup()
                                .addGap(67, 67, 67)
                                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(textUsername, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addComponent(textNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(textCognome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel26))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(textEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel24))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(textPasswordUtente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel53))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(ShowPassword)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(editUtente, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(addUtente, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(deleteUtente))
                        .addGap(28, 28, 28)
                        .addComponent(jButton7)))
                .addContainerGap(67, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("ute", jPanel13);

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "NOME", "DESCRIZIONE", "CODICE SQL", "DATABASE"
            }
        ));
        jTable3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable3MouseClicked(evt);
            }
        });
        jTable3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTable3KeyReleased(evt);
            }
        });
        jScrollPane3.setViewportView(jTable3);

        jLabel18.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel18.setText("Id :");

        jLabel19.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel19.setText("Nome:");

        jLabel20.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel20.setText("Descrizione:");

        jLabel22.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel22.setText("Codice SQL:");

        textNomeVista.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textNomeVistaActionPerformed(evt);
            }
        });

        textId_vista.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textId_vistaActionPerformed(evt);
            }
        });

        textDescrizioneVista.setColumns(20);
        textDescrizioneVista.setRows(5);
        jScrollPane4.setViewportView(textDescrizioneVista);

        textCodiceSqlVista.setColumns(20);
        textCodiceSqlVista.setRows(5);
        jScrollPane5.setViewportView(textCodiceSqlVista);

        jLabel23.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel23.setText("Database:");

        addVistaBottom.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        addVistaBottom.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/add.png"))); // NOI18N
        addVistaBottom.setText("AGGIUNGI");
        addVistaBottom.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        addVistaBottom.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        addVistaBottom.setInheritsPopupMenu(true);
        addVistaBottom.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        addVistaBottom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addVistaBottomActionPerformed(evt);
            }
        });

        editVistaBottom.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        editVistaBottom.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/edit.png"))); // NOI18N
        editVistaBottom.setText("MODIFICA");
        editVistaBottom.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        editVistaBottom.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        editVistaBottom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editVistaBottomActionPerformed(evt);
            }
        });

        deleteVistaBottom.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        deleteVistaBottom.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/delete.png"))); // NOI18N
        deleteVistaBottom.setText("ELIMINA");
        deleteVistaBottom.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        deleteVistaBottom.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        deleteVistaBottom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteVistaBottomActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 24)); // NOI18N
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/vista.png"))); // NOI18N
        jLabel1.setText("GESTIONE DELLE VISTE");

        valueVista.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                valueVistaActionPerformed(evt);
            }
        });
        valueVista.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                valueVistaKeyReleased(evt);
            }
        });

        jLabel51.setText("RICERCA VELOCE:");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 294, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(311, 311, 311))
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(jLabel51)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(valueVista, javax.swing.GroupLayout.PREFERRED_SIZE, 308, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 426, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 87, Short.MAX_VALUE)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel19)
                                    .addComponent(jLabel18)
                                    .addComponent(jLabel20))
                                .addGap(30, 30, 30))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel9Layout.createSequentialGroup()
                                .addComponent(jLabel22)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(textNomeVista, javax.swing.GroupLayout.DEFAULT_SIZE, 220, Short.MAX_VALUE)
                            .addComponent(textId_vista, javax.swing.GroupLayout.DEFAULT_SIZE, 220, Short.MAX_VALUE)
                            .addComponent(jScrollPane4)
                            .addComponent(jScrollPane5)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                        .addComponent(addVistaBottom)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 35, Short.MAX_VALUE)
                        .addComponent(editVistaBottom, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30)
                        .addComponent(deleteVistaBottom, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(jLabel23)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jComboBoxDb2, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(50, 50, 50))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 42, Short.MAX_VALUE)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel51, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(valueVista, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addComponent(textId_vista, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(19, 19, 19))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                                .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(16, 16, 16)))
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textNomeVista, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addGap(13, 13, 13)
                                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addGap(14, 14, 14)
                                .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(20, 20, 20)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jComboBoxDb2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(32, 32, 32)
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(addVistaBottom, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(deleteVistaBottom, javax.swing.GroupLayout.Alignment.TRAILING)))
                            .addComponent(editVistaBottom, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 365, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(52, 52, 52))
        );

        jTabbedPane2.addTab("vista", jPanel9);

        jPanel24.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable10.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "NOME", "DEFAULT", "TABELLA", "DOMINIO", "PK", "NOME PK", "POSIZIONE PK"
            }
        ));
        jTable10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable10MouseClicked(evt);
            }
        });
        jTable10.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTable10KeyReleased(evt);
            }
        });
        jScrollPane12.setViewportView(jTable10);
        if (jTable10.getColumnModel().getColumnCount() > 0) {
            jTable10.getColumnModel().getColumn(0).setResizable(false);
        }

        jPanel24.add(jScrollPane12, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 395, 809, 133));

        jLabel13.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel13.setText("Id:");
        jPanel24.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 106, -1, -1));

        jLabel15.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel15.setText("Nome:");
        jPanel24.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 146, -1, -1));

        jLabel42.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel42.setText("Default:");
        jPanel24.add(jLabel42, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 186, -1, -1));

        jLabel43.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel43.setText("Dominio:");
        jPanel24.add(jLabel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 226, -1, 28));

        textIdAttributo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textIdAttributoActionPerformed(evt);
            }
        });
        jPanel24.add(textIdAttributo, new org.netbeans.lib.awtextra.AbsoluteConstraints(151, 108, 190, -1));

        textNomeAttributo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textNomeAttributoActionPerformed(evt);
            }
        });
        jPanel24.add(textNomeAttributo, new org.netbeans.lib.awtextra.AbsoluteConstraints(151, 148, 190, -1));

        jComboBoxDefaultAttributo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "NULL", "NOT NULL" }));
        jComboBoxDefaultAttributo.setToolTipText("");
        jPanel24.add(jComboBoxDefaultAttributo, new org.netbeans.lib.awtextra.AbsoluteConstraints(151, 188, 190, -1));

        jComboBoxAttributoTabella.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleziona" }));
        jComboBoxAttributoTabella.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxAttributoTabellaActionPerformed(evt);
            }
        });
        jPanel24.add(jComboBoxAttributoTabella, new org.netbeans.lib.awtextra.AbsoluteConstraints(151, 284, 190, -1));

        addAttributo.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        addAttributo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/add.png"))); // NOI18N
        addAttributo.setText("AGGIUNGI");
        addAttributo.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        addAttributo.setInheritsPopupMenu(true);
        addAttributo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addAttributoActionPerformed(evt);
            }
        });
        jPanel24.add(addAttributo, new org.netbeans.lib.awtextra.AbsoluteConstraints(208, 312, -1, 39));

        editAttributo.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        editAttributo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/edit.png"))); // NOI18N
        editAttributo.setText("MODIFICA");
        editAttributo.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        editAttributo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editAttributoActionPerformed(evt);
            }
        });
        jPanel24.add(editAttributo, new org.netbeans.lib.awtextra.AbsoluteConstraints(418, 312, -1, -1));

        deleteAttributo.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        deleteAttributo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/delete.png"))); // NOI18N
        deleteAttributo.setText("ELIMINA");
        deleteAttributo.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        deleteAttributo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteAttributoActionPerformed(evt);
            }
        });
        jPanel24.add(deleteAttributo, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 310, 125, -1));

        jLabel50.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel50.setText("Tabella:");
        jPanel24.add(jLabel50, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 282, -1, -1));

        jComboBoxAttributoDominio.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleziona" }));
        jComboBoxAttributoDominio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxAttributoDominioActionPerformed(evt);
            }
        });
        jPanel24.add(jComboBoxAttributoDominio, new org.netbeans.lib.awtextra.AbsoluteConstraints(151, 232, 190, -1));

        jLabel17.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 24)); // NOI18N
        jLabel17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/attributo.png"))); // NOI18N
        jLabel17.setText("GESTIONE DEGLI ATTRIBUTI");
        jPanel24.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(312, 10, -1, -1));

        valueAttributo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                valueAttributoActionPerformed(evt);
            }
        });
        valueAttributo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                valueAttributoKeyReleased(evt);
            }
        });
        jPanel24.add(valueAttributo, new org.netbeans.lib.awtextra.AbsoluteConstraints(158, 369, 314, -1));

        jLabel55.setText("RICERCA VELOCE:");
        jPanel24.add(jLabel55, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 372, -1, -1));

        buttonGroupVincoli.add(boxPk);
        boxPk.setText("IMPOSTA PRIMARY KEY");
        boxPk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boxPkActionPerformed(evt);
            }
        });
        jPanel24.add(boxPk, new org.netbeans.lib.awtextra.AbsoluteConstraints(398, 156, -1, -1));

        buttonGroupVincoli.add(boxFk);
        boxFk.setText("IMPOSTA FOREIGN KEY");
        boxFk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boxFkActionPerformed(evt);
            }
        });
        jPanel24.add(boxFk, new org.netbeans.lib.awtextra.AbsoluteConstraints(398, 197, -1, -1));

        buttonGroupVincoli.add(boxCheck);
        boxCheck.setText("IMPOSTA CHECK");
        boxCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boxCheckActionPerformed(evt);
            }
        });
        jPanel24.add(boxCheck, new org.netbeans.lib.awtextra.AbsoluteConstraints(398, 238, -1, -1));

        jTabbedPane1.setEnabled(false);
        jTabbedPane1.setName(""); // NOI18N
        jTabbedPane1.setVerifyInputWhenFocusTarget(false);

        panelPk.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel61.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel61.setText("Nome PK:");

        textNomePk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textNomePkActionPerformed(evt);
            }
        });

        jLabel62.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel62.setText("Posizione:");

        comboPosizionePk.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" }));

        javax.swing.GroupLayout panelPkLayout = new javax.swing.GroupLayout(panelPk);
        panelPk.setLayout(panelPkLayout);
        panelPkLayout.setHorizontalGroup(
            panelPkLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelPkLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(panelPkLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel61)
                    .addComponent(jLabel62))
                .addGap(32, 32, 32)
                .addGroup(panelPkLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(textNomePk)
                    .addComponent(comboPosizionePk, 0, 144, Short.MAX_VALUE))
                .addContainerGap(11, Short.MAX_VALUE))
        );
        panelPkLayout.setVerticalGroup(
            panelPkLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelPkLayout.createSequentialGroup()
                .addContainerGap(28, Short.MAX_VALUE)
                .addGroup(panelPkLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textNomePk, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel61, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(panelPkLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel62, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(comboPosizionePk, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(40, 40, 40))
        );

        jTabbedPane1.addTab("PK", panelPk);

        panelFk.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        panelFk.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        comboPosizioneFk.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" }));
        panelFk.add(comboPosizioneFk, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 10, 40, -1));

        jLabel66.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel66.setText("NOME FOREIGN KEY:");
        panelFk.add(jLabel66, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 30, -1, 30));

        jButton3.setText("CREA");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        panelFk.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 110, -1, -1));
        panelFk.add(nomeFkAttributo, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 70, 190, -1));

        jButton8.setText("VISUALIZZA");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        panelFk.add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 110, 100, -1));

        jTabbedPane1.addTab("FK", panelFk);

        panelCheck.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        textDescrizioneCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textDescrizioneCheckActionPerformed(evt);
            }
        });

        jLabel68.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel68.setText("Descrizione:");

        textNomeCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textNomeCheckActionPerformed(evt);
            }
        });

        jLabel72.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel72.setText("Nome Check:");

        jButton4.setText("CREA");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton9.setText("VISUALIZZA");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelCheckLayout = new javax.swing.GroupLayout(panelCheck);
        panelCheck.setLayout(panelCheckLayout);
        panelCheckLayout.setHorizontalGroup(
            panelCheckLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelCheckLayout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(panelCheckLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel68)
                    .addComponent(jLabel72))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(panelCheckLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(textDescrizioneCheck, javax.swing.GroupLayout.DEFAULT_SIZE, 132, Short.MAX_VALUE)
                    .addComponent(textNomeCheck))
                .addGap(24, 24, 24))
            .addGroup(panelCheckLayout.createSequentialGroup()
                .addGap(49, 49, 49)
                .addComponent(jButton4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 42, Short.MAX_VALUE)
                .addComponent(jButton9)
                .addGap(41, 41, 41))
        );
        panelCheckLayout.setVerticalGroup(
            panelCheckLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelCheckLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(panelCheckLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textNomeCheck, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel72, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelCheckLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textDescrizioneCheck, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel68, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panelCheckLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton4)
                    .addComponent(jButton9))
                .addContainerGap(32, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("CHECK", panelCheck);

        javax.swing.GroupLayout jPanel28Layout = new javax.swing.GroupLayout(jPanel28);
        jPanel28.setLayout(jPanel28Layout);
        jPanel28Layout.setHorizontalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 282, Short.MAX_VALUE)
        );
        jPanel28Layout.setVerticalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 161, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("", jPanel28);

        jPanel24.add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(582, 106, 287, -1));

        javax.swing.GroupLayout jPanel32Layout = new javax.swing.GroupLayout(jPanel32);
        jPanel32.setLayout(jPanel32Layout);
        jPanel32Layout.setHorizontalGroup(
            jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel32Layout.setVerticalGroup(
            jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 44, Short.MAX_VALUE)
        );

        jPanel24.add(jPanel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(555, 56, -1, -1));

        buttonGroupVincoli.add(pushKey);
        pushKey.setText("NO KEYS");
        pushKey.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pushKeyActionPerformed(evt);
            }
        });
        jPanel24.add(pushKey, new org.netbeans.lib.awtextra.AbsoluteConstraints(398, 115, -1, -1));

        jTabbedPane2.addTab("att", jPanel24);

        jPanel25.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel45.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel45.setText("Nome:");
        jPanel25.add(jLabel45, new org.netbeans.lib.awtextra.AbsoluteConstraints(537, 188, -1, -1));

        textIdDominio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textIdDominioActionPerformed(evt);
            }
        });
        jPanel25.add(textIdDominio, new org.netbeans.lib.awtextra.AbsoluteConstraints(641, 134, 232, 27));

        textNomeDominio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textNomeDominioActionPerformed(evt);
            }
        });
        jPanel25.add(textNomeDominio, new org.netbeans.lib.awtextra.AbsoluteConstraints(641, 187, 232, 27));

        jLabel46.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel46.setText("Id:");
        jPanel25.add(jLabel46, new org.netbeans.lib.awtextra.AbsoluteConstraints(537, 135, -1, -1));

        jLabel47.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel47.setText("Descrizione:");
        jPanel25.add(jLabel47, new org.netbeans.lib.awtextra.AbsoluteConstraints(537, 239, -1, -1));

        jLabel48.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel48.setText("Formato:");
        jPanel25.add(jLabel48, new org.netbeans.lib.awtextra.AbsoluteConstraints(537, 282, -1, 50));

        textDescrizioneDominio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textDescrizioneDominioActionPerformed(evt);
            }
        });
        jPanel25.add(textDescrizioneDominio, new org.netbeans.lib.awtextra.AbsoluteConstraints(641, 238, 232, 27));

        addDominio.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        addDominio.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/add.png"))); // NOI18N
        addDominio.setText("AGGIUNGI");
        addDominio.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        addDominio.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        addDominio.setInheritsPopupMenu(true);
        addDominio.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        addDominio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addDominioActionPerformed(evt);
            }
        });
        jPanel25.add(addDominio, new org.netbeans.lib.awtextra.AbsoluteConstraints(537, 441, -1, -1));

        editDominio.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        editDominio.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/edit.png"))); // NOI18N
        editDominio.setText("MODIFICA");
        editDominio.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        editDominio.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        editDominio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editDominioActionPerformed(evt);
            }
        });
        jPanel25.add(editDominio, new org.netbeans.lib.awtextra.AbsoluteConstraints(665, 441, 90, 63));

        deleteDominio.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        deleteDominio.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/delete.png"))); // NOI18N
        deleteDominio.setText("ELIMINA");
        deleteDominio.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        deleteDominio.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        deleteDominio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteDominioActionPerformed(evt);
            }
        });
        jPanel25.add(deleteDominio, new org.netbeans.lib.awtextra.AbsoluteConstraints(782, 441, 90, 63));

        jPanel25.add(textStandard, new org.netbeans.lib.awtextra.AbsoluteConstraints(637, 307, 236, -1));

        RadioFormato.add(standard);
        standard.setText("Standard");
        standard.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                standardItemStateChanged(evt);
            }
        });
        jPanel25.add(standard, new org.netbeans.lib.awtextra.AbsoluteConstraints(616, 282, -1, -1));

        RadioFormato.add(personalizzato);
        personalizzato.setText("Personalizzato");
        personalizzato.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                personalizzatoItemStateChanged(evt);
            }
        });
        personalizzato.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                personalizzatoActionPerformed(evt);
            }
        });
        jPanel25.add(personalizzato, new org.netbeans.lib.awtextra.AbsoluteConstraints(616, 337, -1, -1));

        textPersonalizzato.setColumns(20);
        textPersonalizzato.setRows(5);
        jScrollPane10.setViewportView(textPersonalizzato);

        jPanel25.add(jScrollPane10, new org.netbeans.lib.awtextra.AbsoluteConstraints(637, 362, 235, 52));

        jLabel44.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 24)); // NOI18N
        jLabel44.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/dominio.png"))); // NOI18N
        jLabel44.setText("GESTIONE DEI DOMINI");
        jPanel25.add(jLabel44, new org.netbeans.lib.awtextra.AbsoluteConstraints(381, 25, 344, 55));

        jTable11.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "NOME", "DESCRIZIONE", "FORMATO"
            }
        ));
        jTable11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable11MouseClicked(evt);
            }
        });
        jTable11.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTable11KeyReleased(evt);
            }
        });
        jScrollPane21.setViewportView(jTable11);

        jPanel25.add(jScrollPane21, new org.netbeans.lib.awtextra.AbsoluteConstraints(51, 134, 412, 370));

        valueDominio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                valueDominioActionPerformed(evt);
            }
        });
        valueDominio.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                valueDominioKeyReleased(evt);
            }
        });
        jPanel25.add(valueDominio, new org.netbeans.lib.awtextra.AbsoluteConstraints(173, 108, 290, -1));

        jLabel54.setText("RICERCA VELOCE:");
        jPanel25.add(jLabel54, new org.netbeans.lib.awtextra.AbsoluteConstraints(55, 111, -1, -1));

        jTabbedPane2.addTab("dom", jPanel25);

        jPanel26.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel75.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 24)); // NOI18N
        jLabel75.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/procedura.png"))); // NOI18N
        jLabel75.setText("GESTIONE DELLE SEQUENZE");
        jPanel26.add(jLabel75, new org.netbeans.lib.awtextra.AbsoluteConstraints(281, 11, 344, 55));

        jLabel76.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel76.setText("Nome:");
        jPanel26.add(jLabel76, new org.netbeans.lib.awtextra.AbsoluteConstraints(543, 135, -1, -1));

        nomeSequenza.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nomeSequenzaActionPerformed(evt);
            }
        });
        jPanel26.add(nomeSequenza, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 137, 182, -1));

        jLabel77.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel77.setText("Valore max:");
        jPanel26.add(jLabel77, new org.netbeans.lib.awtextra.AbsoluteConstraints(543, 281, -1, -1));

        jLabel78.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel78.setText("Incrementa di:");
        jPanel26.add(jLabel78, new org.netbeans.lib.awtextra.AbsoluteConstraints(543, 209, -1, -1));

        jLabel79.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel79.setText("Valore minimo:");
        jPanel26.add(jLabel79, new org.netbeans.lib.awtextra.AbsoluteConstraints(543, 244, -1, -1));

        jLabel80.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel80.setText("Inizia da:");
        jPanel26.add(jLabel80, new org.netbeans.lib.awtextra.AbsoluteConstraints(543, 172, -1, -1));

        jLabel81.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel81.setText("Tabella:");
        jPanel26.add(jLabel81, new org.netbeans.lib.awtextra.AbsoluteConstraints(543, 318, -1, -1));

        jLabel82.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel82.setText("Attributo:");
        jPanel26.add(jLabel82, new org.netbeans.lib.awtextra.AbsoluteConstraints(543, 353, -1, -1));

        iniziadaSequenza.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iniziadaSequenzaActionPerformed(evt);
            }
        });
        jPanel26.add(iniziadaSequenza, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 174, 182, -1));

        incrementadiSequenza.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                incrementadiSequenzaActionPerformed(evt);
            }
        });
        jPanel26.add(incrementadiSequenza, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 209, 182, -1));

        valoremaxSequenza.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                valoremaxSequenzaActionPerformed(evt);
            }
        });
        jPanel26.add(valoremaxSequenza, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 283, 182, -1));

        valoreminSequenza.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                valoreminSequenzaActionPerformed(evt);
            }
        });
        jPanel26.add(valoreminSequenza, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 246, 182, -1));

        tabellaSequenza.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleziona" }));
        tabellaSequenza.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                tabellaSequenzaItemStateChanged(evt);
            }
        });
        jPanel26.add(tabellaSequenza, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 318, 182, -1));

        jPanel26.add(attributoSequenza, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 355, 182, -1));

        addSequenza.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        addSequenza.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/add.png"))); // NOI18N
        addSequenza.setText("AGGIUNGI");
        addSequenza.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        addSequenza.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        addSequenza.setInheritsPopupMenu(true);
        addSequenza.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        addSequenza.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addSequenzaActionPerformed(evt);
            }
        });
        jPanel26.add(addSequenza, new org.netbeans.lib.awtextra.AbsoluteConstraints(534, 400, -1, -1));

        editSequenza.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        editSequenza.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/edit.png"))); // NOI18N
        editSequenza.setText("MODIFICA");
        editSequenza.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        editSequenza.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        editSequenza.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editSequenzaActionPerformed(evt);
            }
        });
        jPanel26.add(editSequenza, new org.netbeans.lib.awtextra.AbsoluteConstraints(658, 400, 90, 63));

        deleteSequenza.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        deleteSequenza.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/delete.png"))); // NOI18N
        deleteSequenza.setText("ELIMINA");
        deleteSequenza.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        deleteSequenza.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        deleteSequenza.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteSequenzaActionPerformed(evt);
            }
        });
        jPanel26.add(deleteSequenza, new org.netbeans.lib.awtextra.AbsoluteConstraints(782, 400, 90, 63));

        jTableSequenza.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "NOME", "START WITH", "INCREMENT", "MIN", "MAX", "ATTRIBUTO"
            }
        ));
        jTableSequenza.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableSequenzaMouseClicked(evt);
            }
        });
        jTableSequenza.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTableSequenzaKeyReleased(evt);
            }
        });
        jScrollPane23.setViewportView(jTableSequenza);

        jPanel26.add(jScrollPane23, new org.netbeans.lib.awtextra.AbsoluteConstraints(32, 135, -1, 329));

        valueSequenza.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                valueSequenzaActionPerformed(evt);
            }
        });
        valueSequenza.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                valueSequenzaKeyReleased(evt);
            }
        });
        jPanel26.add(valueSequenza, new org.netbeans.lib.awtextra.AbsoluteConstraints(176, 109, 308, -1));

        jLabel83.setText("RICERCA VELOCE:");
        jPanel26.add(jLabel83, new org.netbeans.lib.awtextra.AbsoluteConstraints(32, 112, -1, -1));

        jTabbedPane2.addTab("seq", jPanel26);

        jPanel12.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable7.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "NOME", "DESCRIZIONE", "CODICE SQL", "DATABASE"
            }
        ));
        jTable7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable7MouseClicked(evt);
            }
        });
        jTable7.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTable7KeyReleased(evt);
            }
        });
        jScrollPane9.setViewportView(jTable7);

        jPanel12.add(jScrollPane9, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 133, 426, 371));

        jLabel36.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel36.setText("Id:");
        jPanel12.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(541, 133, -1, 30));

        jLabel37.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel37.setText("Nome:");
        jPanel12.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(541, 183, 90, 37));

        jLabel38.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel38.setText("Descrizione:");
        jPanel12.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(541, 238, -1, 30));

        jLabel39.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel39.setText("Database:");
        jPanel12.add(jLabel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(541, 381, -1, 30));

        jLabel40.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel40.setText("Codice SQL:");
        jPanel12.add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(541, 315, -1, 38));

        textIdProcedura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textIdProceduraActionPerformed(evt);
            }
        });
        jPanel12.add(textIdProcedura, new org.netbeans.lib.awtextra.AbsoluteConstraints(641, 136, 246, 27));

        textDescrizioneProcedura.setColumns(20);
        textDescrizioneProcedura.setRows(5);
        jScrollPane19.setViewportView(textDescrizioneProcedura);

        jPanel12.add(jScrollPane19, new org.netbeans.lib.awtextra.AbsoluteConstraints(641, 233, 246, 52));

        textNomeProcedura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textNomeProceduraActionPerformed(evt);
            }
        });
        jPanel12.add(textNomeProcedura, new org.netbeans.lib.awtextra.AbsoluteConstraints(641, 190, 246, 27));

        textCodiceSqlProcedura.setColumns(20);
        textCodiceSqlProcedura.setRows(5);
        jScrollPane20.setViewportView(textCodiceSqlProcedura);

        jPanel12.add(jScrollPane20, new org.netbeans.lib.awtextra.AbsoluteConstraints(641, 306, 246, 55));

        jComboBoxDbProcedura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxDbProceduraActionPerformed(evt);
            }
        });
        jPanel12.add(jComboBoxDbProcedura, new org.netbeans.lib.awtextra.AbsoluteConstraints(641, 388, 246, -1));

        editProcedureBottom.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        editProcedureBottom.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/edit.png"))); // NOI18N
        editProcedureBottom.setText("MODIFICA");
        editProcedureBottom.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        editProcedureBottom.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        editProcedureBottom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editProcedureBottomActionPerformed(evt);
            }
        });
        jPanel12.add(editProcedureBottom, new org.netbeans.lib.awtextra.AbsoluteConstraints(668, 445, 90, -1));

        deleteProcedureBottom.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        deleteProcedureBottom.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/delete.png"))); // NOI18N
        deleteProcedureBottom.setText("ELIMINA");
        deleteProcedureBottom.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        deleteProcedureBottom.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        deleteProcedureBottom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteProcedureBottomActionPerformed(evt);
            }
        });
        jPanel12.add(deleteProcedureBottom, new org.netbeans.lib.awtextra.AbsoluteConstraints(794, 445, 90, -1));

        jLabel6.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 24)); // NOI18N
        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/procedura.png"))); // NOI18N
        jLabel6.setText("GESTIONE DELLE S-PROCEDURE");
        jPanel12.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(328, 24, 344, 55));

        addProcedureBottom.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        addProcedureBottom.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/add.png"))); // NOI18N
        addProcedureBottom.setText("AGGIUNGI");
        addProcedureBottom.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        addProcedureBottom.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        addProcedureBottom.setInheritsPopupMenu(true);
        addProcedureBottom.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        addProcedureBottom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addProcedureBottomActionPerformed(evt);
            }
        });
        jPanel12.add(addProcedureBottom, new org.netbeans.lib.awtextra.AbsoluteConstraints(541, 445, -1, 59));

        valueProcedura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                valueProceduraActionPerformed(evt);
            }
        });
        valueProcedura.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                valueProceduraKeyReleased(evt);
            }
        });
        jPanel12.add(valueProcedura, new org.netbeans.lib.awtextra.AbsoluteConstraints(168, 107, 308, -1));

        RicercaProcedure.setText("RICERCA VELOCE:");
        jPanel12.add(RicercaProcedure, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 110, -1, -1));

        jTabbedPane2.addTab("proc", jPanel12);

        jLabel67.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 24)); // NOI18N
        jLabel67.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/check.png"))); // NOI18N
        jLabel67.setText("GESTIONE DEI CHECK");

        jTableCheck.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "NOME", "DESCRIZIONE", "ATTRIBUTO", "CODICE SQL"
            }
        ));
        jTableCheck.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableCheckMouseClicked(evt);
            }
        });
        jTableCheck.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTableCheckKeyReleased(evt);
            }
        });
        jScrollPane6.setViewportView(jTableCheck);

        jLabel69.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel69.setText("Nome Check:");

        jLabel70.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel70.setText("Descrizione:");

        jLabel71.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel71.setText("Tabella:");

        jLabel73.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel73.setText("Attributo:");

        jLabel74.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel74.setText("Codice Sql:");

        nomeCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nomeCheckActionPerformed(evt);
            }
        });

        codiceSqlCheck.setColumns(20);
        codiceSqlCheck.setRows(5);
        jScrollPane22.setViewportView(codiceSqlCheck);

        addProcedureBottom1.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        addProcedureBottom1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/add.png"))); // NOI18N
        addProcedureBottom1.setText("AGGIUNGI");
        addProcedureBottom1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        addProcedureBottom1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        addProcedureBottom1.setInheritsPopupMenu(true);
        addProcedureBottom1.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        addProcedureBottom1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addProcedureBottom1ActionPerformed(evt);
            }
        });

        deleteCheck.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        deleteCheck.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/delete.png"))); // NOI18N
        deleteCheck.setText("ELIMINA");
        deleteCheck.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        deleteCheck.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        deleteCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteCheckActionPerformed(evt);
            }
        });

        tabellaCheck.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                tabellaCheckItemStateChanged(evt);
            }
        });

        valueCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                valueCheckActionPerformed(evt);
            }
        });
        valueCheck.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                valueCheckKeyReleased(evt);
            }
        });

        jLabel85.setText("RICERCA VELOCE:");

        javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
        jPanel21.setLayout(jPanel21Layout);
        jPanel21Layout.setHorizontalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel21Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jPanel21Layout.createSequentialGroup()
                        .addComponent(jLabel85, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(valueCheck, javax.swing.GroupLayout.PREFERRED_SIZE, 302, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel21Layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(jPanel21Layout.createSequentialGroup()
                                .addComponent(jLabel69)
                                .addGap(18, 18, 18)
                                .addComponent(nomeCheck, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel21Layout.createSequentialGroup()
                                .addComponent(jLabel70)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(descrizioneCheck, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel21Layout.createSequentialGroup()
                                .addComponent(jLabel71)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(tabellaCheck, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel21Layout.createSequentialGroup()
                                .addComponent(jLabel73)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(attributoCheck, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel21Layout.createSequentialGroup()
                                .addComponent(jLabel74)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jScrollPane22, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel21Layout.createSequentialGroup()
                        .addGap(65, 65, 65)
                        .addComponent(addProcedureBottom1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(deleteCheck, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(90, 90, 90))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel21Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel67)
                .addGap(318, 318, 318))
        );
        jPanel21Layout.setVerticalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel21Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel67, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(56, 56, 56)
                .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(valueCheck, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel85))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel21Layout.createSequentialGroup()
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 323, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 73, Short.MAX_VALUE))
                    .addGroup(jPanel21Layout.createSequentialGroup()
                        .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel69)
                            .addComponent(nomeCheck, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(20, 20, 20)
                        .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(descrizioneCheck, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel70))
                        .addGap(20, 20, 20)
                        .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tabellaCheck, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel71))
                        .addGap(20, 20, 20)
                        .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(attributoCheck, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel73))
                        .addGap(20, 20, 20)
                        .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane22, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel74))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 23, Short.MAX_VALUE)
                        .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(addProcedureBottom1, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(deleteCheck))
                        .addContainerGap(75, Short.MAX_VALUE))))
        );

        jTabbedPane2.addTab("check", jPanel21);

        jPanel27.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel56.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel56.setText("Nome FK:");
        jPanel27.add(jLabel56, new org.netbeans.lib.awtextra.AbsoluteConstraints(574, 156, -1, -1));

        jLabel57.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel57.setText("Tabella:");
        jPanel27.add(jLabel57, new org.netbeans.lib.awtextra.AbsoluteConstraints(573, 208, -1, -1));

        jLabel58.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel58.setText("Attributo:");
        jPanel27.add(jLabel58, new org.netbeans.lib.awtextra.AbsoluteConstraints(573, 254, -1, -1));

        jLabel59.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel59.setText("Posizione:");
        jPanel27.add(jLabel59, new org.netbeans.lib.awtextra.AbsoluteConstraints(573, 397, -1, -1));
        jPanel27.add(nomeFk, new org.netbeans.lib.awtextra.AbsoluteConstraints(704, 158, 142, -1));

        addFk.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        addFk.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/add.png"))); // NOI18N
        addFk.setText("AGGIUNGI ");
        addFk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addFkActionPerformed(evt);
            }
        });
        jPanel27.add(addFk, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 440, -1, -1));

        jButton6.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/delete.png"))); // NOI18N
        jButton6.setText("ELIMINA");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel27.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 440, -1, -1));

        jLabel60.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 24)); // NOI18N
        jLabel60.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/chiave.png"))); // NOI18N
        jLabel60.setText("GESTIONE DELLE FOREIGN KEY");
        jPanel27.add(jLabel60, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 34, 344, 55));

        jLabel63.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel63.setText("RTabella:");
        jPanel27.add(jLabel63, new org.netbeans.lib.awtextra.AbsoluteConstraints(573, 294, -1, -1));

        jLabel64.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel64.setText("RAttributo:");
        jPanel27.add(jLabel64, new org.netbeans.lib.awtextra.AbsoluteConstraints(573, 342, -1, -1));

        jPanel27.add(comboRAttributo, new org.netbeans.lib.awtextra.AbsoluteConstraints(704, 344, 142, -1));

        comboPosAttributo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" }));
        jPanel27.add(comboPosAttributo, new org.netbeans.lib.awtextra.AbsoluteConstraints(704, 399, -1, -1));

        textAttributoFk.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                textAttributoFkItemStateChanged(evt);
            }
        });
        jPanel27.add(textAttributoFk, new org.netbeans.lib.awtextra.AbsoluteConstraints(704, 256, 142, -1));

        tabellaFk.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "NOME", "TABELLA", "ATTRIBUTO", "RTABELLA", "RATTRIBUTO", "POSIZIONE"
            }
        ));
        tabellaFk.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabellaFkMouseClicked(evt);
            }
        });
        tabellaFk.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tabellaFkKeyReleased(evt);
            }
        });
        jScrollPane24.setViewportView(tabellaFk);

        jPanel27.add(jScrollPane24, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 160, -1, 320));

        textTabellaFk.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                textTabellaFkItemStateChanged(evt);
            }
        });
        jPanel27.add(textTabellaFk, new org.netbeans.lib.awtextra.AbsoluteConstraints(704, 210, 142, -1));

        comboRTabella.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleziona" }));
        comboRTabella.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                comboRTabellaItemStateChanged(evt);
            }
        });
        jPanel27.add(comboRTabella, new org.netbeans.lib.awtextra.AbsoluteConstraints(704, 296, 142, -1));

        jLabel65.setText("RICERCA VELOCE:");
        jPanel27.add(jLabel65, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 130, -1, 20));

        valueFk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                valueFkActionPerformed(evt);
            }
        });
        valueFk.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                valueFkKeyReleased(evt);
            }
        });
        jPanel27.add(valueFk, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 130, 306, -1));

        jTabbedPane2.addTab("fk", jPanel27);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane11.setViewportView(jTable1);

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleziona...", "Databases", "Tabelle", "Attributi", "Primary Keys", "Foreign Keys", "Checks", "Viste", "Dominio", "Triggers", "Asserzioni", "Procedure", "Sequenze", "Utenti" }));

        jButton2.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/visualizza.png"))); // NOI18N
        jButton2.setText("VISUALIZZA");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 24)); // NOI18N
        jLabel8.setText("Cosa vuoi visualizzare?");

        jLabel84.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 24)); // NOI18N
        jLabel84.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/search.png"))); // NOI18N
        jLabel84.setText("EFFETTUA RICERCA");

        javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
        jPanel22.setLayout(jPanel22Layout);
        jPanel22Layout.setHorizontalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel22Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel22Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBox1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(140, 140, 140))
                    .addGroup(jPanel22Layout.createSequentialGroup()
                        .addGap(109, 109, 109)
                        .addComponent(jLabel8)
                        .addContainerGap(125, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel22Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel84, javax.swing.GroupLayout.PREFERRED_SIZE, 344, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(261, 261, 261))
        );
        jPanel22Layout.setVerticalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel22Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel84, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 41, Short.MAX_VALUE)
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel22Layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addGap(80, 80, 80)
                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(62, 62, 62)
                        .addComponent(jButton2)
                        .addGap(154, 154, 154))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel22Layout.createSequentialGroup()
                        .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(105, 105, 105))))
        );

        jTabbedPane2.addTab("ric", jPanel22);

        jTable4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "UTENTE", "PERMESSO", "DATABASE"
            }
        ));
        jTable4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable4MouseClicked(evt);
            }
        });
        jTable4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTable4KeyReleased(evt);
            }
        });
        jScrollPane14.setViewportView(jTable4);

        jLabel21.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 24)); // NOI18N
        jLabel21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/login.png"))); // NOI18N
        jLabel21.setText("GESTIONE PERMESSI UTENTI");

        NomeUtente.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        NomeUtente.setText("Nome Utente:");

        database.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        database.setText("Database:");

        Permesso.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        Permesso.setText("Permesso:");

        comboDbPermessi.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleziona" }));

        addSequenza1.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        addSequenza1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/add.png"))); // NOI18N
        addSequenza1.setText("AGGIUNGI");
        addSequenza1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        addSequenza1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        addSequenza1.setInheritsPopupMenu(true);
        addSequenza1.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        addSequenza1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addSequenza1ActionPerformed(evt);
            }
        });

        editPermessi.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        editPermessi.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/edit.png"))); // NOI18N
        editPermessi.setText("MODIFICA");
        editPermessi.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        editPermessi.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        editPermessi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editPermessiActionPerformed(evt);
            }
        });

        deletePermessi.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        deletePermessi.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/delete.png"))); // NOI18N
        deletePermessi.setText("ELIMINA");
        deletePermessi.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        deletePermessi.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        deletePermessi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletePermessiActionPerformed(evt);
            }
        });

        comboPermesso.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleziona", "Writer", "Reader", "Editor" }));

        comboUsernamePermessi.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleziona" }));

        javax.swing.GroupLayout jPanel31Layout = new javax.swing.GroupLayout(jPanel31);
        jPanel31.setLayout(jPanel31Layout);
        jPanel31Layout.setHorizontalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel31Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addComponent(jScrollPane14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(60, 60, 60)
                .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(database)
                    .addComponent(Permesso)
                    .addComponent(NomeUtente)
                    .addComponent(addSequenza1))
                .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel31Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 21, Short.MAX_VALUE)
                        .addComponent(editPermessi, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20)
                        .addComponent(deletePermessi, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(84, 84, 84))
                    .addGroup(jPanel31Layout.createSequentialGroup()
                        .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel31Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(comboUsernamePermessi, 0, 188, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel31Layout.createSequentialGroup()
                                .addGap(16, 16, 16)
                                .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(comboDbPermessi, javax.swing.GroupLayout.Alignment.TRAILING, 0, 190, Short.MAX_VALUE)
                                    .addComponent(comboPermesso, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addGap(0, 0, Short.MAX_VALUE))))
            .addGroup(jPanel31Layout.createSequentialGroup()
                .addGap(300, 300, 300)
                .addComponent(jLabel21)
                .addGap(65, 65, 65))
        );
        jPanel31Layout.setVerticalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel31Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel21)
                .addGap(82, 82, 82)
                .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane14, javax.swing.GroupLayout.PREFERRED_SIZE, 254, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel31Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(NomeUtente, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(comboUsernamePermessi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(27, 27, 27)
                        .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Permesso, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(comboPermesso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(26, 26, 26)
                        .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(database)
                            .addComponent(comboDbPermessi))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(addSequenza1, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(editPermessi, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(deletePermessi, javax.swing.GroupLayout.Alignment.TRAILING))))
                .addContainerGap(156, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("per", jPanel31);

        jTabbedPane2.setSelectedIndex(2);

        getContentPane().add(jTabbedPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 70, 940, 580));

        jPanel29.setBackground(new java.awt.Color(178, 38, 38));
        jPanel29.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ntrg)
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ntrg)
                .addContainerGap())
        );

        jPanel29.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, -1, -1));

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(nass)
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(nass)
                .addContainerGap())
        );

        jPanel29.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 145, -1, -1));

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(nprd)
                .addContainerGap())
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(nprd)
                .addContainerGap())
        );

        jPanel29.add(jPanel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, -1, -1));

        BottomTrigger2.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 11)); // NOI18N
        BottomTrigger2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/trigger.png"))); // NOI18N
        BottomTrigger2.setText("TRIGGER");
        BottomTrigger2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BottomTrigger2.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        BottomTrigger2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BottomTriggerActionPerformed(evt);
            }
        });
        jPanel29.add(BottomTrigger2, new org.netbeans.lib.awtextra.AbsoluteConstraints(61, 0, 90, 75));

        BottomProcedura2.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 10)); // NOI18N
        BottomProcedura2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/procedura.png"))); // NOI18N
        BottomProcedura2.setText("PROCEDURA");
        BottomProcedura2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BottomProcedura2.setIconTextGap(6);
        BottomProcedura2.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        BottomProcedura2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BottomProceduraActionPerformed(evt);
            }
        });
        jPanel29.add(BottomProcedura2, new org.netbeans.lib.awtextra.AbsoluteConstraints(61, 230, 90, 75));

        BottomFunzione2.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 9)); // NOI18N
        BottomFunzione2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/asserzione.png"))); // NOI18N
        BottomFunzione2.setText("ASSERZIONE");
        BottomFunzione2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BottomFunzione2.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        BottomFunzione2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BottomFunzioneActionPerformed(evt);
            }
        });
        jPanel29.add(BottomFunzione2, new org.netbeans.lib.awtextra.AbsoluteConstraints(61, 115, 90, 75));

        BottomSequenza.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 10)); // NOI18N
        BottomSequenza.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/sequenza.png"))); // NOI18N
        BottomSequenza.setText("SEQUENZA");
        BottomSequenza.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BottomSequenza.setIconTextGap(6);
        BottomSequenza.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        BottomSequenza.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BottomSequenzaBottomProceduraActionPerformed(evt);
            }
        });
        jPanel29.add(BottomSequenza, new org.netbeans.lib.awtextra.AbsoluteConstraints(61, 345, 90, 75));

        javax.swing.GroupLayout jPanel35Layout = new javax.swing.GroupLayout(jPanel35);
        jPanel35.setLayout(jPanel35Layout);
        jPanel35Layout.setHorizontalGroup(
            jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel35Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(nsqz)
                .addContainerGap())
        );
        jPanel35Layout.setVerticalGroup(
            jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel35Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(nsqz)
                .addContainerGap())
        );

        jPanel29.add(jPanel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 370, -1, -1));

        BottomUtente.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 11)); // NOI18N
        BottomUtente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/resource/utenti.png"))); // NOI18N
        BottomUtente.setText("UTENTE");
        BottomUtente.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BottomUtente.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        BottomUtente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BottomUtenteActionPerformed(evt);
            }
        });
        jPanel29.add(BottomUtente, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 460, 90, 75));

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(nusr)
                .addContainerGap())
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(nusr)
                .addContainerGap())
        );

        jPanel29.add(jPanel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 490, -1, -1));

        getContentPane().add(jPanel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(1109, 100, 170, 610));

        jPanel30.setBackground(new java.awt.Color(178, 38, 38));

        javax.swing.GroupLayout jPanel30Layout = new javax.swing.GroupLayout(jPanel30);
        jPanel30.setLayout(jPanel30Layout);
        jPanel30Layout.setHorizontalGroup(
            jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        jPanel30Layout.setVerticalGroup(
            jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 700, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(1250, 0, 10, 700));

        jPanel19.setBackground(new java.awt.Color(178, 38, 38));
        jPanel19.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(jPanel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(1260, 0, 20, 700));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void BottomUtenteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BottomUtenteActionPerformed
        jTabbedPane2.setSelectedIndex(5) ;  // TODO add your handling code here:
    }//GEN-LAST:event_BottomUtenteActionPerformed

    private void BottomVistaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BottomVistaActionPerformed
        jTabbedPane2.setSelectedIndex(6) ;
        try {
             jComboBoxDb2.removeAllItems();
             Show_Db_In_JCombo2();
             
             // TODO add your handling code here:
         } catch (SQLException ex) {
             Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
         }

// TODO add your handling code here:
    }//GEN-LAST:event_BottomVistaActionPerformed

    private void BottomTabellaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BottomTabellaActionPerformed
        jTabbedPane2.setSelectedIndex(2) ;
         try {
             jComboBox_db.removeAllItems();
             Show_db_In_JCombo();
             
             // TODO add your handling code here:
         } catch (SQLException ex) {
             Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
         }
    }//GEN-LAST:event_BottomTabellaActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       jTabbedPane2.setSelectedIndex(0) ; // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void BottomAttributoActionPerformed1(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BottomAttributoActionPerformed1
        

 jTabbedPane2.setSelectedIndex(7) ;
 pushKey.setSelected(true);
 jTabbedPane1.setSelectedIndex(3) ;
 /* panelPk.setVisible(false);
  panelFk.setVisible(false);
  panelCheck.setVisible(false);
  jTabbedPane1.setSelectedIndex(3); */
  jComboBoxAttributoDominio.removeAllItems();
  Show_Domain_In_JComboAttributoDomain();
  jComboBoxAttributoTabella.removeAllItems();
  Show_Table_In_JComboAttributo();

// TODO add your handling code here:
    }//GEN-LAST:event_BottomAttributoActionPerformed1

    private void BottomDatabaseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BottomDatabaseActionPerformed
        jTabbedPane2.setSelectedIndex(1) ;   
       
        DefaultTableModel model = (DefaultTableModel)JTable1.getModel();
                model.setRowCount(0);
         try {
             Show_Db_In_JTable();
         } catch (SQLException ex) {
             Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
         }
        
        
    }//GEN-LAST:event_BottomDatabaseActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
      jTabbedPane2.setSelectedIndex(8) ; 
      textStandard.disable();
      textPersonalizzato.disable();
      
// TODO add your handling code here:
    }//GEN-LAST:event_jButton5ActionPerformed

    private void BottomSequenzaBottomProceduraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BottomSequenzaBottomProceduraActionPerformed
      jTabbedPane2.setSelectedIndex(9) ;
        attributoSequenza.disable();  // TODO add your handling code here:
        tabellaSequenza.removeAllItems();
        Show_Table_In_JComboSequenza();
        attributoSequenza.removeAllItems();
        Show_Attribute_In_JComboSequenza();
        
        
    }//GEN-LAST:event_BottomSequenzaBottomProceduraActionPerformed

    private void BottomFunzioneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BottomFunzioneActionPerformed
         try {
             jTabbedPane2.setSelectedIndex(4) ;
             textDbAssertion.removeAllItems();
             Show_Db_In_JCombo3();// TODO add your handling code here:
         } catch (SQLException ex) {
             Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
         }
    }//GEN-LAST:event_BottomFunzioneActionPerformed

    private void BottomProceduraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BottomProceduraActionPerformed
         try {
             jTabbedPane2.setSelectedIndex(10) ;
             jComboBoxDbProcedura.removeAllItems();
             Show_Db_In_JComboSProcedure();
             
// TODO add your handling code here:
         } catch (SQLException ex) {
             Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
         }
    }//GEN-LAST:event_BottomProceduraActionPerformed

    private void BottomTriggerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BottomTriggerActionPerformed
        jTabbedPane2.setSelectedIndex(3) ;
        jComboBoxTriggerTabella.disable();
        jComboBoxTriggerVista.disable();
        jComboBoxTriggerTabella.removeAllItems();
        Show_Table_In_JComboTriggers();
        jComboBoxTriggerVista.removeAllItems();
          Show_View_In_JComboTriggers();

        // TODO add your handling code here:
    }//GEN-LAST:event_BottomTriggerActionPerformed

    private void comboRTabellaItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_comboRTabellaItemStateChanged
        if(evt.getStateChange() == ItemEvent.SELECTED)
        {
            comboRAttributo.removeAllItems();
            RiempiRAttributo();

        }
    }//GEN-LAST:event_comboRTabellaItemStateChanged

    private void textTabellaFkItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_textTabellaFkItemStateChanged
        if(evt.getStateChange() == ItemEvent.SELECTED)
        {

            textAttributoFk.removeAllItems();
            RiempiTextAttributo();

        }
    }//GEN-LAST:event_textTabellaFkItemStateChanged

    private void tabellaFkKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tabellaFkKeyReleased
        if(evt.getKeyCode() == KeyEvent.VK_UP|| evt.getKeyCode() == KeyEvent.VK_DOWN )
        {

            int i = tabellaFk.getSelectedRow();
            TableModel model= tabellaFk.getModel();
            nomeFk.setText(model.getValueAt(i,0).toString());

        }
    }//GEN-LAST:event_tabellaFkKeyReleased

    private void tabellaFkMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabellaFkMouseClicked
        int i = tabellaFk.getSelectedRow();
        TableModel model= tabellaFk.getModel();
        nomeFk.setText(model.getValueAt(i,0).toString());
    }//GEN-LAST:event_tabellaFkMouseClicked

    private void textAttributoFkItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_textAttributoFkItemStateChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_textAttributoFkItemStateChanged

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            try ( // establish connection
                Connection con = getDefaultConnection();
                Statement statement = con.createStatement()) {
                statement.executeUpdate("DELETE FROM FOREIGNKEY WHERE Nome_fk= '"+nomeFk.getText()+"'");
                JOptionPane.showMessageDialog(null, "Eseguito correttamente.");
                DefaultTableModel model = (DefaultTableModel)tabellaFk.getModel();
                model.setRowCount(0);
                Show_Fk_In_JTable();
            }
            //Calling Referesh() method
        } catch (SQLException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, e);
        }

    }//GEN-LAST:event_jButton6ActionPerformed

    private void addFkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addFkActionPerformed
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            try ( // establish connection
                Connection con = getDefaultConnection();
                Statement statement = con.createStatement()) {

               
                if(textTabellaFk.getSelectedItem().toString().equals("Seleziona") || comboRTabella.getSelectedItem().toString().equals("Seleziona")|| textAttributoFk.getSelectedItem().toString().equals("Seleziona")|| comboRAttributo.getSelectedItem().toString().equals("Seleziona") )
                    JOptionPane.showMessageDialog(null, "Riempire campo obbligatorio.");
                
                else if(!textTabellaFk.getSelectedItem().toString().equals("Seleziona") && !comboRTabella.getSelectedItem().toString().equals("Seleziona") && !textAttributoFk.getSelectedItem().toString().equals("Seleziona") && !comboRAttributo.getSelectedItem().toString().equals("Seleziona"))
                { 
                   //funzione split();

                String str1= (String) textTabellaFk.getSelectedItem();
                String[] strSplit= str1.split(":");
                String p1= strSplit[0];

                //funzione split();

                String strin2= (String) textAttributoFk.getSelectedItem();
                String[] strinSplit= strin2.split(":");
                String p2= strinSplit[0];

                //funzione split();

                String str3= (String) comboRTabella.getSelectedItem();
                String[] striSplit= str3.split(":");
                String p3= striSplit[0];

                //funzione split();

                String strin4= (String) comboRAttributo.getSelectedItem();
                String[] stSplit= strin4.split(":");
                String p4= stSplit[0];
  
                    statement.executeUpdate("INSERT INTO FOREIGNKEY(Nome_Fk,id_tabella,id_attributo,RTabella, RAttributo,posizione) VALUES('"+nomeFk.getText()+"'," +p1+ "," +p2+ "," +p3 + "," +p4+ ","+comboPosAttributo.getSelectedItem()+ ")");
                JOptionPane.showMessageDialog(null, "Eseguito correttamente.");
                
                DefaultTableModel model = (DefaultTableModel)tabellaFk.getModel();
                model.setRowCount(0);
                Show_Fk_In_JTable();
            }}
            //Calling Referesh() method
        } catch (SQLException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, e);
        }      // TODO add your handling code here:
    }//GEN-LAST:event_addFkActionPerformed

    private void tabellaCheckItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_tabellaCheckItemStateChanged
        if(evt.getStateChange() == ItemEvent.SELECTED)
        {

            attributoCheck.removeAllItems();
            RiempiAttributoCheck();

        }
    }//GEN-LAST:event_tabellaCheckItemStateChanged

    private void deleteCheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteCheckActionPerformed
         try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            try ( // establish connection
                Connection con = getDefaultConnection();
                Statement statement = con.createStatement()) {
                statement.executeUpdate("DELETE FROM VCHECK WHERE nome= '"+nomeCheck.getText().toString()+"'");
                JOptionPane.showMessageDialog(null, "Eseguito correttamente.");
                DefaultTableModel model = (DefaultTableModel)jTableCheck.getModel();
                model.setRowCount(0);
              Show_Check_In_JTable();
              nomeCheck.setText("");
              descrizioneCheck.setText("");
              codiceSqlCheck.setText("");
            }
            //Calling Referesh() method
        } catch (SQLException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_deleteCheckActionPerformed

    private void addProcedureBottom1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addProcedureBottom1ActionPerformed
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            try ( // establish connection
                Connection con = getDefaultConnection();
                Statement statement = con.createStatement()) {

                if(nomeCheck.getText().length()==0)
                     JOptionPane.showMessageDialog(null, "Inserire Nome Check.");
                else{
                    
                        if(tabellaCheck.getSelectedItem().toString().equals("Seleziona")||attributoCheck.getSelectedItem().toString().equals("Seleziona")||!attributoCheck.isEnabled())
                         JOptionPane.showMessageDialog(null, "Riempire campo obbligatorio.");
                        else if(!tabellaCheck.getSelectedItem().toString().equals("Seleziona")||!attributoCheck.getSelectedItem().toString().equals("Seleziona")||attributoCheck.isEnabled())
                        {
                
                
                
                
                //funzione split();

                String str= (String) attributoCheck.getSelectedItem();
                String[] strSplit= str.split(":");
                String p1= strSplit[0];

                statement.executeUpdate("INSERT INTO VCHECK (nome,descrizione, id_attributo,codice_sql) VALUES('" +nomeCheck.getText() + "','" +descrizioneCheck.getText() + "'," +p1 + ",'" +codiceSqlCheck.getText() + "')");
                JOptionPane.showMessageDialog(null, "Eseguito correttamente.");
                DefaultTableModel model = (DefaultTableModel)jTableCheck.getModel();
                model.setRowCount(0);
                Show_Check_In_JTable();
            }}}
            //Calling Referesh() method
        } catch (SQLException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_addProcedureBottom1ActionPerformed

    private void nomeCheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nomeCheckActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nomeCheckActionPerformed

    private void valueProceduraKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_valueProceduraKeyReleased
        jTable7.setModel(new DefaultTableModel(null,new Object[] {"ID","NOME","DESCRIZIONE","CODICE SQL","DATABASE"}));

        try {
            String valueToSearch=  valueProcedura.getText().toString();
            System.out.println(valueToSearch);
            Search_SProcedure_in_JTable7(jTable7,valueToSearch);

        } catch (SQLException ex) {
            Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_valueProceduraKeyReleased

    private void valueProceduraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_valueProceduraActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_valueProceduraActionPerformed

    private void addProcedureBottomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addProcedureBottomActionPerformed

        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            try ( // establish connection
                Connection con = getDefaultConnection();
                Statement statement = con.createStatement()) {

                
                if(textIdProcedura.getText().length()==0 || textNomeProcedura.getText().length()==0)
                     JOptionPane.showMessageDialog(null, "Campo obbligatorio assente.");
                //funzione split();
                else if(textIdProcedura.getText().length()>0 && textNomeProcedura.getText().length()>0){
                    
                    
                     if( jComboBoxDbProcedura.getSelectedItem().toString().equals("Seleziona"))
                            JOptionPane.showMessageDialog(null, "Seleziona il Database.");
                        else{
                             String str= (String) jComboBoxDbProcedura.getSelectedItem();
                             String[] strSplit= str.split(":");
                             String p1= strSplit[0];

                             statement.executeUpdate("INSERT INTO PROCEDURA (id_procedura,nome,descrizione, codice_sql,id_db) VALUES(" +textIdProcedura.getText() + ",'" +textNomeProcedura.getText() + "','" +textDescrizioneProcedura.getText() + "','" +textCodiceSqlProcedura.getText() + "','"+p1+"')");
                             JOptionPane.showMessageDialog(null, "Eseguito correttamente.");
                             DefaultTableModel model = (DefaultTableModel)jTable7.getModel();
                             model.setRowCount(0);
                             Show_SProcedure_In_JTable();
            }}}
            //Calling Referesh() method
        } catch (SQLException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        try {
            Scelta.nprd.setText(""+Integer.toString(CountFunction.countDb("PROCEDURA")));
        } catch (SQLException ex) {
            Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_addProcedureBottomActionPerformed

    private void deleteProcedureBottomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteProcedureBottomActionPerformed
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            try ( // establish connection
                Connection con = getDefaultConnection();
                Statement statement = con.createStatement()) {
                statement.executeUpdate("DELETE FROM PROCEDURA WHERE id_procedura= "+textIdProcedura.getText());
                JOptionPane.showMessageDialog(null, "Eseguito correttamente.");
                DefaultTableModel model = (DefaultTableModel)jTable7.getModel();
                model.setRowCount(0);
                Show_SProcedure_In_JTable();
            }
            //Calling Referesh() method
        } catch (SQLException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        try {
            Scelta.nprd.setText(""+Integer.toString(CountFunction.countDb("PROCEDURA")));
        } catch (SQLException ex) {
            Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
        }           // TODO add your handling code here:
    }//GEN-LAST:event_deleteProcedureBottomActionPerformed

    private void editProcedureBottomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editProcedureBottomActionPerformed
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            try ( // establish connection
                Connection con = getDefaultConnection();
                Statement statement = con.createStatement()) {
                
                
                   if(textIdProcedura.getText().length()==0 || textNomeProcedura.getText().length()==0)
                     JOptionPane.showMessageDialog(null, "Campo obbligatorio assente.");
                //funzione split();
                else if(textIdProcedura.getText().length()>0 && textNomeProcedura.getText().length()>0){
                    
                    
                     if( jComboBoxDbProcedura.getSelectedItem().toString().equals("Seleziona"))
                            JOptionPane.showMessageDialog(null, "Seleziona il Database.");
                        else{
                    String str= (String) jComboBoxDbProcedura.getSelectedItem();
                    String[] strSplit= str.split(":");
                    String p1= strSplit[0];

                    statement.executeUpdate("UPDATE PROCEDURA SET nome='"+textNomeProcedura.getText()+"', descrizione= '"+textDescrizioneProcedura.getText()+"',codice_sql='"+textCodiceSqlProcedura.getText()+"',id_db="+p1+" WHERE id_procedura='"+textIdProcedura.getText()+"'");

                    JOptionPane.showMessageDialog(null, "Eseguito correttamente.");
                    DefaultTableModel model = (DefaultTableModel)jTable7.getModel();
                    model.setRowCount(0);
                    Show_SProcedure_In_JTable();
            }}}
            //Calling Referesh() method
        } catch (SQLException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_editProcedureBottomActionPerformed

    private void jComboBoxDbProceduraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxDbProceduraActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxDbProceduraActionPerformed

    private void textNomeProceduraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textNomeProceduraActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textNomeProceduraActionPerformed

    private void textIdProceduraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textIdProceduraActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textIdProceduraActionPerformed

    private void jTable7KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable7KeyReleased
        if(evt.getKeyCode() == KeyEvent.VK_UP|| evt.getKeyCode() == KeyEvent.VK_DOWN )
        {

            int i = jTable7.getSelectedRow();
            TableModel model= jTable7.getModel();
            textIdProcedura.setText(model.getValueAt(i,0).toString());
            textNomeProcedura.setText(model.getValueAt(i,1).toString());
            textDescrizioneProcedura.setText(model.getValueAt(i,2).toString());
            textCodiceSqlProcedura.setText(model.getValueAt(i,3).toString());
            jComboBoxDbProcedura.setSelectedItem(model.getValueAt(i,4).toString());

        }

        // TODO add your handling code here:
    }//GEN-LAST:event_jTable7KeyReleased

    private void jTable7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable7MouseClicked
        // mostro la selezione in jtext;
        int i = jTable7.getSelectedRow();
        TableModel model= jTable7.getModel();
        textIdProcedura.setText(model.getValueAt(i,0).toString());
        textNomeProcedura.setText(model.getValueAt(i,1).toString());
        textDescrizioneProcedura.setText(model.getValueAt(i,2).toString());
        textCodiceSqlProcedura.setText(model.getValueAt(i,3).toString());
        jComboBoxDbProcedura.setSelectedItem(model.getValueAt(i,4).toString());

        // TODO add your handling code here:
    }//GEN-LAST:event_jTable7MouseClicked

    private void valueSequenzaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_valueSequenzaKeyReleased
     jTableSequenza.setModel(new DefaultTableModel(null,new Object[] {"NOME","START WITH","INCREMENT","MIN","MAX","ATTRIBUTO"})) ;       

        try {
            String valueToSearch=  valueSequenza.getText().toString();
            System.out.println(valueToSearch);
            Search_Sequence_in_JTable1(jTableSequenza,valueToSearch);

            // TODO add your handling code here:
        } catch (SQLException ex) {
            Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_valueSequenzaKeyReleased

    private void valueSequenzaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_valueSequenzaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_valueSequenzaActionPerformed

    private void deleteSequenzaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteSequenzaActionPerformed
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            try ( // establish connection
                Connection con = getDefaultConnection();
                Statement statement = con.createStatement()) {
                  statement.executeUpdate("DELETE FROM SEQUENZA WHERE nome= '"+nomeSequenza.getText()+"'");
                JOptionPane.showMessageDialog(null, "Eseguito correttamente.");
              DefaultTableModel model = (DefaultTableModel)jTableSequenza.getModel();
                model.setRowCount(0);
                Show_Sequenza_In_JTable();
            }
            //Calling Referesh() method
        } catch (SQLException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        try {
            Scelta.nsqz.setText(""+Integer.toString(CountFunction.countDb("SEQUENZA")));
        } catch (SQLException ex) {
            Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_deleteSequenzaActionPerformed

    private void editSequenzaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editSequenzaActionPerformed
        
       try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            try ( // establish connection
                Connection con = getDefaultConnection();
                Statement statement = con.createStatement()) {

                if(nomeSequenza.getText().length()==0 || iniziadaSequenza.getText().length()==0 ||incrementadiSequenza.getText().length()==0 ||valoreminSequenza.getText().length()==0 ||valoremaxSequenza.getText().length()==0)
                JOptionPane.showMessageDialog(null, "Campo abbligatorio mancante.");
                else if(nomeSequenza.getText().length()>0 && iniziadaSequenza.getText().length()>0 && incrementadiSequenza.getText().length()>0 && valoreminSequenza.getText().length()>0 && valoremaxSequenza.getText().length()>0)
                {
                    
                if(tabellaSequenza.getSelectedItem().toString().equals("Seleziona")||attributoSequenza.getSelectedItem().toString().equals("Seleziona"))
                    JOptionPane.showMessageDialog(null, "Selezione Attributo mancante.");
                //funzione split();
                else{
                String str= (String) attributoSequenza.getSelectedItem();
                String[] strSplit= str.split(":");
                String p1= strSplit[0];

                statement.executeUpdate("UPDATE SEQUENZA SET startwith= "+iniziadaSequenza.getText() + ",incremento= " +incrementadiSequenza.getText() + ",minval= "+valoreminSequenza.getText()+",maxval="+valoremaxSequenza.getText()+",id_attributo="+p1+" WHERE nome= '"+nomeSequenza.getText()+"'");
                JOptionPane.showMessageDialog(null, "Eseguito correttamente.");
                DefaultTableModel model = (DefaultTableModel)jTableSequenza.getModel();
                model.setRowCount(0);
                Show_Sequenza_In_JTable();
            }}}
            //Calling Referesh() method
        } catch (SQLException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, e);
        } 
        
    }//GEN-LAST:event_editSequenzaActionPerformed

    private void addSequenzaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addSequenzaActionPerformed
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            try ( // establish connection
                Connection con = getDefaultConnection();
                Statement statement = con.createStatement()) {

                if(nomeSequenza.getText().length()==0 || iniziadaSequenza.getText().length()==0 ||incrementadiSequenza.getText().length()==0 ||valoreminSequenza.getText().length()==0 ||valoremaxSequenza.getText().length()==0)
                JOptionPane.showMessageDialog(null, "Campo abbligatorio mancante.");
                else if(nomeSequenza.getText().length()>0 && iniziadaSequenza.getText().length()>0 && incrementadiSequenza.getText().length()>0 && valoreminSequenza.getText().length()>0 && valoremaxSequenza.getText().length()>0)
                {
                    
                if(tabellaSequenza.getSelectedItem().toString().equals("Seleziona")||attributoSequenza.getSelectedItem().toString().equals("Seleziona"))
                    JOptionPane.showMessageDialog(null, "Selezione Attributo mancante.");
                //funzione split();
                else{
                String str= (String) attributoSequenza.getSelectedItem();
                String[] strSplit= str.split(":");
                String p1= strSplit[0];

                statement.executeUpdate("INSERT INTO SEQUENZA (nome,startwith,incremento,minval,maxval,id_attributo) VALUES('" +nomeSequenza.getText()+ "'," +iniziadaSequenza.getText() + "," +incrementadiSequenza.getText() + ","+valoreminSequenza.getText()+","+valoremaxSequenza.getText()+","+p1+")");
                JOptionPane.showMessageDialog(null, "Eseguito correttamente.");
                DefaultTableModel model = (DefaultTableModel)jTableSequenza.getModel();
                model.setRowCount(0);
                Show_Sequenza_In_JTable();
            }}}
            //Calling Referesh() method
        } catch (SQLException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_addSequenzaActionPerformed

    private void tabellaSequenzaItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_tabellaSequenzaItemStateChanged
        if(evt.getStateChange() == ItemEvent.SELECTED)
        {

            attributoSequenza.removeAllItems();
            RiempiAttributoSequenza();

        }
    }//GEN-LAST:event_tabellaSequenzaItemStateChanged

    private void valoreminSequenzaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_valoreminSequenzaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_valoreminSequenzaActionPerformed

    private void valoremaxSequenzaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_valoremaxSequenzaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_valoremaxSequenzaActionPerformed

    private void incrementadiSequenzaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_incrementadiSequenzaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_incrementadiSequenzaActionPerformed

    private void iniziadaSequenzaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iniziadaSequenzaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_iniziadaSequenzaActionPerformed

    private void nomeSequenzaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nomeSequenzaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nomeSequenzaActionPerformed

    private void valueDominioKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_valueDominioKeyReleased
        jTable11.setModel(new DefaultTableModel(null,new Object[] {"ID","NOME","DESCRIZIONE","FORMATO"}));

        try {
            String valueToSearch=  valueDominio.getText().toString();
            System.out.println(valueToSearch);
            Search_Domain_in_JTable11( jTable11,valueToSearch);

            // TODO add your handling code here:
        } catch (SQLException ex) {
            Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_valueDominioKeyReleased

    private void valueDominioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_valueDominioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_valueDominioActionPerformed

    private void jTable11KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable11KeyReleased
        if(evt.getKeyCode() == KeyEvent.VK_UP|| evt.getKeyCode() == KeyEvent.VK_DOWN )
        {

            int i = jTable11.getSelectedRow();
            TableModel model= jTable11.getModel();
            textIdDominio.setText(model.getValueAt(i,0).toString());
            textNomeDominio.setText(model.getValueAt(i,1).toString());
            textDescrizioneDominio.setText(model.getValueAt(i,2).toString());
            if(standard.isSelected())
            textStandard.setSelectedItem(model.getValueAt(i,3).toString());
            if(personalizzato.isSelected())
            textPersonalizzato.setText(model.getValueAt(i,3).toString());

        }

        // TODO add your handling code here:
    }//GEN-LAST:event_jTable11KeyReleased

    private void jTable11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable11MouseClicked
        int i = jTable11.getSelectedRow();
        TableModel model= jTable11.getModel();
        textIdDominio.setText(model.getValueAt(i,0).toString());
        textNomeDominio.setText(model.getValueAt(i,1).toString());
        textDescrizioneDominio.setText(model.getValueAt(i,2).toString());
        if(standard.isSelected())
        textStandard.setSelectedItem(model.getValueAt(i,3).toString());
        else
        textPersonalizzato.setText(model.getValueAt(i,3).toString());
    }//GEN-LAST:event_jTable11MouseClicked

    private void personalizzatoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_personalizzatoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_personalizzatoActionPerformed

    private void personalizzatoItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_personalizzatoItemStateChanged
        if(personalizzato.isSelected())
        {

            textPersonalizzato.enable();
            textStandard.disable();
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_personalizzatoItemStateChanged

    private void standardItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_standardItemStateChanged
        if(standard.isSelected())
        {

            textStandard.enable();
            textPersonalizzato.disable();

        }

        // TODO add your handling code here:
    }//GEN-LAST:event_standardItemStateChanged

    private void deleteDominioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteDominioActionPerformed
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            try ( // establish connection
                Connection con = getDefaultConnection();
                Statement statement = con.createStatement()) {
                statement.executeUpdate("DELETE FROM DOMINIO WHERE id_dominio= "+textIdDominio.getText());
                JOptionPane.showMessageDialog(null, "Eseguito correttamente.");
                DefaultTableModel model = (DefaultTableModel)jTable11.getModel();
                model.setRowCount(0);
                Show_Dominio_In_JTable();
            }
            //Calling Referesh() method
        } catch (SQLException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        try {
            Scelta.ndmn.setText(""+Integer.toString(CountFunction.countDb("DOMINIO")));
        } catch (SQLException ex) {
            Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_deleteDominioActionPerformed

    private void editDominioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editDominioActionPerformed
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            try ( // establish connection
                Connection con = getDefaultConnection();
                Statement statement = con.createStatement()) {

                if(!standard.isSelected()&& !personalizzato.isSelected())
                JOptionPane.showMessageDialog(null, "SELEZIONARE IL DOMINIO.");

                if(standard.isSelected()){
                    statement.executeUpdate("UPDATE DOMINIO SET Nome='"+textNomeDominio.getText()+"',Descrizione='"+textDescrizioneDominio.getText()+"', Formato='"+textStandard.getSelectedItem().toString()+"' WHERE id_dominio='"+textIdDominio.getText()+"'");
                    JOptionPane.showMessageDialog(null, "Eseguito correttamente.");}

                else if(personalizzato.isSelected())
                {  statement.executeUpdate("UPDATE DOMINIO SET Nome='"+textNomeDominio.getText()+"',Descrizione='"+textDescrizioneDominio.getText()+"', Formato='"+textPersonalizzato.getText()+"' WHERE id_dominio='"+textIdDominio.getText()+"'");
                    JOptionPane.showMessageDialog(null, "Eseguito correttamente.");}

                DefaultTableModel model = (DefaultTableModel)jTable11.getModel();
                model.setRowCount(0);
                Show_Dominio_In_JTable();
            }
            //Calling Referesh() method
        } catch (SQLException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_editDominioActionPerformed

    private void addDominioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addDominioActionPerformed
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            try ( // establish connection
                Connection con = getDefaultConnection();
                Statement statement = con.createStatement()) {
                if(standard.isSelected()){
                    statement.executeUpdate("INSERT INTO DOMINIO (id_dominio,nome,descrizione,formato) VALUES(" +textIdDominio.getText() + ",'" +textNomeDominio.getText() + "','" +textDescrizioneDominio.getText() + "','"+textStandard.getSelectedItem().toString()+"')");
                    JOptionPane.showMessageDialog(null, "Eseguito correttamente.");
                }
                else
                {
                    statement.executeUpdate("INSERT INTO DOMINIO (id_dominio,nome,descrizione,formato) VALUES(" +textIdDominio.getText() + ",'" +textNomeDominio.getText() + "','" +textDescrizioneDominio.getText() + "','"+textPersonalizzato.getText()+"')");
                    JOptionPane.showMessageDialog(null, "Eseguito correttamente.");
                }

                DefaultTableModel model = (DefaultTableModel)jTable11.getModel();
                model.setRowCount(0);
               Show_Dominio_In_JTable();
            }
            //Calling Referesh() method
        } catch (SQLException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        /* try {
            Scelta.ndb.setText(""+Integer.toString(CountFunction.countDb("ATTRIBUTO")));
        } catch (SQLException ex) {
            Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
        }

        */

        // TODO add your handling code here:
    }//GEN-LAST:event_addDominioActionPerformed

    private void textDescrizioneDominioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textDescrizioneDominioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textDescrizioneDominioActionPerformed

    private void textNomeDominioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textNomeDominioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textNomeDominioActionPerformed

    private void textIdDominioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textIdDominioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textIdDominioActionPerformed

    private void pushKeyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pushKeyActionPerformed
        jTabbedPane1.setSelectedIndex(3);
    }//GEN-LAST:event_pushKeyActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        jTabbedPane2.setSelectedIndex(11);
        nomeCheck.setText(textNomeCheck.getText());
        descrizioneCheck.setText(textDescrizioneCheck.getText());
    }//GEN-LAST:event_jButton4ActionPerformed

    private void textNomeCheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textNomeCheckActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textNomeCheckActionPerformed

    private void textDescrizioneCheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textDescrizioneCheckActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textDescrizioneCheckActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        jTabbedPane2.setSelectedIndex(12);
        nomeFk.setText(nomeFkAttributo.getText());
        
    }//GEN-LAST:event_jButton3ActionPerformed

    private void textNomePkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textNomePkActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textNomePkActionPerformed

    private void boxCheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boxCheckActionPerformed
        if(boxCheck.isSelected())
        jTabbedPane1.setSelectedIndex(2);

        // TODO add your handling code here:
    }//GEN-LAST:event_boxCheckActionPerformed

    private void boxFkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boxFkActionPerformed
        if(boxFk.isSelected()){
            jTabbedPane1.setSelectedIndex(1);
            comboRAttributo.disable();

        }

        // TODO add your handling code here:
    }//GEN-LAST:event_boxFkActionPerformed

    private void boxPkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boxPkActionPerformed
        if(boxPk.isSelected()) {
            jTabbedPane1.setSelectedIndex(0);
        }
    }//GEN-LAST:event_boxPkActionPerformed

    private void valueAttributoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_valueAttributoKeyReleased

        jTable10.setModel(new DefaultTableModel(null,new Object[] {"ID","NOME","DEFAULT","TABELLA","DOMINIO","PK","NOME PK","POSIZIONE PK"}));

        try {
            String valueToSearch=  valueAttributo.getText().toString();
            System.out.println(valueToSearch);
            Search_Attribute_in_JTable10( jTable10,valueToSearch);

            // TODO add your handling code here:
        } catch (SQLException ex) {
            Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_valueAttributoKeyReleased

    private void valueAttributoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_valueAttributoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_valueAttributoActionPerformed

    private void jComboBoxAttributoDominioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxAttributoDominioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxAttributoDominioActionPerformed

    private void deleteAttributoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteAttributoActionPerformed

        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            try ( // establish connection
                Connection con = getDefaultConnection();
                Statement statement = con.createStatement()) {
                statement.executeUpdate("DELETE FROM ATTRIBUTO WHERE id_attributo= "+textIdAttributo.getText());
                JOptionPane.showMessageDialog(null, "Eseguito correttamente.");
                DefaultTableModel model = (DefaultTableModel)jTable10.getModel();
                model.setRowCount(0);
                Show_Attribute_In_JTable();
            }
            //Calling Referesh() method
        } catch (SQLException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        try {
            Scelta.natt.setText(""+Integer.toString(CountFunction.countDb("ATTRIBUTO")));
        } catch (SQLException ex) {
            Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_deleteAttributoActionPerformed

    private void editAttributoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editAttributoActionPerformed

        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            try ( // establish connection
                Connection con = getDefaultConnection();
                Statement statement = con.createStatement()) {
                //funzione split();

                String str= (String) jComboBoxAttributoTabella.getSelectedItem();
                String[] strSplit= str.split(":");
                String p1= strSplit[0];

                //funzione split();

                String strin= (String) jComboBoxAttributoDominio.getSelectedItem();
                String[] strinSplit= strin.split(":");
                String p= strinSplit[0];

                if(pushKey.isSelected()){
                    statement.executeUpdate("UPDATE ATTRIBUTO SET Nome= '"+textNomeAttributo.getText()+"', Defoult= '"+jComboBoxDefaultAttributo.getSelectedItem()+"',id_dominio= "+p+",id_tabella="+p1+",PK= NULL, nome_pk = NULL, posizione_pk=NULL WHERE id_attributo= "+textIdAttributo.getText());
                    DefaultTableModel model = (DefaultTableModel)jTable10.getModel();
                    model.setRowCount(0);
                    Show_Attribute_In_JTable();}
                else if(boxPk.isSelected() && !pushKey.isSelected()){

                    statement.executeUpdate("UPDATE ATTRIBUTO SET Nome= '"+textNomeAttributo.getText()+"', Defoult= 'NOT NIL',id_dominio= "+p+",id_tabella="+p1+", PK='*', nome_pk= '"+textNomePk.getText()+"', posizione_pk="+comboPosizionePk.getSelectedItem()+"  WHERE id_attributo= "+textIdAttributo.getText());
                    JOptionPane.showMessageDialog(null, "Eseguito correttamente.");
                    DefaultTableModel model = (DefaultTableModel)jTable10.getModel();
                    model.setRowCount(0);
                    Show_Attribute_In_JTable();
                }  }
                //Calling Referesh() method
            } catch (SQLException | ClassNotFoundException e) {
                JOptionPane.showMessageDialog(null, e);
            }

            try {
                Scelta.nass.setText(""+Integer.toString(CountFunction.countDb("ATTRIBUTO")));
            } catch (SQLException ex) {
                Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
            }
    }//GEN-LAST:event_editAttributoActionPerformed

    private void addAttributoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addAttributoActionPerformed

        try ( // establish connection
            Connection con = getDefaultConnection();
            Statement statement = con.createStatement()) {
            //funzione split

            if(jComboBoxAttributoDominio.getSelectedItem().equals("Seleziona")|| jComboBoxAttributoTabella.getSelectedItem().equals("Seleziona"))
            JOptionPane.showMessageDialog(null, "Campo obbligatorio da inserire.");
            
            else if(!jComboBoxAttributoDominio.getSelectedItem().equals("Seleziona")|| !jComboBoxAttributoTabella.getSelectedItem().equals("Seleziona"))
            {
            String str1= (String) jComboBoxAttributoDominio.getSelectedItem();
            String[] strSplit= str1.split(":");
            String p1= strSplit[0];

            String str2= (String) jComboBoxAttributoTabella.getSelectedItem();
            String[] str2Split= str2.split(":");
            String p2= str2Split[0];

            if(boxPk.isSelected()){
                if(textNomePk.getText().length()==0)
                    JOptionPane.showMessageDialog(null, "Inserire Nome Primary Key");
                else{    
                jComboBoxDefaultAttributo.setSelectedItem("NOT NULL");
                Object s=jComboBoxDefaultAttributo.getSelectedItem();
                System.out.println(s);
                  
                statement.executeUpdate("INSERT INTO ATTRIBUTO(id_attributo,Nome,Defoult,id_tabella, id_dominio,PK, nome_pk,posizione_pk) VALUES(" +textIdAttributo.getText() + ",'" +textNomeAttributo.getText() + "','NOT NULL', " +p2+ "," +p1+ ", '*','" +textNomePk.getText() + "'," +comboPosizionePk.getSelectedItem() + " )");
                JOptionPane.showMessageDialog(null, "Eseguito correttamente.");
                }
            }

            else if(!boxPk.isSelected()){
                 statement.executeUpdate("INSERT INTO ATTRIBUTO(id_attributo,Nome,Defoult,id_tabella, id_dominio,PK, nome_pk,posizione_pk) VALUES(" +textIdAttributo.getText() + ",'" +textNomeAttributo.getText() + "','"+jComboBoxDefaultAttributo.getSelectedItem()+ "', " +p2+ "," +p1+ ", null,null,null )");
                JOptionPane.showMessageDialog(null, "Eseguito correttamente.");
                  System.out.println("INSERITA no PK");
            }

            DefaultTableModel model = (DefaultTableModel)jTable10.getModel();
            model.setRowCount(0);
            Show_Attribute_In_JTable();
            pushKey.setSelected(true);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        try {
            Scelta.natt.setText(""+Integer.toString(CountFunction.countDb("ATTRIBUTO")));
        } catch (SQLException ex) {
            Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_addAttributoActionPerformed

    private void jComboBoxAttributoTabellaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxAttributoTabellaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxAttributoTabellaActionPerformed

    private void textNomeAttributoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textNomeAttributoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textNomeAttributoActionPerformed

    private void textIdAttributoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textIdAttributoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textIdAttributoActionPerformed

    private void jTable10KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable10KeyReleased

        if(evt.getKeyCode() == KeyEvent.VK_UP|| evt.getKeyCode() == KeyEvent.VK_DOWN )
        {

            int i = jTable10.getSelectedRow();
            TableModel model= jTable10.getModel();
            textIdAttributo.setText(model.getValueAt(i,0).toString());
            textNomeAttributo.setText(model.getValueAt(i,1).toString());
            jComboBoxDefaultAttributo.setSelectedItem(model.getValueAt(i,2).toString());
            jComboBoxAttributoTabella.setSelectedItem("Seleziona");
            jComboBoxAttributoDominio.setSelectedItem("Seleziona");
            buttonGroupVincoli.clearSelection();
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_jTable10KeyReleased

    private void jTable10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable10MouseClicked
        int i = jTable10.getSelectedRow();
        TableModel model= jTable10.getModel();
        textIdAttributo.setText(model.getValueAt(i,0).toString());
        textNomeAttributo.setText(model.getValueAt(i,1).toString());
        jComboBoxDefaultAttributo.setSelectedItem(model.getValueAt(i,2).toString());
        jComboBoxAttributoTabella.setSelectedItem("Seleziona");
        jComboBoxAttributoDominio.setSelectedItem("Seleziona");

        // TODO add your handling code here:
    }//GEN-LAST:event_jTable10MouseClicked

    private void valueVistaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_valueVistaKeyReleased
        jTable3.setModel(new DefaultTableModel(null,new Object[] {"ID","NOME","DESCRIZIONE","CODICE SQL","DATABASE"}));

        try {
            String valueToSearch=  valueVista.getText().toString();
            System.out.println(valueToSearch);
            Search_View_in_JTable1(jTable3,valueToSearch);

            // TODO add your handling code here:
        } catch (SQLException ex) {
            Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_valueVistaKeyReleased

    private void valueVistaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_valueVistaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_valueVistaActionPerformed

    private void deleteVistaBottomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteVistaBottomActionPerformed
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            try ( // establish connection
                Connection con = getDefaultConnection();
                Statement statement = con.createStatement()) {
                statement.executeUpdate("DELETE FROM VISTA WHERE id_vista= "+textId_vista.getText());
                JOptionPane.showMessageDialog(null, "Eseguito correttamente.");
                DefaultTableModel model = (DefaultTableModel)jTable3.getModel();
                model.setRowCount(0);
                Show_View_In_JTable();
            }
            //Calling Referesh() method
        } catch (SQLException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        try {
            Scelta.nvst.setText(""+Integer.toString(CountFunction.countDb("VISTA")));
        } catch (SQLException ex) {
            Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_deleteVistaBottomActionPerformed

    private void editVistaBottomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editVistaBottomActionPerformed

        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            try ( // establish connection
                Connection con = getDefaultConnection();
                Statement statement = con.createStatement()) {
               
                if(textId_vista.getText().length()==0 ||jComboBoxDb2.getSelectedItem().toString().equals("Seleziona"))
                     JOptionPane.showMessageDialog(null, "Campo obbligatorio non inserito.");
                else {
                String str= (String) jComboBoxDb2.getSelectedItem();
                String[] strSplit= str.split(":");
                String p1= strSplit[0];

                statement.executeUpdate("UPDATE VISTA SET Nome='"+textNomeVista.getText()+"',Descrizione='"+textDescrizioneVista.getText()+"', Codice_sql='"+textCodiceSqlVista.getText()+"', id_db="+p1+" WHERE id_vista='"+textId_vista.getText()+"'");

                JOptionPane.showMessageDialog(null, "Eseguito correttamente.");
                DefaultTableModel model = (DefaultTableModel)jTable3.getModel();
                model.setRowCount(0);
                Show_View_In_JTable();
            }}
            //Calling Referesh() method
        } catch (SQLException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_editVistaBottomActionPerformed

    private void addVistaBottomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addVistaBottomActionPerformed

        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            try ( // establish connection
                Connection con = getDefaultConnection();
                Statement statement = con.createStatement()) {
                
                if(textId_vista.getText().length()==0 ||jComboBoxDb2.getSelectedItem().toString().equals("Seleziona"))
                     JOptionPane.showMessageDialog(null, "Campo obbligatorio non inserito.");
                else {
                String str= (String) jComboBoxDb2.getSelectedItem();
                String[] strSplit= str.split(":");
                String p1= strSplit[0];

                statement.executeUpdate("INSERT INTO VISTA (id_vista,nome,descrizione, codice_sql,id_db) VALUES(" +textId_vista.getText() + ",'" +textNomeVista.getText() + "','" +textDescrizioneVista.getText() + "','" +textCodiceSqlVista.getText() + "','"+p1+"')");
                JOptionPane.showMessageDialog(null, "Eseguito correttamente.");
                DefaultTableModel model = (DefaultTableModel)jTable3.getModel();
                model.setRowCount(0);
                Show_View_In_JTable();
            }}
            //Calling Referesh() method
        } catch (SQLException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        try {
            Scelta.nvst.setText(""+Integer.toString(CountFunction.countDb("VISTA")));
        } catch (SQLException ex) {
            Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_addVistaBottomActionPerformed

    private void textId_vistaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textId_vistaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textId_vistaActionPerformed

    private void textNomeVistaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textNomeVistaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textNomeVistaActionPerformed

    private void jTable3KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable3KeyReleased
        if(evt.getKeyCode() == KeyEvent.VK_UP|| evt.getKeyCode() == KeyEvent.VK_DOWN )
        {

            int i = jTable3.getSelectedRow();
            TableModel model= jTable3.getModel();
            textId_vista.setText(model.getValueAt(i,0).toString());
            textNomeVista.setText(model.getValueAt(i,1).toString());
            textDescrizioneVista.setText(model.getValueAt(i,2).toString());
            textCodiceSqlVista.setText(model.getValueAt(i,3).toString());
            jComboBoxDb2.setSelectedItem(model.getValueAt(i,4).toString());

        }

        // TODO add your handling code here:
    }//GEN-LAST:event_jTable3KeyReleased

    private void jTable3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable3MouseClicked
        int i = jTable3.getSelectedRow();
        TableModel model= jTable3.getModel();
        textId_vista.setText(model.getValueAt(i,0).toString());
        textNomeVista.setText(model.getValueAt(i,1).toString());
        textDescrizioneVista.setText(model.getValueAt(i,2).toString());
        textCodiceSqlVista.setText(model.getValueAt(i,3).toString());
        jComboBoxDb2.setSelectedItem(model.getValueAt(i,4).toString());////
    }//GEN-LAST:event_jTable3MouseClicked

    private void jTableUtenteKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTableUtenteKeyReleased

        if(evt.getKeyCode() == KeyEvent.VK_UP|| evt.getKeyCode() == KeyEvent.VK_DOWN )
        {

            int i = jTableUtente.getSelectedRow();
            TableModel model= jTableUtente.getModel();
            textUsername.setText(model.getValueAt(i,0).toString());
            textNome.setText(model.getValueAt(i,1).toString());
            textCognome.setText(model.getValueAt(i,2).toString());
            textEmail.setText(model.getValueAt(i,3).toString());
            textPasswordUtente.setText(model.getValueAt(i,4).toString());

        }

        // TODO add your handling code here:
    }//GEN-LAST:event_jTableUtenteKeyReleased

    private void jTableUtenteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableUtenteMouseClicked
        int i = jTableUtente.getSelectedRow();
        TableModel model= jTableUtente.getModel();
        textUsername.setText(model.getValueAt(i,0).toString());
        textNome.setText(model.getValueAt(i,1).toString());
        textCognome.setText(model.getValueAt(i,2).toString());
        textEmail.setText(model.getValueAt(i,3).toString());
        textPasswordUtente.setText(model.getValueAt(i,4).toString());

        // TODO add your handling code here:
    }//GEN-LAST:event_jTableUtenteMouseClicked

    private void valueUserKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_valueUserKeyReleased
        jTableUtente.setModel(new DefaultTableModel(null,new Object[] {"USERNAME","NOME","COGNOME","EMAIL","PASSWORD"}));

        try {
            String valueToSearch=  valueUser.getText().toString();
            System.out.println(valueToSearch);
            Search_User_in_JTable1(jTableUtente,valueToSearch);

            // TODO add your handling code here:
        } catch (SQLException ex) {
            Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_valueUserKeyReleased

    private void valueUserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_valueUserActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_valueUserActionPerformed

    private void ShowPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ShowPasswordActionPerformed
        if(ShowPassword.isSelected())
        textPasswordUtente.setEchoChar((char)0);
        else
        textPasswordUtente.setEchoChar('*');

        // TODO add your handling code here:
    }//GEN-LAST:event_ShowPasswordActionPerformed

    private void textEmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textEmailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textEmailActionPerformed

    private void textNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textNomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textNomeActionPerformed

    private void deleteUtenteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteUtenteActionPerformed
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            try ( // establish connection
                Connection con = getDefaultConnection();
                Statement statement = con.createStatement()) {
                statement.executeUpdate("DELETE FROM UTENTE WHERE username= '"+textUsername.getText()+"'");
                JOptionPane.showMessageDialog(null, "Eseguito correttamente.");
                DefaultTableModel model = (DefaultTableModel)jTableUtente.getModel();
                model.setRowCount(0);
                Show_User_In_JTable();
            }
            //Calling Referesh() method
        } catch (SQLException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        try {
            Scelta.nusr.setText(""+Integer.toString(CountFunction.countDb("UTENTE")));
        } catch (SQLException ex) {
            Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_deleteUtenteActionPerformed

    private void editUtenteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editUtenteActionPerformed
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            try ( // establish connection
                Connection con = getDefaultConnection();
                Statement statement = con.createStatement()) {
                statement.executeUpdate("UPDATE UTENTE SET nome='"+textNome.getText()+"', cognome='"+textCognome.getText()+"',email='"+textEmail.getText()+"',password='"+textPasswordUtente.getText()+"' WHERE username='"+textUsername.getText()+"'");

                JOptionPane.showMessageDialog(null, "Eseguito correttamente.");
                DefaultTableModel model = (DefaultTableModel)jTableUtente.getModel();
                model.setRowCount(0);
                Show_User_In_JTable();
            }
            //Calling Referesh() method
        } catch (SQLException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, e);
        }
        
        try {
            Scelta.nusr.setText(""+Integer.toString(CountFunction.countDb("UTENTE")));
        } catch (SQLException ex) {
            Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_editUtenteActionPerformed

    private void addUtenteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addUtenteActionPerformed

        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            try ( // establish connection
                Connection con = getDefaultConnection();
                Statement statement = con.createStatement()) {

                statement.executeUpdate("INSERT INTO UTENTE(username,nome,cognome,email,password) VALUES('" +textUsername.getText() + "','" +textNome.getText() + "','" +textCognome.getText() + "','" +textEmail.getText() + "','" +textPasswordUtente.getText()+"' )");
                JOptionPane.showMessageDialog(null, "Eseguito correttamente.");
                DefaultTableModel model = (DefaultTableModel)jTableUtente.getModel();
                model.setRowCount(0);
                Show_User_In_JTable();
            }
            //Calling Referesh() method
        } catch (SQLException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_addUtenteActionPerformed

    private void textCognomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textCognomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textCognomeActionPerformed

    private void textUsernameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textUsernameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textUsernameActionPerformed

    private void valueAssertionKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_valueAssertionKeyReleased
        jTable6.setModel(new DefaultTableModel(null,new Object[] {"ID","NOME","DESCRIZIONE","CODICE SQL","DATABASE"}));

        try {
            String valueToSearch=  valueAssertion.getText().toString();
            System.out.println(valueToSearch);
            Search_Assertion_in_JTable1( jTable6,valueToSearch);

            // TODO add your handling code here:
        } catch (SQLException ex) {
            Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_valueAssertionKeyReleased

    private void valueAssertionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_valueAssertionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_valueAssertionActionPerformed

    private void textIdAssertionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textIdAssertionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textIdAssertionActionPerformed

    private void addAssertionBottomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addAssertionBottomActionPerformed
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            try ( // establish connection
                Connection con = getDefaultConnection();
                Statement statement = con.createStatement()) {
                if(textIdAssertion.getText().length()==0 || textNomeAssertion.getText().length()==0)   
                    JOptionPane.showMessageDialog(null, "Campo obbligatorio assente.");
                else if(textIdAssertion.getText().length()>0 && textNomeAssertion.getText().length()>0)
                {

                //funzione split();
                    if(textDbAssertion.getSelectedItem().toString().equals("Seleziona"))
                       JOptionPane.showMessageDialog(null, "Seleziona Database."); 
                    else {
                        String str= (String) textDbAssertion.getSelectedItem();
                        String[] strSplit= str.split(":");
                        String p1= strSplit[0];

                        statement.executeUpdate("INSERT INTO ASSERZIONE(id_asserzione,nome,descrizione,codice_sql,id_db) VALUES(" +textIdAssertion.getText() + ",'" +textNomeAssertion.getText() + "','" +textDescrizioneAssertion.getText() + "','" +textCodiceSqlAssertion.getText() + "','"+p1+"')");
                        JOptionPane.showMessageDialog(null, "Eseguito correttamente.");
                        DefaultTableModel model = (DefaultTableModel)jTable6.getModel();
                        model.setRowCount(0);
                        Show_Assertion_In_JTable();
            }}}
            //Calling Referesh() method
        } catch (SQLException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        try {
            Scelta.nass.setText(""+Integer.toString(CountFunction.countDb("ASSERZIONE")));
        } catch (SQLException ex) {
            Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_addAssertionBottomActionPerformed

    private void deleteDbBottom5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteDbBottom5ActionPerformed

        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            try ( // establish connection
                Connection con = getDefaultConnection();
                Statement statement = con.createStatement()) {
                statement.executeUpdate("DELETE FROM ASSERZIONE WHERE id_asserzione= "+textIdAssertion.getText());
                JOptionPane.showMessageDialog(null, "Eseguito correttamente.");
                DefaultTableModel model = (DefaultTableModel)jTable6.getModel();
                model.setRowCount(0);
                Show_Assertion_In_JTable();
            }
            //Calling Referesh() method
        } catch (SQLException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        try {
            Scelta.nass.setText(""+Integer.toString(CountFunction.countDb("ASSERZIONE")));
        } catch (SQLException ex) {
            Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_deleteDbBottom5ActionPerformed

    private void editAssertionBottomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editAssertionBottomActionPerformed
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            try ( // establish connection
                Connection con = getDefaultConnection();
                Statement statement = con.createStatement()) {
                //funzione split();

                String str= (String) textDbAssertion.getSelectedItem();
                String[] strSplit= str.split(":");
                String p1= strSplit[0];

                statement.executeUpdate("UPDATE ASSERZIONE SET nome='"+textNomeAssertion.getText()+"', descrizione= '"+textDescrizioneAssertion.getText()+"',codice_sql='"+textCodiceSqlAssertion.getText()+"', id_db="+p1+"  WHERE id_asserzione='"+textIdAssertion.getText()+"'");

                JOptionPane.showMessageDialog(null, "Eseguito correttamente.");
                DefaultTableModel model = (DefaultTableModel)jTable6.getModel();
                model.setRowCount(0);
                Show_Assertion_In_JTable();
            }
            //Calling Referesh() method
        } catch (SQLException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_editAssertionBottomActionPerformed

    private void textNomeAssertionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textNomeAssertionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textNomeAssertionActionPerformed

    private void jTable6MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable6MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable6MouseEntered

    private void jTable6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable6MouseClicked
        // mostro la selezione in jtext;
        int i = jTable6.getSelectedRow();
        TableModel model= jTable6.getModel();
        textIdAssertion.setText(model.getValueAt(i,0).toString());
        textNomeAssertion.setText(model.getValueAt(i,1).toString());
        textDescrizioneAssertion.setText(model.getValueAt(i,2).toString());
        textCodiceSqlAssertion.setText(model.getValueAt(i,3).toString());
        textDbAssertion.setSelectedItem(model.getValueAt(i,4).toString());

        // TODO add your handling code here:
    }//GEN-LAST:event_jTable6MouseClicked

    private void valueTriggerKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_valueTriggerKeyReleased
        jTable5.setModel(new DefaultTableModel(null,new Object[] {"ID","NOME","DESCRIZIONE","CODICE SQL","TABELLA","VISTA"}));

        try {
            String valueToSearch=  valueTrigger.getText().toString();
            System.out.println(valueToSearch);
            Search_Trigger_in_JTable5( jTable5,valueToSearch);

            // TODO add your handling code here:
        } catch (SQLException ex) {
            Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_valueTriggerKeyReleased

    private void valueTriggerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_valueTriggerActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_valueTriggerActionPerformed

    private void jComboBoxTriggerVistaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxTriggerVistaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxTriggerVistaActionPerformed

    private void RadioVistaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RadioVistaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RadioVistaActionPerformed

    private void RadioVistaItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_RadioVistaItemStateChanged
        //se � selezionato Vista, allora ATTIVA combobox vista.

        if(RadioVista.isSelected()){

            jComboBoxTriggerVista.enable();
            jComboBoxTriggerTabella.disable();

        }

        // TODO add your handling code here:
    }//GEN-LAST:event_RadioVistaItemStateChanged

    private void RadioTabellaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RadioTabellaActionPerformed

        // TODO add your handling code here:
    }//GEN-LAST:event_RadioTabellaActionPerformed

    private void RadioTabellaItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_RadioTabellaItemStateChanged
        //se � selezionato Tabella, allora ATTIVA combobox tabella.
        if(RadioTabella.isSelected())
        {     jComboBoxTriggerTabella.enable();

            jComboBoxTriggerVista.disable();
        }
    }//GEN-LAST:event_RadioTabellaItemStateChanged

    private void textIdTriggerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textIdTriggerActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textIdTriggerActionPerformed

    private void deleteTriggerBottomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteTriggerBottomActionPerformed
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            try ( // establish connection
                Connection con = getDefaultConnection();
                Statement statement = con.createStatement()) {
                System.out.println(textIdTrigger.getText());
                statement.executeUpdate("DELETE FROM TRIGGERS WHERE id_trigger= "+textIdTrigger.getText());
                JOptionPane.showMessageDialog(null, "Eseguito correttamente.");
                DefaultTableModel model = (DefaultTableModel)jTable5.getModel();
                model.setRowCount(0);
                Show_Trigger_In_JTable();
            }
            //Calling Referesh() method
        } catch (SQLException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        try {
            Scelta.ntrg.setText(""+Integer.toString(CountFunction.countDb("TRIGGERS")));
        } catch (SQLException ex) {
            Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_deleteTriggerBottomActionPerformed

    private void editTriggerBottomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editTriggerBottomActionPerformed
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            try ( // establish connection
                Connection con = getDefaultConnection();
                Statement statement = con.createStatement()) {

                //funzione split();
                if(textIdTrigger.getText().length()==0||textNomeTrigger.getText().length()==0){
                 JOptionPane.showMessageDialog(null, "Campo obbligatorio non riempito.");   
                System.out.println("ENTRO");
                }
                else if (textIdTrigger.getText().length()>0&&textNomeTrigger.getText().length()>0)
                {    
                    
                if(!RadioTabella.isSelected() && !RadioVista.isSelected())
                JOptionPane.showMessageDialog(null, "SELEZIONARE TABELLA O VISTA.");

                if(RadioTabella.isSelected()&& !RadioVista.isSelected()){

                    //funzione split();

                    String str= (String) jComboBoxTriggerTabella.getSelectedItem();
                    String[] strSplit= str.split(":");
                    String p1= strSplit[0];

                    statement.executeUpdate("UPDATE TRIGGERS SET nome='"+textNomeTrigger.getText()+"',Descrizione='"+textDescrizioneTrigger.getText()+"', codice_sql='"+textCodiceSqlTrigger.getText()+"', id_tabella='"+p1+"',id_vista= NULL  WHERE id_trigger='"+textIdTrigger.getText()+"'");
                    JOptionPane.showMessageDialog(null, "Eseguito correttamente.");

                }

                if(RadioVista.isSelected()&& !RadioTabella.isSelected()){

                    //funzione split
                    String strin= (String) jComboBoxTriggerVista.getSelectedItem();
                    String[] strinSplit= strin.split(":");
                    String p= strinSplit[0];

                    statement.executeUpdate("UPDATE TRIGGERS SET nome='"+textNomeTrigger.getText()+"',Descrizione='"+textDescrizioneTrigger.getText()+"', codice_sql='"+textCodiceSqlTrigger.getText()+"',id_tabella= NULL, id_vista='"+p+"'  WHERE id_trigger='"+textIdTrigger.getText()+"'");
                    JOptionPane.showMessageDialog(null, "Eseguito correttamente.");
                }
                }
                DefaultTableModel model = (DefaultTableModel)jTable5.getModel();
                model.setRowCount(0);
                Show_Trigger_In_JTable();
            }
            //Calling Referesh() method
        } catch (SQLException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_editTriggerBottomActionPerformed

    private void addTriggerBottomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addTriggerBottomActionPerformed
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            try ( // establish connection
                Connection con = getDefaultConnection();
                Statement statement = con.createStatement()) {

                //funzione split();

               if(textIdTrigger.getText().length()==0||textNomeTrigger.getText().length()==0){
                 JOptionPane.showMessageDialog(null, "Campo obbligatorio non riempito.");   
                System.out.println("ENTRO");
                }
                else if (textIdTrigger.getText().length()>0&&textNomeTrigger.getText().length()>0)
                {    
                
                
                if(!RadioTabella.isSelected() && !RadioVista.isSelected())
                JOptionPane.showMessageDialog(null, "SELEZIONARE TABELLA O VISTA.");
                else {

                if(RadioTabella.isSelected()&& !RadioVista.isSelected()){
                    
                    if(jComboBoxTriggerTabella.getSelectedItem().toString().equals("Seleziona"))
                         JOptionPane.showMessageDialog(null, "Selezione Tabella assente.");
                    else if(!jComboBoxTriggerTabella.getSelectedItem().toString().equals("Seleziona"))
                    {
                    //funzione split();

                    String str= (String) jComboBoxTriggerTabella.getSelectedItem();
                    String[] strSplit= str.split(":");
                    String p1= strSplit[0];

                    statement.executeUpdate("INSERT INTO TRIGGERS (id_trigger,nome,descrizione, codice_sql,id_tabella,id_vista) VALUES(" +textIdTrigger.getText() + ",'" +textNomeTrigger.getText() + "','" +textDescrizioneTrigger.getText() + "','" +textCodiceSqlTrigger.getText() + "','"+p1+"',NULL)");
                    JOptionPane.showMessageDialog(null, "Eseguito correttamente.");
                    }
                }

                else     
                
                 if(jComboBoxTriggerVista.getSelectedItem().toString().equals("Seleziona"))
                         JOptionPane.showMessageDialog(null, "Selezione Vista assente.");
                    else if(!jComboBoxTriggerVista.getSelectedItem().toString().equals("Seleziona"))
                    {
                         if(RadioVista.isSelected()&& !RadioTabella.isSelected()){

                    //funzione split
                        String strin= (String) jComboBoxTriggerVista.getSelectedItem();
                        String[] strinSplit= strin.split(":");
                        String p= strinSplit[0];

                        statement.executeUpdate("INSERT INTO TRIGGERS (id_trigger,nome,descrizione, codice_sql,id_tabella,id_vista) VALUES(" +textIdTrigger.getText() + ",'" +textNomeTrigger.getText() + "','" +textDescrizioneTrigger.getText() + "','" +textCodiceSqlTrigger.getText() + "',NULL,'"+p+"')");
                        JOptionPane.showMessageDialog(null, "Eseguito correttamente.");
                }}
                }}
                DefaultTableModel model = (DefaultTableModel)jTable5.getModel();
                model.setRowCount(0);
                Show_Trigger_In_JTable();
            }
            
            //Calling Referesh() method
        } catch (SQLException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        try {
            Scelta.ntrg.setText(""+Integer.toString(CountFunction.countDb("TRIGGERS")));
        } catch (SQLException ex) {
            Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_addTriggerBottomActionPerformed

    private void jComboBoxTriggerTabellaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxTriggerTabellaActionPerformed

    }//GEN-LAST:event_jComboBoxTriggerTabellaActionPerformed

    private void textNomeTriggerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textNomeTriggerActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textNomeTriggerActionPerformed

    private void jTable5KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable5KeyReleased
        if(evt.getKeyCode() == KeyEvent.VK_UP|| evt.getKeyCode() == KeyEvent.VK_DOWN )
        {

            int i = jTable5.getSelectedRow();
            TableModel model= jTable5.getModel();
            textIdTrigger.setText(model.getValueAt(i,0).toString());
            textNomeTrigger.setText(model.getValueAt(i,1).toString());
            textDescrizioneTrigger.setText(model.getValueAt(i,2).toString());
            textCodiceSqlTrigger.setText(model.getValueAt(i,3).toString());

        }

        // TODO add your handling code here:
    }//GEN-LAST:event_jTable5KeyReleased

    private void jTable5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable5MouseClicked

        // mostro la selezione in jtext;
        int i = jTable5.getSelectedRow();
        TableModel model= jTable5.getModel();
        textIdTrigger.setText(model.getValueAt(i,0).toString());
        textNomeTrigger.setText(model.getValueAt(i,1).toString());
        textDescrizioneTrigger.setText(model.getValueAt(i,2).toString());
        textCodiceSqlTrigger.setText(model.getValueAt(i,3).toString());

        if(RadioTabella.isSelected())
        jComboBoxTriggerTabella.setSelectedItem(model.getValueAt(i,4).toString());
        else
        if(RadioVista.isSelected())
        jComboBoxTriggerVista.setSelectedItem(model.getValueAt(i,4).toString());

        // TODO add your handling code here:
    }//GEN-LAST:event_jTable5MouseClicked

    private void valueTabellaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_valueTabellaKeyReleased
        jTable2.setModel(new DefaultTableModel(null,new Object[] {"ID TABELLA","NOME","DATABASE"}));

        try {
            String valueToSearch=  valueTabella.getText().toString();
            System.out.println(valueToSearch);
            Search_Table_in_JTable1( jTable2,valueToSearch);

            // TODO add your handling code here:
        } catch (SQLException ex) {
            Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_valueTabellaKeyReleased

    private void valueTabellaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_valueTabellaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_valueTabellaActionPerformed

    private void textIdTabellaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textIdTabellaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textIdTabellaActionPerformed

    private void addtableBottomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addtableBottomActionPerformed

        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            try ( // establish connection
                Connection con = getDefaultConnection();
                Statement statement = con.createStatement()) {

                //funzione split();

                String str= (String) jComboBox_db.getSelectedItem();
                String[] strSplit= str.split(":");
                String p1= strSplit[0];

                if(jComboBox_db.getSelectedItem().equals("Seleziona"))
                JOptionPane.showMessageDialog(null, "Seleziona il database.");
                else{

                    statement.executeUpdate( "INSERT INTO TABELLA ( id_tabella, nome, id_db) VALUES(" +textIdTabella.getText() + ",'" +textNomeTabella.getText() + "', '"+ p1 + "')");
                    JOptionPane.showMessageDialog(null, "Eseguito correttamente.");
                    DefaultTableModel model = (DefaultTableModel)jTable2.getModel();
                    model.setRowCount(0);
                    Show_Table_In_JTable();
                }
            }
            //Calling Referesh() method
        } catch (SQLException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        try {
            Scelta.ntb.setText(""+Integer.toString(CountFunction.countDb("TABELLA")));
        } catch (SQLException ex) {
            Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_addtableBottomActionPerformed

    private void editDbBottom4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editDbBottom4ActionPerformed
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            try ( // establish connection
                Connection con = getDefaultConnection();
                Statement statement = con.createStatement()) {

                //FUNZIONE SPLIT
                String str= (String) jComboBox_db.getSelectedItem();
                String[] strSplit= str.split(":");
                String p1= strSplit[0];

                if(jComboBox_db.getSelectedItem().equals("Seleziona"))
                JOptionPane.showMessageDialog(null, "Seleziona il database.");
                else {
                    statement.executeUpdate("UPDATE TABELLA SET nome='"+textNomeTabella.getText()+"',id_db='"+p1+"' WHERE id_tabella="+textIdTabella.getText()+"");
                    JOptionPane.showMessageDialog(null, "Eseguito correttamente.");
                    DefaultTableModel model = (DefaultTableModel)jTable2.getModel();
                    model.setRowCount(0);
                    Show_Table_In_JTable();
                }  }
                //Calling Referesh() method
            } catch (SQLException | ClassNotFoundException e) {
                JOptionPane.showMessageDialog(null, e);
            }

            // TODO add your handling code here:
    }//GEN-LAST:event_editDbBottom4ActionPerformed

    private void deleteTbBottomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteTbBottomActionPerformed
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            try ( // establish connection
                Connection con = getDefaultConnection();
                Statement statement = con.createStatement()) {
                statement.executeUpdate("DELETE FROM TABELLA WHERE id_tabella= "+textIdTabella.getText());
                JOptionPane.showMessageDialog(null, "Eseguito correttamente.");
                DefaultTableModel model = (DefaultTableModel)jTable2.getModel();
                model.setRowCount(0);
                Show_Table_In_JTable();
            }
            //Calling Referesh() method
        } catch (SQLException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        try {
            Scelta.ntb.setText(""+Integer.toString(CountFunction.countDb("TABELLA")));
        } catch (SQLException ex) {
            Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_deleteTbBottomActionPerformed

    private void jComboBox_dbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox_dbActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox_dbActionPerformed

    private void textNomeTabellaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textNomeTabellaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textNomeTabellaActionPerformed

    private void jTable2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable2KeyReleased

        if(evt.getKeyCode() == KeyEvent.VK_UP|| evt.getKeyCode() == KeyEvent.VK_DOWN )
        {

            int i = jTable2.getSelectedRow();
            TableModel model= jTable2.getModel();
            textIdTabella.setText(model.getValueAt(i,0).toString());
            textNomeTabella.setText(model.getValueAt(i,1).toString());
            jComboBox_db.setSelectedIndex(0);

        }

        // TODO add your handling code here:
    }//GEN-LAST:event_jTable2KeyReleased

    private void jTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseClicked
        // mostro la selezione in jtext;
        int i = jTable2.getSelectedRow();
        TableModel model= jTable2.getModel();
        textIdTabella.setText(model.getValueAt(i,0).toString());
        textNomeTabella.setText(model.getValueAt(i,1).toString());
        jComboBox_db.setSelectedItem(model.getValueAt(i,2).toString());////
    }//GEN-LAST:event_jTable2MouseClicked

    private void valueDbKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_valueDbKeyTyped

    }//GEN-LAST:event_valueDbKeyTyped

    private void valueDbKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_valueDbKeyReleased
     JTable1.setModel(new DefaultTableModel(null,new Object[] {"ID","NOME"})) ;       

        try {
            String valueToSearch=  valueDb.getText().toString();
            System.out.println(valueToSearch);
            Search_Db_in_JTable1( JTable1,valueToSearch);

            // TODO add your handling code here:
        } catch (SQLException ex) {
            Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_valueDbKeyReleased

    private void valueDbKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_valueDbKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_valueDbKeyPressed

    private void valueDbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_valueDbActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_valueDbActionPerformed

    private void JTable1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JTable1KeyReleased
        if(evt.getKeyCode() == KeyEvent.VK_UP|| evt.getKeyCode() == KeyEvent.VK_DOWN )
        {

            int i = JTable1.getSelectedRow();
            TableModel model= JTable1.getModel();
            textIdDb.setText(model.getValueAt(i,0).toString());
            textNomeDb.setText(model.getValueAt(i,1).toString());

        }

        // TODO add your handling code here:
    }//GEN-LAST:event_JTable1KeyReleased

    private void JTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JTable1MouseClicked
        // mostro la selezione in jtext;
        int i = JTable1.getSelectedRow();
        TableModel model= JTable1.getModel();
        textIdDb.setText(model.getValueAt(i,0).toString());
        textNomeDb.setText(model.getValueAt(i,1).toString());
    }//GEN-LAST:event_JTable1MouseClicked

    private void deleteDbBottomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteDbBottomActionPerformed

         try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            try ( // establish connection
                Connection con = getDefaultConnection();
                Statement statement = con.createStatement()) {
                
                statement.executeUpdate("DELETE FROM Database WHERE id_db = "+textIdDb.getText()+"");
                JOptionPane.showMessageDialog(null, "Eseguito correttamente.");
                DefaultTableModel model = (DefaultTableModel)JTable1.getModel();
                model.setRowCount(0);
                Show_Db_In_JTable();
            }
            //Calling Referesh() method
        } catch (SQLException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        try {
            Scelta.ndb.setText(""+Integer.toString(CountFunction.countDb("DATABASE")));
        } catch (SQLException ex) {
            Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_deleteDbBottomActionPerformed

    private void addDbBottomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addDbBottomActionPerformed

         try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            try ( // establish connection
                Connection con = getDefaultConnection();
                Statement statement = con.createStatement()) {
                
                statement.executeUpdate("INSERT INTO database(id_db,nome) VALUES( "+textIdDb.getText() +" ,'" +textNomeDb.getText() + "')");
                JOptionPane.showMessageDialog(null, "Eseguito correttamente.");
                DefaultTableModel model = (DefaultTableModel)JTable1.getModel();
                model.setRowCount(0);
                Show_Db_In_JTable();
            }
            //Calling Referesh() method
        } catch (SQLException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        try {
            Scelta.ndb.setText(""+Integer.toString(CountFunction.countDb("DATABASE")));
        } catch (SQLException ex) {
            Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_addDbBottomActionPerformed

    private void editDbBottomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editDbBottomActionPerformed

      try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            try ( // establish connection
                Connection con = getDefaultConnection();
                Statement statement = con.createStatement()) {
                statement.executeUpdate("UPDATE DATABASE SET Nome='"+textNomeDb.getText()+"' WHERE id_db='"+textIdDb.getText()+"'");

                JOptionPane.showMessageDialog(null, "Eseguito correttamente.");
                DefaultTableModel model = (DefaultTableModel)JTable1.getModel();
                model.setRowCount(0);
                Show_Db_In_JTable();
            }
            //Calling Referesh() method
        } catch (SQLException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, e);
        }


        // TODO add your handling code here:
    }//GEN-LAST:event_editDbBottomActionPerformed

    private void textNomeDbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textNomeDbActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textNomeDbActionPerformed

    private void textIdDbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textIdDbActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textIdDbActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
       switch(jComboBox1.getSelectedItem().toString())  {
           
           case "Databases":        
                    jTable1.setModel(JTable1.getModel());
                    break;
                   
           case "Tabelle":        
                    jTable1.setModel(jTable2.getModel());
                    break;
           
           case "Attributi":        
                    jTable1.setModel(jTable10.getModel());
                    break;        
                    
           case "Viste":        
                    jTable1.setModel(jTable3.getModel());
                    break;
            
           case "Domini":        
                    jTable1.setModel(jTable11.getModel());
                    break;
           
           case "Triggers":        
                    jTable1.setModel(jTable5.getModel());
                    break; 
                    
           case "Asserzioni":        
                    jTable1.setModel(jTable6.getModel());
                    break;
                
           case "Procedure":        
                    jTable1.setModel(jTable7.getModel());
                    break;
                    
           case "Sequenze":        
                    jTable1.setModel(jTableSequenza.getModel());
                    break;
                    
           case "Utenti":        
                    jTable1.setModel(jTableUtente.getModel());
                    break;
                    
           case "Primary Keys":        
           { try {
               jTable1.setModel(new DefaultTableModel(null,new Object[] {"ID","NOME","DEFAULT","TABELLA","DOMINIO","PK","NOME PK","POSIZIONE PK"}));
               Search_Pk_in_JTableSearch(jTable1,"*");
               
               break;
           } catch (SQLException ex) {
               Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
           }
}
              
            case "Foreign Keys":        
                    jTable1.setModel(tabellaFk.getModel());
                    break;
                    
            case "Checks":        
                    jTable1.setModel(jTableCheck.getModel());
                    break;        
                  
              
       }   
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
    jTabbedPane2.setSelectedIndex(14) ;        
        
        try {
             comboUsernamePermessi.removeAllItems();
             Show_Users_In_JComboPermessi();
             comboDbPermessi.removeAllItems();
             Show_Db_In_JComboPermessi();
         } catch (SQLException ex) {
             Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
         }
    }//GEN-LAST:event_jButton7ActionPerformed

    private void addSequenza1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addSequenza1ActionPerformed
       try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            try ( // establish connection
                Connection con = getDefaultConnection();
                Statement statement = con.createStatement()) {

               

                if(comboUsernamePermessi.getSelectedItem().toString().equals("Seleziona")||comboPermesso.getSelectedItem().toString().equals("Seleziona")||comboDbPermessi.getSelectedItem().toString().equals("Seleziona"))
                  JOptionPane.showMessageDialog(null, "Campo obbligatorio assente.");    
                else if(!comboUsernamePermessi.getSelectedItem().toString().equals("Seleziona")&&!comboPermesso.getSelectedItem().toString().equals("Seleziona")&&!comboDbPermessi.getSelectedItem().toString().equals("Seleziona"))
                {
                    
                     //funzione split();

                String str1= (String)comboDbPermessi.getSelectedItem();
                String[] strSplit= str1.split(":");
                String p1= strSplit[0];
                statement.executeUpdate("INSERT INTO ACCESSO(username,id_db,accesso) VALUES('"+comboUsernamePermessi.getSelectedItem().toString()+"'," +p1+ ",'"+comboPermesso.getSelectedItem().toString()+ "')");
                JOptionPane.showMessageDialog(null, "Eseguito correttamente.");

                DefaultTableModel model = (DefaultTableModel)jTable4.getModel();
                model.setRowCount(0);
                Show_Access_In_JTable();
            }}
            //Calling Referesh() method
        } catch (SQLException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, e);
        } 
    }//GEN-LAST:event_addSequenza1ActionPerformed

    private void editPermessiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editPermessiActionPerformed
       try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            try ( // establish connection
                Connection con = getDefaultConnection();
                Statement statement = con.createStatement()) {

                

                if(comboUsernamePermessi.getSelectedItem().toString().equals("Seleziona")||comboPermesso.getSelectedItem().toString().equals("Seleziona")||comboDbPermessi.getSelectedItem().toString().equals("Seleziona"))
                  JOptionPane.showMessageDialog(null, "Campo obbligatorio assente.");    
                else if(!comboUsernamePermessi.getSelectedItem().toString().equals("Seleziona")&&!comboPermesso.getSelectedItem().toString().equals("Seleziona")&&!comboDbPermessi.getSelectedItem().toString().equals("Seleziona"))
                {
                    //FUNZIONE SPLIT
                    String str= (String) comboDbPermessi.getSelectedItem();
                    String[] strSplit= str.split(":");
                    String p1= strSplit[0];
                    statement.executeUpdate("UPDATE ACCESSO SET id_db="+p1+", accesso= '"+comboPermesso.getSelectedItem().toString()+"'  WHERE username='"+comboUsernamePermessi.getSelectedItem().toString()+"'");
                    JOptionPane.showMessageDialog(null, "Eseguito correttamente.");
                    DefaultTableModel model = (DefaultTableModel)jTable4.getModel();
                    model.setRowCount(0);
                    Show_Access_In_JTable();
                }  }
                //Calling Referesh() method
            } catch (SQLException | ClassNotFoundException e) {
                JOptionPane.showMessageDialog(null, e);
            }
    }//GEN-LAST:event_editPermessiActionPerformed

    private void deletePermessiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletePermessiActionPerformed
      
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            try ( // establish connection
                Connection con = getDefaultConnection();
                Statement statement = con.createStatement()) {
                statement.executeUpdate("DELETE FROM ACCESSO WHERE username= '"+comboUsernamePermessi.getSelectedItem().toString()+"'");
                JOptionPane.showMessageDialog(null, "Eseguito correttamente.");
                DefaultTableModel model = (DefaultTableModel)jTable4.getModel();
                model.setRowCount(0);
               Show_Access_In_JTable();
            }
            //Calling Referesh() method
        } catch (SQLException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        
    }//GEN-LAST:event_deletePermessiActionPerformed

    private void jTable4KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable4KeyReleased
      if(evt.getKeyCode() == KeyEvent.VK_UP|| evt.getKeyCode() == KeyEvent.VK_DOWN )
        {

            int i = jTable4.getSelectedRow();
            TableModel model= jTable4.getModel();
           comboUsernamePermessi.setSelectedItem(model.getValueAt(i,0).toString());
           comboPermesso.setSelectedItem(model.getValueAt(i,1).toString());
           

        }
    }//GEN-LAST:event_jTable4KeyReleased

    private void jTable4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable4MouseClicked
        int i = jTable4.getSelectedRow();
            TableModel model= jTable4.getModel();
           comboUsernamePermessi.setSelectedItem(model.getValueAt(i,0).toString());
           comboPermesso.setSelectedItem(model.getValueAt(i,1).toString());
           
    }//GEN-LAST:event_jTable4MouseClicked

    private void jTableCheckKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTableCheckKeyReleased
       if(evt.getKeyCode() == KeyEvent.VK_UP|| evt.getKeyCode() == KeyEvent.VK_DOWN )
        {

            int i = jTableCheck.getSelectedRow();
            TableModel model= jTableCheck.getModel();
            nomeCheck.setText(model.getValueAt(i,0).toString());
            descrizioneCheck.setText(model.getValueAt(i,1).toString());
            attributoCheck.setSelectedItem(model.getValueAt(i,2).toString());
            codiceSqlCheck.setText(model.getValueAt(i,3).toString());
        }
    }//GEN-LAST:event_jTableCheckKeyReleased

    private void jTableCheckMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableCheckMouseClicked
     int i = jTableCheck.getSelectedRow();
            TableModel model= jTableCheck.getModel();
            nomeCheck.setText(model.getValueAt(i,0).toString());
            descrizioneCheck.setText(model.getValueAt(i,1).toString());
            attributoCheck.setSelectedItem(model.getValueAt(i,2).toString());
            codiceSqlCheck.setText(model.getValueAt(i,3).toString());
    }//GEN-LAST:event_jTableCheckMouseClicked

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        jTabbedPane2.setSelectedIndex(11) ;
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
         jTabbedPane2.setSelectedIndex(12) ;
    }//GEN-LAST:event_jButton8ActionPerformed

    private void valueCheckKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_valueCheckKeyReleased
         jTableCheck.setModel(new DefaultTableModel(null,new Object[] {"NOME","DESCRIZIONE","ATTRIBUTO","CODICE SQL"}));

        try {
            String valueToSearch=  valueCheck.getText().toString();
            System.out.println(valueToSearch);
            RicercaCheck(jTableCheck,valueToSearch);

            // TODO add your handling code here:
        } catch (SQLException ex) {
            Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_valueCheckKeyReleased

    private void valueCheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_valueCheckActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_valueCheckActionPerformed

    private void valueFkKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_valueFkKeyReleased
        tabellaFk.setModel(new DefaultTableModel(null,new Object[] {"NOME","TABELLA","ATTRIBUTO","RTABELLA","RATTRIBUTO","POSIZIONE"}));

        try {
            String valueToSearch=  valueFk.getText().toString();
            System.out.println(valueToSearch);
           Search_FK_in_JTableFk(  tabellaFk,valueToSearch);

           
        } catch (SQLException ex) {
            Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_valueFkKeyReleased

    private void valueFkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_valueFkActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_valueFkActionPerformed

    private void jTableSequenzaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTableSequenzaKeyReleased
        if(evt.getKeyCode() == KeyEvent.VK_UP|| evt.getKeyCode() == KeyEvent.VK_DOWN )
        {

            int i = jTableSequenza.getSelectedRow();
            TableModel model= jTableSequenza.getModel();
            nomeSequenza.setText(model.getValueAt(i,0).toString());
            iniziadaSequenza.setText(model.getValueAt(i,1).toString());
            incrementadiSequenza.setText(model.getValueAt(i,2).toString());
            valoreminSequenza.setText(model.getValueAt(i,3).toString());
            valoremaxSequenza.setText(model.getValueAt(i,4).toString());
            attributoSequenza.setSelectedItem("Seleziona");

        }

    }//GEN-LAST:event_jTableSequenzaKeyReleased

    private void jTableSequenzaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableSequenzaMouseClicked
       int i = jTableSequenza.getSelectedRow();
            TableModel model= jTableSequenza.getModel();
            nomeSequenza.setText(model.getValueAt(i,0).toString());
            iniziadaSequenza.setText(model.getValueAt(i,1).toString());
            incrementadiSequenza.setText(model.getValueAt(i,2).toString());
            valoreminSequenza.setText(model.getValueAt(i,3).toString());
            valoremaxSequenza.setText(model.getValueAt(i,4).toString());
            attributoSequenza.setSelectedItem("Seleziona");
    }//GEN-LAST:event_jTableSequenzaMouseClicked

    private void jTable6KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable6KeyReleased
          if(evt.getKeyCode() == KeyEvent.VK_UP|| evt.getKeyCode() == KeyEvent.VK_DOWN )
        {

            int i = jTable6.getSelectedRow();
        TableModel model= jTable6.getModel();
        textIdAssertion.setText(model.getValueAt(i,0).toString());
        textNomeAssertion.setText(model.getValueAt(i,1).toString());
        textDescrizioneAssertion.setText(model.getValueAt(i,2).toString());
        textCodiceSqlAssertion.setText(model.getValueAt(i,3).toString());
        textDbAssertion.setSelectedItem(model.getValueAt(i,4).toString());
        }
    }//GEN-LAST:event_jTable6KeyReleased

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        jTabbedPane2.setSelectedIndex(13) ; 
    }//GEN-LAST:event_jButton10ActionPerformed
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Scelta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Scelta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Scelta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Scelta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                
                
             
                
                try {
                    new Scelta().setVisible(true);
                    
                } catch (SQLException ex) {
                    Logger.getLogger(Scelta.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BottomAttributo;
    private javax.swing.JButton BottomDatabase;
    private javax.swing.JButton BottomFunzione2;
    private javax.swing.JButton BottomProcedura2;
    private javax.swing.JButton BottomSequenza;
    private javax.swing.JButton BottomTabella;
    private javax.swing.JButton BottomTrigger2;
    private javax.swing.JButton BottomUtente;
    private javax.swing.JButton BottomVista;
    public static javax.swing.JTable JTable1;
    private javax.swing.JLabel NomeUtente;
    private javax.swing.JLabel Permesso;
    private javax.swing.ButtonGroup RadioFormato;
    private javax.swing.JRadioButton RadioTabella;
    private javax.swing.JRadioButton RadioVista;
    private javax.swing.JLabel RicercaAssertion;
    private javax.swing.JLabel RicercaProcedure;
    private javax.swing.JCheckBox ShowPassword;
    private javax.swing.JButton addAssertionBottom;
    private javax.swing.JButton addAttributo;
    private javax.swing.JButton addDbBottom;
    private javax.swing.JButton addDominio;
    private javax.swing.JButton addFk;
    private javax.swing.JButton addProcedureBottom;
    private javax.swing.JButton addProcedureBottom1;
    private javax.swing.JButton addSequenza;
    private javax.swing.JButton addSequenza1;
    private javax.swing.JButton addTriggerBottom;
    private javax.swing.JButton addUtente;
    private javax.swing.JButton addVistaBottom;
    private javax.swing.JButton addtableBottom;
    private javax.swing.JComboBox<String> attributoCheck;
    private javax.swing.JComboBox<String> attributoSequenza;
    private javax.swing.JRadioButton boxCheck;
    private javax.swing.JRadioButton boxFk;
    private javax.swing.JRadioButton boxPk;
    private javax.swing.ButtonGroup buttonGroupVincoli;
    private javax.swing.JTextArea codiceSqlCheck;
    private javax.swing.JComboBox<String> comboDbPermessi;
    private javax.swing.JComboBox<String> comboPermesso;
    private javax.swing.JComboBox<String> comboPosAttributo;
    private javax.swing.JComboBox<String> comboPosizioneFk;
    private javax.swing.JComboBox<String> comboPosizionePk;
    private javax.swing.JComboBox<String> comboRAttributo;
    private javax.swing.JComboBox<String> comboRTabella;
    private javax.swing.JComboBox<String> comboUsernamePermessi;
    private javax.swing.JLabel database;
    private javax.swing.JButton deleteAttributo;
    private javax.swing.JButton deleteCheck;
    private javax.swing.JButton deleteDbBottom;
    private javax.swing.JButton deleteDbBottom5;
    private javax.swing.JButton deleteDominio;
    private javax.swing.JButton deletePermessi;
    private javax.swing.JButton deleteProcedureBottom;
    private javax.swing.JButton deleteSequenza;
    private javax.swing.JButton deleteTbBottom;
    private javax.swing.JButton deleteTriggerBottom;
    private javax.swing.JButton deleteUtente;
    private javax.swing.JButton deleteVistaBottom;
    private javax.swing.JTextField descrizioneCheck;
    private javax.swing.JButton editAssertionBottom;
    private javax.swing.JButton editAttributo;
    private javax.swing.JButton editDbBottom;
    private javax.swing.JButton editDbBottom4;
    private javax.swing.JButton editDominio;
    private javax.swing.JButton editPermessi;
    private javax.swing.JButton editProcedureBottom;
    private javax.swing.JButton editSequenza;
    private javax.swing.JButton editTriggerBottom;
    private javax.swing.JButton editUtente;
    private javax.swing.JButton editVistaBottom;
    private javax.swing.JTextField incrementadiSequenza;
    private javax.swing.JTextField iniziadaSequenza;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBoxAttributoDominio;
    private javax.swing.JComboBox<String> jComboBoxAttributoTabella;
    private javax.swing.JComboBox<String> jComboBoxDb2;
    private javax.swing.JComboBox<String> jComboBoxDbProcedura;
    private javax.swing.JComboBox<String> jComboBoxDefaultAttributo;
    private javax.swing.JComboBox<String> jComboBoxTriggerTabella;
    private javax.swing.JComboBox<String> jComboBoxTriggerVista;
    private javax.swing.JComboBox<String> jComboBox_db;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel73;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JLabel jLabel77;
    private javax.swing.JLabel jLabel78;
    private javax.swing.JLabel jLabel79;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel80;
    private javax.swing.JLabel jLabel81;
    private javax.swing.JLabel jLabel82;
    private javax.swing.JLabel jLabel83;
    private javax.swing.JLabel jLabel84;
    private javax.swing.JLabel jLabel85;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel34;
    private javax.swing.JPanel jPanel35;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane12;
    private javax.swing.JScrollPane jScrollPane13;
    private javax.swing.JScrollPane jScrollPane14;
    private javax.swing.JScrollPane jScrollPane15;
    private javax.swing.JScrollPane jScrollPane16;
    private javax.swing.JScrollPane jScrollPane17;
    private javax.swing.JScrollPane jScrollPane18;
    private javax.swing.JScrollPane jScrollPane19;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane20;
    private javax.swing.JScrollPane jScrollPane21;
    private javax.swing.JScrollPane jScrollPane22;
    private javax.swing.JScrollPane jScrollPane23;
    private javax.swing.JScrollPane jScrollPane24;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable10;
    private javax.swing.JTable jTable11;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JTable jTable4;
    private javax.swing.JTable jTable5;
    private javax.swing.JTable jTable6;
    private javax.swing.JTable jTable7;
    private javax.swing.JTable jTableCheck;
    private javax.swing.JTable jTableSequenza;
    private javax.swing.JTable jTableUtente;
    private java.awt.Label label2;
    private java.awt.Label label3;
    private javax.swing.JLabel logo;
    public static javax.swing.JLabel nass;
    public static javax.swing.JLabel natt;
    public static javax.swing.JLabel ndb;
    public static javax.swing.JLabel ndmn;
    private javax.swing.JTextField nomeCheck;
    private javax.swing.JTextField nomeFk;
    private javax.swing.JTextField nomeFkAttributo;
    private javax.swing.JTextField nomeSequenza;
    public static javax.swing.JLabel nprd;
    public static javax.swing.JLabel nsqz;
    public static javax.swing.JLabel ntb;
    public static javax.swing.JLabel ntrg;
    public static javax.swing.JLabel nusr;
    public static javax.swing.JLabel nvst;
    private javax.swing.JPanel panelCheck;
    private javax.swing.JPanel panelFk;
    private javax.swing.JPanel panelPk;
    private javax.swing.JRadioButton personalizzato;
    private javax.swing.JRadioButton pushKey;
    private javax.swing.JRadioButton standard;
    private javax.swing.JComboBox<String> tabellaCheck;
    private javax.swing.JTable tabellaFk;
    private javax.swing.JComboBox<String> tabellaSequenza;
    private javax.swing.JComboBox<String> textAttributoFk;
    private javax.swing.JTextArea textCodiceSqlAssertion;
    private javax.swing.JTextArea textCodiceSqlProcedura;
    private javax.swing.JTextArea textCodiceSqlTrigger;
    private javax.swing.JTextArea textCodiceSqlVista;
    private javax.swing.JTextField textCognome;
    private javax.swing.JComboBox<String> textDbAssertion;
    private javax.swing.JTextArea textDescrizioneAssertion;
    private javax.swing.JTextField textDescrizioneCheck;
    private javax.swing.JTextField textDescrizioneDominio;
    private javax.swing.JTextArea textDescrizioneProcedura;
    private javax.swing.JTextArea textDescrizioneTrigger;
    private javax.swing.JTextArea textDescrizioneVista;
    private javax.swing.JTextField textEmail;
    private javax.swing.JTextField textIdAssertion;
    private javax.swing.JTextField textIdAttributo;
    private javax.swing.JTextField textIdDb;
    private javax.swing.JTextField textIdDominio;
    private javax.swing.JTextField textIdProcedura;
    private javax.swing.JTextField textIdTabella;
    private javax.swing.JLabel textIdTb;
    private javax.swing.JTextField textIdTrigger;
    private javax.swing.JTextField textId_vista;
    private javax.swing.JTextField textNome;
    private javax.swing.JTextField textNomeAssertion;
    private javax.swing.JTextField textNomeAttributo;
    private javax.swing.JTextField textNomeCheck;
    private javax.swing.JTextField textNomeDb;
    private javax.swing.JTextField textNomeDominio;
    private javax.swing.JTextField textNomePk;
    private javax.swing.JTextField textNomeProcedura;
    private javax.swing.JTextField textNomeTabella;
    private javax.swing.JTextField textNomeTrigger;
    private javax.swing.JTextField textNomeVista;
    private javax.swing.JPasswordField textPasswordUtente;
    private javax.swing.JTextArea textPersonalizzato;
    private javax.swing.JComboBox<String> textStandard;
    private javax.swing.JComboBox<String> textTabellaFk;
    private javax.swing.JTextField textUsername;
    private javax.swing.JTextField valoremaxSequenza;
    private javax.swing.JTextField valoreminSequenza;
    private javax.swing.JLabel value;
    private javax.swing.JLabel value1;
    private javax.swing.JLabel value2;
    private javax.swing.JTextField valueAssertion;
    private javax.swing.JTextField valueAttributo;
    private javax.swing.JTextField valueCheck;
    private javax.swing.JTextField valueDb;
    private javax.swing.JTextField valueDominio;
    private javax.swing.JTextField valueFk;
    private javax.swing.JTextField valueProcedura;
    private javax.swing.JTextField valueSequenza;
    private javax.swing.JTextField valueTabella;
    private javax.swing.JTextField valueTrigger;
    private javax.swing.JTextField valueUser;
    private javax.swing.JTextField valueVista;
    // End of variables declaration//GEN-END:variables

}

CREATE TABLE Database 
( id_db INTEGER   PRIMARY KEY ,
  nome VARCHAR(32) UNIQUE NOT NULL
);
/
CREATE TABLE Tabella 
(
	id_tabella 	INTEGER  	 PRIMARY KEY,
	nome 		VARCHAR(32) 	 NOT NULL,
	id_db INTEGER NOT NULL, 
    FOREIGN KEY (id_db) REFERENCES Database(id_db) ON DELETE CASCADE,
    UNIQUE (nome,id_db)
);
/
CREATE TABLE Dominio
(	id_dominio	INTEGER    PRIMARY KEY,
	nome 		VARCHAR(32) UNIQUE NOT NULL,
	descrizione	VARCHAR(32) NOT NULL,
	formato		VARCHAR(32) NOT NULL
);
/
CREATE TABLE Attributo
(	id_attributo	INTEGER    PRIMARY KEY,
	Nome 	 	VARCHAR(32) NOT NULL,
	Defoult	        VARCHAR(10) NOT NULL CHECK (Defoult IN ('NULL', 'NOT NULL')) ,
	id_tabella      INTEGER NOT NULL,
	id_dominio	INTEGER NOT NULL,
	PK              VARCHAR2(4) CHECK (PK IN('*','NULL')),
        nome_pk         VARCHAR2(32),
	posizione_pk 	INTEGER,
       FOREIGN KEY (id_tabella) REFERENCES Tabella(id_tabella) ON DELETE CASCADE ,
     FOREIGN KEY (id_dominio) REFERENCES Dominio(id_dominio) ON DELETE CASCADE,
	CONSTRAINT v1 CHECK ((PK='*' AND nome_pk IS NOT NULL AND posizione_pk IS NOT NULL) OR (PK IS NULL AND nome_pk IS NULL AND posizione_pk IS NULL)),
        CONSTRAINT v2 UNIQUE (nome_pk,posizione_pk),
        CONSTRAINT v3 UNIQUE (nome,id_tabella)
);
/
CREATE TABLE FOREIGNKEY
(
	Nome_fk          VARCHAR(32) NOT NULL,
	id_tabella	 INTEGER NOT NULL,
     id_attributo	 INTEGER NOT NULL ,
	RTabella 	 INTEGER NOT NULL ,
	RAttributo       INTEGER NOT NULL ,
	posizione        INTEGER NOT NULL,
    FOREIGN KEY(id_tabella) REFERENCES Tabella(id_tabella) ON DELETE CASCADE,
    FOREIGN KEY (id_attributo) REFERENCES Attributo(id_attributo) ON DELETE CASCADE,
    FOREIGN KEY(RTabella) REFERENCES Tabella(id_tabella) ON DELETE CASCADE,
    FOREIGN KEY (RAttributo) REFERENCES Attributo(id_attributo) ON DELETE CASCADE,
        CONSTRAINT v4 UNIQUE (id_tabella,id_attributo, posizione)
);
/
CREATE TABLE VCHECK(

	nome             VARCHAR(32) PRIMARY KEY,         
        descrizione      VARCHAR(32) NOT NULL,
        id_attributo     INTEGER NOT NULL,
        codice_sql	 VARCHAR2(4000),
        FOREIGN KEY (id_attributo) REFERENCES Attributo(id_attributo) ON DELETE CASCADE
);
/

CREATE TABLE Vista
(
	id_vista	INTEGER PRIMARY KEY,
	nome 		VARCHAR(32) NOT NULL,
    descrizione	VARCHAR(800),
	codice_Sql	VARCHAR2(800),
	id_db		INTEGER NOT NULL,
    FOREIGN KEY (id_db) REFERENCES  Database(id_db) ON DELETE CASCADE,
	CONSTRAINT v5 UNIQUE (nome,id_db)
);
/
CREATE TABLE Triggers
(
	id_trigger	INTEGER      PRIMARY KEY,
	nome 		VARCHAR(32) NOT NULL,
	Descrizione	VARCHAR(32),
	codice_sql      VARCHAR(800),
      id_tabella	INTEGER ,
	id_vista	INTEGER ,
    FOREIGN KEY(id_tabella) REFERENCES tabella(id_tabella) ON DELETE CASCADE,
    FOREIGN KEY (id_vista) REFERENCES vista(id_vista) ON DELETE CASCADE,
    CONSTRAINT v6 UNIQUE (nome, id_tabella),
	CONSTRAINT v7 UNIQUE (nome, id_vista),
	CONSTRAINT v8 CHECK ( ( id_tabella IS NULL AND id_vista IS NOT NULL ) OR  ( id_tabella IS NOT NULL AND id_Vista IS NULL ))
);
/
CREATE TABLE Asserzione
(
	id_asserzione	INTEGER PRIMARY KEY,
	nome 		VARCHAR(32) NOT NULL,
	descrizione	VARCHAR2(50),
	codice_sql	VARCHAR(800),
	id_db		INTEGER NOT NULL,
    	FOREIGN KEY (id_db)REFERENCES  Database(id_db) ON DELETE CASCADE,
	CONSTRAINT v9 UNIQUE (nome, id_db)
);
/
CREATE TABLE Procedura
(
	id_procedura	INTEGER      PRIMARY KEY,
	nome 		VARCHAR(32) NOT NULL,
	descrizione	VARCHAR(50),
	codice_sql	VARCHAR(800),
	id_db  INTEGER NOT NULL,
    FOREIGN KEY (id_db) REFERENCES  Database(id_db) ON DELETE CASCADE,
    CONSTRAINT v10 UNIQUE (nome, id_db)
);
/
CREATE TABLE Sequenza
(
	nome 		VARCHAR2(32) PRIMARY KEY,
    startwith       INTEGER NOT NULL,
    incremento      INTEGER NOT NULL,
    minval 		INTEGER NOT NULL,
    maxval 		INTEGER NOT NULL,
    id_attributo INTEGER NOT NULL,
    FOREIGN KEY (id_attributo) REFERENCES  Attributo(id_attributo) ON DELETE CASCADE
);
/
CREATE TABLE Utente
(
        username	VARCHAR2(32) PRIMARY KEY,
  	nome 		VARCHAR2(32) NOT NULL,
	cognome 	VARCHAR2(32) NOT NULL,
	email		VARCHAR2(32) NOT NULL,
	password	VARCHAR2(32) NOT NULL
);
/
CREATE TABLE Accesso
(
 	username  VARCHAR2(32) NOT NULL,
	accesso  VARCHAR2(10) NOT NULL CHECK(accesso IN ('Writer','Reader','Editor')),
	id_db 	  INTEGER NOT NULL,
    PRIMARY KEY (username,id_db),
    FOREIGN KEY (username) REFERENCES Utente(username) ON DELETE CASCADE,
    FOREIGN KEY (id_db)REFERENCES Database(id_db) ON DELETE CASCADE      
);





